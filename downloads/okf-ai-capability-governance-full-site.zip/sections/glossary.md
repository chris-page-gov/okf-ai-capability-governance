---
type: publisher-section
title: Glossary and frequently asked questions
status: draft
sources:
- title: Glossary and frequently asked questions
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#glossary
x-dom-section: glossary
---

# Glossary and frequently asked questions

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#glossary)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Glossary and frequently asked questions [21433]

## Glossary [21436]

[21438] Filter terms

[21442] 4-eyes / 6-eyes

[21443] Two or three independent people involved in producing and approving an output.

[21445] accept

[21446] Used as produced, with no material change.

[21448] Agent

[21449] Software that plans and acts across multiple steps using tools, within explicit permissions and bounds.

[21451] Agent register

[21452] An operational inventory of deployed agents with named owners, approved sources, autonomy tier and retirement trigger.

[21454] Agent sprawl / orphaned agents

[21455] Agents outlive purpose, owner or service; estate accumulates unowned automation.

[21457] Agent washing

[21458] Rebranding existing automation as agentic; Gartner assesses ~130 of thousands of vendors as genuine.

[21460] Agentic

[21461] A capability that takes actions across tools under delegated authority, choosing its own path to a goal.

[21463] alb

[21464] Arm's-length body, agency or public corporation.

[21466] analyst

[21467] Produces analysis rather than decisions.

[21469] anti_streak

[21470] The interface changed state following a run of unmodified approvals.

[21472] Approval fatigue

[21473] Volume-driven degradation of review quality — the agentic form of clinical alert fatigue Remedy: Batching, risk-triage of what reaches a human at all.

[21475] assist

[21476] Drafts, summarises or analyses. No decision about a person is attached to the output.

[21478] Assist / recommend / determine

[21479] Deployment classes: assist = drafting/summarisation, no decision; recommend = informs a decision a person makes; determine = constitutes or directly produces the decision.

[21481] Assisted digital

[21482] Support for people who cannot use a digital service independently.

[21484] Assurance tier

[21485] The proportionate level of control an agent attracts, derived from criticality rather than popularity.

[21487] ATRS

[21488] Algorithmic Transparency Recording Standard — the UK format for publishing algorithmic tool use.

[21490] Authority

[21491] What an agent is permitted to do, as distinct from what it is technically capable of doing.

[21493] Automation bias

[21494] The tendency to accept an automated output without enough scrutiny.

[21496] Automation complacency

[21497] Reduced monitoring effort — not looking rather than looking and agreeing Remedy: Canaries; anti-streak interventions.

[21499] Automation drift

[21500] The gradual shift of an automated system's behaviour or use over time so it no longer aligns with the original design intent or approved scope. (Adopted from TBS Canada.)

[21502] Automation drift vs model/data/concept drift

[21503] Automation drift is behaviour or use shifting away from approved scope — a governance question. Model, data and concept drift are statistical changes in inputs or the target relationship — an ML operations question.

[21505] Autonomy level

[21506] How far an agent may act without a human decision, from suggest-only to bounded execution.

[21508] Barometer

[21509] The eight-dimension readiness self-assessment held on the reader's own device.

[21511] bias_pattern

[21512] The output reflects a disparate pattern across a protected characteristic.

[21514] Bimodality coefficient

[21515] (skew²+1)/(excess kurtosis + 3(n−1)²/((n−2)(n−3))); >~0.555 suggests bimodality; applied to time-to-decision as rubber-stamping signature.

[21517] Bounded autonomy

[21518] TBS Canada principle: tight explicit limits on data, tools, permissions and scope; labelled activity level ('draft only','read only'); named trained owners incl. sub-agents.

[21520] Canary

[21521] Synthetic known-bad output injected at low randomised rate under ethics approval with guaranteed downstream suppression.

[21523] canary.detected

[21524] True only where the reviewer's action demonstrates detection — modify, reject or escalate citing the seeded defect. Accepting a canary is never 'detected'.

[21526] Capability class

[21527] Whether a deployment is generative, agentic or declarative — the determinant of which controls carry the weight.

[21529] caseworker

[21530] Handles individual cases within established policy.

[21532] central_department

[21533] Ministerial or non-ministerial department.

[21535] Cognitive debt

[21536] Kosmyna et al. term for reduced cognitive engagement and unaided performance after LLM assistance.

[21538] Compensatory use

[21539] AI use that offsets a stable access barrier — one that's stable regardless of effort (e.g. drafting support for dyslexia, checking tone, structuring a first draft, holding several things in working memory). Carries little skill-atrophy risk because the underlying skill was never the bottleneck. 'This is what assistive technology is.'

[21541] Comprehension debt

[21542] Loss of understanding of code created via AI generation; targeted by comprehension gates at PR.

[21544] confidence_gated

[21545] The output was withheld because model uncertainty was high.

[21547] Conformance pack

[21548] A bundle of automated checks that tests an artefact against a named standard.

[21550] Connector

[21551] An integration that lets an AI tool read from, or write to, another system.

[21553] consecutive_unmodified_count

[21554] Derived from the actual ordered sequence of dispositions within a session. Reset to zero on any disposition other than 'accept'. Never estimated or sampled.

[21556] Contestability erosion

[21557] If the decision-maker cannot explain reasoning, the citizen cannot meaningfully challenge it.

[21559] Copilot Credit

[21560] The consumption billing unit for Microsoft agent activity, replacing the previous message unit from 1 September 2025.

[21562] Counterfactual

[21563] The comparison against which a benefit is measured, typically a group not using the tool.

[21565] Criticality

[21566] Operational dependency and consequence of failure, scored across ten dimensions to set the gate.

[21568] Crypto-agility

[21569] The ability to change cryptographic algorithms without redesigning the system.

[21571] Curb-cut framing / effect

[21572] Framing an accessibility tool by benefits that accrue to everyone, rather than as a deficit fix.

[21574] Currency

[21575] Recency/proficiency regime by analogy with aviation recency and clinical revalidation; NHS DCB0129/DCB0160 Clinical Safety Officer as domestic precedent.

[21577] Data boundary

[21578] A supplier commitment about where data is stored and processed. Check which features and models sit outside it.

[21580] DBT 'cold turkey' test

[21581] Imagine the licence removed tomorrow: which tasks become mildly annoying vs genuinely destabilising.

[21583] Decay class

[21584] How quickly a claim goes out of date: structural, positional, volatile or expiring.

[21586] Declarative

[21587] A capability defined by a specification — instructions, sources, permitted actions and constraints — that the platform executes.

[21589] Declarative agent

[21590] An agent defined by configuration: purpose, instructions, knowledge and permitted actions, run on a platform’s own model and orchestration.

[21592] Degraded-mode operating standard

[21593] Every agentic deployment demonstrates periodically and for real that the service runs without the agent at acceptable quality for a defined period.

[21595] DEIA

[21596] Diversity, equity, inclusion and accessibility.

[21598] Delegation competence

[21599] Skill of setting appropriate bounds, reading evidence they are wrong, and withdrawing agency without service collapse. Replaces task-audit definition of oversight competence.

[21601] Deployment route

[21602] The same model reached directly, through a cloud platform or inside another supplier’s product is a different governance object each time.

[21604] Deprecation

[21605] A supplier’s notice that a model, feature or interface will be withdrawn.

[21607] determine

[21608] The output constitutes, or directly produces, a decision about a person.

[21610] Deterministic automation

[21611] Rules-based automation that gives the same output for the same input every time.

[21613] developer

[21614] Builds or maintains the system.

[21616] Digital worker

[21617] An agent framed as a managed member of the workforce, with recruitment, probation, review and retirement.

[21619] disconfirmation_panel

[21620] Contradicting evidence was surfaced alongside the output.

[21622] DPIA

[21623] Data protection impact assessment, required for high-risk processing.

[21625] Drift

[21626] Divergence between a cited source, a model version or a control and what is actually in use.

[21628] Earned autonomy

[21629] Teams demonstrating sustained catch performance move to lighter oversight modes and higher agent autonomy.

[21631] Easy Read

[21632] Accessible format: short sentences, one idea per chunk, large type, simple icon per point, plain words, explicit permission to ignore what doesn't fit; normally reviewed by Easy Read readers before publication.

[21634] edit_distance_normalised

[21635] Normalised difference between the output as presented and the output as finalised, in [0,1]. Report the algorithm used alongside the data; values are not comparable across different distance measures.

[21637] EQIA

[21638] Equality impact assessment evidencing the public sector equality duty.

[21640] equality_concern

[21641] The output raised a potential discriminatory or disparate-impact issue.

[21643] escalate

[21644] Referred to another person or process rather than decided.

[21646] Evidence card

[21647] The standard record of a claim: what was done, method, result, publisher, date and known limitations.

[21649] Evidence log

[21650] A record of how a piece of AI-assisted work was produced, retained with the work.

[21652] Evidence pack

[21653] The bundle of records proving how an AI-assisted output was produced, checked and approved.

[21655] Exit path

[21656] The seven-step route out of a platform, model or supplier dependency: discover, target, design, extract, test, cutover, decommission.

[21658] Expiring

[21659] Carries an explicit date. Auto-flags for review on that date.

[21661] extension

[21662] Local codes must be namespaced with a 'x_' prefix (e.g. 'x_local_triage_override'). Anything unprefixed is reserved for the central vocabulary so that local extension never collides with a future addition.

[21664] FACT / INTERPRETATION convention

[21665] Evidence-discipline convention used in turn-5 paragraph.

[21667] factual_correction

[21668] A fact in the output was wrong.

[21670] factual_error

[21671] A verifiably incorrect fact.

[21673] FASTER principles

[21674] Canada: Fair, Accountable, Secure, Transparent, Educated, Relevant.

[21676] FinOps

[21677] The practice of joining consumption, cost, quality and value so spend is forecast, allocated and optimised.

[21679] Friction budget

[21680] f(consequence of error × model uncertainty × recency of demonstrated catch performance × novelty of the case).

[21682] Generative

[21683] A capability that produces content, analysis or options; nothing changes until a person acts on the output.

[21685] Grounding

[21686] Supplying authoritative source material so outputs can be traced, cited and checked.

[21688] Guardrail

[21689] A constraint that holds regardless of instruction: prohibited actions, data limits, escalation triggers.

[21691] Harvest now, decrypt later

[21692] Capturing encrypted data today to decrypt once quantum computers are capable.

[21694] high

[21695] Statutory or rights-bearing; detriment is material and correction requires appeal or is not possible.

[21697] Human in the loop

[21698] A person who must act before an output takes effect.

[21700] Human on the loop

[21701] A person who monitors and can intervene in an otherwise automated process.

[21703] Human-agent system

[21704] The agent, the people who instruct and review it, and the controls between them, tested as one.

[21706] Information asset owner

[21707] The named person accountable for an information asset, its use, sharing and risks.

[21709] injected_instruction

[21710] Content in the case record attempts to redirect the agent.

[21712] Instruction block

[21713] The seven-part specification of an agent's behaviour: goal, context, sources, task, format, guardrails, output.

[21715] insufficient_confidence

[21716] The reviewer could not satisfy themselves either way and did not proceed.

[21718] Investment line

[21719] The full cost of adoption: visible, foundational, people and change, operational, and transition and exit.

[21721] Ironies of automation

[21722] Automation takes the easy, routine parts and leaves humans the hard residue while removing the routine practice through which people became competent at the hard parts. Structural root of the programme.

[21724] Kill switch

[21725] A control that stops an agent immediately and blocks further actions.

[21727] Lapsed

[21728] Had a stated end date which has now passed. Status after that date is unknown.

[21730] Least privilege

[21731] Granting only the minimum permissions needed for the shortest necessary time.

[21733] local_authority

[21734] Principal council or combined authority.

[21736] Lock-in

[21737] Dependency on a platform, model, connector or supplier that raises the cost or risk of leaving.

[21739] low

[21740] Recoverable before effect; no material detriment.

[21742] manager

[21743] Supervises a team performing any of the above.

[21745] Material AI assistance

[21746] AI involvement that a reasonable reader would want disclosed because it shaped the output.

[21748] Meaningful human involvement

[21749] Under the UK GDPR, a significant decision with no meaningful human involvement counts as solely automated and needs safeguards, including the right to contest it (Articles 22A to 22C, from 5 February 2026). The ICO's draft guidance says the person must have the authority, training and information to change the outcome, and actually consider it.

[21751] medium

[21752] Correctable through normal review; some detriment or delay.

[21754] missing_context

[21755] The output was reasonable on what it saw but omitted material the reviewer held.

[21757] Model Context Protocol (MCP)

[21758] An open standard that lets an AI client call tools and read resources on an outside system through one interface.

[21760] Model version churn

[21761] Silent model upgrade resets the error profile human trust calibration was built against.

[21763] Model-dependent finding

[21764] Finding about a specific model's output quality at a point in time; short half-life; re-verify before citing.

[21766] modify

[21767] Used after alteration.

[21769] Monoculture / correlated error

[21770] A few frontier models underpin most deployment so errors correlate across services.

[21772] Moral crumple zone

[21773] A human positioned as the responsible party for a system they could not realistically have controlled; liability absorption rather than accountability.

[21775] Neurodiverse (preferred) vs neurodivergent

[21776] The preferred term in this portal is "neurodiverse", used throughout the Inclusive use section.

[21778] nhs

[21779] NHS body or integrated care system.

[21781] none

[21782] Standard presentation.

[21784] Not located

[21785] The cited item could not be found to exist at all.

[21787] Novice pipeline

[21788] The supply of experienced people to do oversight, threatened by removal of entry-level roles whose routine work functioned as practice.

[21790] Orphaned agent

[21791] An agent still in use whose owner has moved on — the most common governance failure in a growing estate.

[21793] other_public_body

[21794] Any other public sector organisation.

[21796] Out-of-the-loop performance

[21797] Inability to re-acquire situational awareness fast enough when the system hands back Remedy: Handback design; keeping the human's mental model warm.

[21799] out_of_scope

[21800] The output addressed something outside the agent's approved scope. Also a drift signal.

[21802] Oversharing

[21803] Content reachable by more people than intended, usually through accumulated permission drift.

[21805] Oversight Assurance Layer

[21806] Shared platform component: schema, SDK, prior-capture widget, canary service, baseline scheduler, privacy-enforcing aggregation, currency ledger, conformance suite.

[21808] plausible_fabrication

[21809] A confident, well-formed output with no basis in the source material.

[21811] Plugin

[21812] A packaged custom action, such as an MCP or API plugin, that lets an agent read or change data in another system.

[21814] policy_misapplication

[21815] The output applied the wrong rule, threshold or guidance.

[21817] Positional

[21818] Who holds a role, what is in force, what has been published. Review quarterly.

[21820] PQC

[21821] Post-quantum cryptography — algorithms resistant to quantum attack.

[21823] Predict-then-reveal

[21824] User records provisional judgement (decision, confidence, one-line rationale) before agent output is displayed. Keystone pattern.

[21826] predict_then_reveal

[21827] The reviewer's provisional judgement was captured before the output was shown.

[21829] Preview

[21830] A feature released before general availability. Terms, controls and data handling may differ.

[21832] Process ossification

[21833] Agents encode current process; changing it means re-engineering agents, so process stops evolving.

[21835] Prohibited fields

[21836] Never present in an oversight event: user_id, staff_id, employee_id, staff_number, person_id, username, email, name, line_manager, ip_address, device_id. These must never appear in an oversight event, at any tier. The privacy contract is what makes the regime credible to staff and to unions; it is enforced in the schema, in the aggregator and in the analyser, not merely stated here.

[21838] Promotion gate

[21839] The checkpoint between personal, team, departmental, operational and cross-government scope.

[21841] Prompt injection

[21842] Untrusted content that manipulates a model into unintended actions.

[21844] Proportionality

[21845] Control matched to risk, autonomy, data sensitivity, decision influence and public effect.

[21847] Provenance

[21848] The verifiable record of where content, data or code came from and how it changed.

[21850] Provenance rot

[21851] Case records increasingly contain agent-generated text that future agents retrieve as evidence; record ceases to be an independent source.

[21853] reason_required

[21854] Approval required a structured reason.

[21856] Reasoned-disagreement sampling

[21857] Sample cases for independent human reasoning; grade quality of reasoning on both sides; never treat divergence as error. Replaces unaided-baseline sampling.

[21859] recommend

[21860] The output informs a decision that a person then makes about someone.

[21862] Recoverability

[21863] TBS Canada principle: pause/stop/return-to-safe-state by design; actions logged in a system the agent cannot alter; fail safely.

[21865] Register

[21866] The eighteen-field record every agent needs, held by the owning organisation, not by this guide.

[21868] reject

[21869] Not used; the reviewer produced their own outcome.

[21871] Residual risk

[21872] What remains after controls are applied — stated, owned and accepted rather than assumed away.

[21874] Responsibility diffusion

[21875] Accountability becomes hard across sub-agents, tool calls and cross-departmental service composition.

[21877] review

[21878] Proposed additions go to the vocabulary owner with a definition, a worked example, and a statement of why an existing code does not fit.

[21880] reviewer

[21881] Second-line check on another person's or system's output.

[21883] Scheme of delegation

[21884] Government's existing model of delegated authority with limits, thresholds, named accountable officers and withdrawal; agents should sit inside it.

[21886] Scissor (volume vs capability)

[21887] Volume requiring oversight rises with adoption while capability to oversee falls with the same adoption; reinforcing loop overload→skimming→atrophy.

[21889] scope_overstep

[21890] The agent proposes an action outside its permitted scope.

[21892] senior_caseworker

[21893] Handles complex or escalated cases.

[21895] Seniority-biased technological change

[21896] Harvard working-paper term for entry-level hiring falling at generative-AI-adopting firms.

[21898] Shadow AI

[21899] Unregistered tools in operational use: unknown ownership, cost and risk. Maturity level zero.

[21901] Skill

[21902] A packaged, versioned capability an assistant or agent can invoke, with defined inputs and limits.

[21904] Skill atrophy

[21905] Degradation of the knowledge and practised judgement that oversight roles depend on, caused by sustained offloading of the underlying task. (Adopted from TBS Canada.)

[21907] Sophistication index

[21908] The prototype quality score across grounding, evaluation, guardrails, observability and support.

[21910] Source tiering

[21911] Ranking sources by authority so conflicts resolve predictably.

[21913] stability

[21914] Codes are additive. A code is never removed or repurposed; superseded codes are marked deprecated with a successor.

[21916] stale_data

[21917] The output relies on superseded information.

[21919] Structural

[21920] An argument, framework or finding about how things work. Review annually.

[21922] Structural finding

[21923] Human-factors/organisational finding about people and institutions; durable across model versions.

[21925] Subprocessor

[21926] A third party that processes data on behalf of the supplier, such as a model provider.

[21928] Substitutive use

[21929] AI use that replaces a judgement the practitioner would otherwise exercise (e.g. assessing whether an argument holds, deciding a course of action, interpreting data, summarising a policy paper one would otherwise have read). Carries the same oversight risk regardless of neurotype.

[21931] Superseded

[21932] Was correct when recorded; a later event has changed the position.

[21934] Supervisory control

[21935] Human-automation interaction concept; agency is a variable set per task and context on a levels-of-automation scale.

[21937] time_to_decision_ms

[21938] From presentation of the output to recording of the disposition. Excludes time before the item was opened.

[21940] tone_or_style

[21941] Presentation only; substance unchanged.

[21943] Unit economics

[21944] Cost and value per interaction: the figure that decides whether an agent earns its keep.

[21946] Unverified

[21947] No accessible primary or strong institutional source located across two independent passes. Not relied upon.

[21949] Verification state

[21950] Whether a claim is verified, verified in substance, unverified, superseded, lapsed or not located.

[21952] Verified

[21953] Source located; organisation, date and substance all confirmed.

[21955] Verified in substance

[21956] Claim is correct but the originally cited link, reference or date did not resolve.

[21958] Vigilance decrement

[21959] Sustained-attention performance falls sharply within the first half hour of monitoring Remedy: Queue design, shift length, task interleaving.

[21961] Volatile

[21962] Supplier rate cards, product availability, live counts. Verify at point of use; never cache.

## Frequently asked questions [21964]

[21967] Do I have to declare every use of AI?

[21969] No. Declare material assistance — where AI shaped the substance, structure, analysis or code of an output. Trivial uses such as spell-checking do not need a declaration, but your local policy may set a lower threshold.

[21971] Can AI approve my work?

[21973] No. AI can suggest, draft, check and explain. Approval is a human act by someone with the authority to make that decision. AI never grants authority a user does not already hold.

[21975] What if the AI cites a source that does not exist?

[21977] Treat it as an incident. Do not publish. Verify every citation against the original, log the failure in the drift and incident register, and check whether the same prompt pattern has been used elsewhere.

[21979] Is this a substitute for a DPIA, EQIA or security assurance?

[21981] No. This toolkit helps you prepare and evidence those assessments; it does not replace them or the professionals accountable for them.

[21983] Can I paste official-sensitive information into a general assistant?

[21985] Not unless the tool is explicitly approved for that classification and the data-handling terms have been assured. When in doubt, do not paste — ask your information asset owner.

[21987] How do I handle AI-generated code?

[21989] Treat it as untrusted third-party code: review it, test it, scan dependencies, record provenance and never merge without a human reviewer who understands it.

[21991] What accessibility duties apply to AI-generated content?

[21993] The same ones that apply to everything else. WCAG 2.2 AA, plain language, alternative formats and the accessibility statement duty all apply regardless of who or what drafted the content.

[21995] Who do I contact if something goes wrong?

[21997] Your service owner and the named AI assurance contact for your organisation. Report near-misses too — they are the cheapest form of learning.

