---
type: publisher-section
title: Knowledge and navigation
status: draft
sources:
- title: Knowledge and navigation
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-knowledge-and-navigation
x-dom-section: part-knowledge-and-navigation
---

# Knowledge and navigation

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-knowledge-and-navigation)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[14814] Part 10 of 12 · 4 chapters

## Knowledge and navigation [14815]

[14824] Knowledge and navigation · 10 entries

## Thesaurus [14825]

[14826] Preferred term, the variants you will hear, and why the distinction matters. Cross-government acronyms and loose synonyms are the main cause of transcripts and registers that cannot be searched.

## Agent [14831]

[14833] digital worker

[14835] assistant

[14837] copilot

[14839] bot

[14840] Use agent for the governed capability; digital worker only when the employment framing is deliberate.

## Assurance [14844]

[14846] governance

[14848] compliance

[14850] sign-off

[14851] Assurance tests claims against evidence; governance sets the rules. Do not use them interchangeably.

## Criticality [14855]

[14857] risk level

[14859] importance

[14861] priority

[14862] Criticality is dependency and consequence. Risk level is the output of scoring it.

## Register [14866]

[14868] inventory

[14870] catalogue

[14872] asset register

[14873] Register for agents; catalogue for data; asset register for information assets. Three registers, integrated, not merged.

## Evaluation [14877]

[14879] testing

[14881] benchmarking

[14883] evals

[14884] Evaluation covers accuracy, safety and fitness against a baseline; testing alone implies pass or fail.

## Guardrail [14888]

[14890] control

[14892] policy

[14894] limit

[14895] Guardrails are technical constraints; controls include process and people; policy is the rule they enforce.

## Retirement [14899]

[14901] decommissioning

[14903] offboarding

[14905] sunsetting

[14906] Retirement is the lifecycle stage; decommissioning is the technical work inside it.

## Transparency record [14910]

[14912] ATRS record

[14914] algorithmic transparency

[14916] publication

[14917] ATRS record is the published artefact; the internal registry extension is proposed, not mandated.

## Value [14921]

[14923] benefit

[14925] ROI

[14927] savings

[14928] State value as an outcome with a method. Reserve savings for cash-releasing benefits that finance has agreed.

## Adoption [14932]

[14934] rollout

[14936] deployment

[14938] enablement

[14939] Adoption is people changing how they work; deployment is the technology going live. They are not the same date.

[14940] Back to the contents · Suggest a correction (opens GitHub)

[14952] Knowledge and navigation · classification

## Taxonomies and ontology [14953]

[14954] Eight facets to classify anything in the estate, and the relations that connect them. Use the same vocabulary in the register, the ATRS record and the assurance case, or none of the three can be joined up.

## Facets [14956]

## Capability class [14960]

[14962] Sets which controls carry the weight.

[14963] Generative Agentic Declarative

## Assurance tier [14970]

[14972] Derived from criticality, not from popularity.

[14973] Personal Team Departmental Operational service Citizen impact

## Lifecycle stage [14982]

[14984] The status field in the register.

[14985] Proposed Pilot Live Restricted Suspended Retired

## Autonomy level [14995]

[14997] Guardrails apply at every level.

[14998] Suggest Recommend Prepare Act with approval Act and report Act autonomously

## Maturity level [15008]

[15010] Evidence-based, not self-scored.

[15011] Uncontrolled Aware Experimenting Governed Integrated Federated Adaptive

## Cost layer [15022]

[15024] Six layers, six owners.

[15025] Enterprise foundation Shared platform Product or service Team or workload Use case End user

## Evidence strength [15035]

[15037] Independently validated down to anecdotal.

[15038] Strong Moderate Emerging Weak Not assessed

## Role family [15047]

[15049] Determines the learning pathway.

[15050] Leadership Product and service Technical and data Governance and assurance Commercial and finance Operations and frontline

## Ontology — subject, relation, object [15057]

[15058] Agent has Purpose, owner, capability class and authority

[15062] Agent is recorded in Register entry and ATRS record

[15066] Agent is classified by Criticality score, which sets its Assurance tier

[15070] Assurance tier requires Evidence set and review frequency

[15074] Agent consumes Data sources with provenance and permissions

[15078] Agent acts within Autonomy level and guardrails

[15082] Agent generates Cost, measured per interaction and per month

[15086] Cost is allocated to One of six cost layers with a named owner

[15090] Agent affects Service outcome, then public experience, then trust

[15094] Incident triggers Failure and recovery loop, then a control change

[15098] Owner is accountable for Agent through its whole lifecycle

[15102] Evidence supports or refutes Claim, with method, publisher and date

[15106] Back to the contents · Suggest a correction (opens GitHub)

[15118] Knowledge and navigation · platforms and repositories

## Platforms and repositories [15119]

[15120] Links point to the vendors' own documentation. Nothing here is an endorsement or a procurement decision: platform choice sits with commercial colleagues, and the dependency and exit chapter applies to every entry on this page.

## Government repositories and communities [15122]

## AI Engineering Lab [15125]

[15126] Open resource repository under OGL v3.0, plus the Knowledge Hub community

## Documentation [15127]

## i.AI open source [15129]

[15130] Consult, Redbox, Caddy and the rest of the incubator's public repositories

## Documentation [15131]

## AI Knowledge Hub [15133]

[15134] Tool pages with cost, evaluation and lessons

## Documentation [15135]

## GOV.UK Design System [15137]

[15138] Components and patterns for government services

## Documentation [15139]

## Microsoft [15140]

## Copilot Studio and agent builder [15143]

[15144] Declarative agents, connectors, publishing controls

## Documentation [15145]

## Microsoft 365 admin and Purview [15147]

[15148] Permissions, sensitivity labels, audit and retention

## Documentation [15149]

## Azure AI Foundry [15151]

[15152] Model hosting, evaluation and content safety

## Documentation [15153]

## Power Platform governance [15155]

[15156] Environment strategy, DLP policies, managed environments

## Documentation [15157]

## Google [15158]

## Gemini for Workspace admin [15161]

[15162] Data handling, availability and admin controls

## Documentation [15163]

## Vertex AI [15165]

[15166] Model garden, evaluation and grounding

## Documentation [15167]

## Google Cloud IAM [15169]

[15170] Least-privilege permissions and service accounts

## Documentation [15171]

## Atlassian [15172]

## Atlassian Intelligence and Rovo [15175]

[15176] Agents over Jira and Confluence content

## Documentation [15177]

## Jira for the pilot backlog [15179]

[15180] Decision records, findings and remediation tracking

## Documentation [15181]

## Confluence for evidence packs [15183]

[15184] Session packs, taxonomies and curated patterns

## Documentation [15185]

## Slack [15186]

## Slack AI and agents [15189]

[15190] Assistants inside channels, with workspace data boundaries

## Documentation [15191]

## Slack Connect governance [15193]

[15194] Cross-organisation channels: membership and data controls

## Documentation [15195]

## Workflow Builder [15197]

[15198] Declarative automation without code

## Documentation [15199]

[15200] Back to the contents · Suggest a correction (opens GitHub)

[15212] Knowledge and navigation · proposed model

## From fragmented guidance to a federated service [15213]

[15214] One trusted discovery layer over many authoritative sources, with a clear path from need to assured deployment. A federated index that links to governed sources beats another copy repository — this is a proposed model synthesised from community discussion and existing guidance, not an authoritative standard.

## The landscape today [15216]

## Government policy & principles [15219]

[15221] AI Playbook for the UK Government

[15222] Generative AI Framework

[15223] Civil service guidance

[15224] Departmental policies

[15225] Ethical & legal frameworks

## Technical documentation [15227]

[15229] Microsoft Learn (Copilot, Agents, Studio, Purview)

[15230] Technical readiness & configuration

[15231] Security & identity blueprints

[15232] Administration guides

## Product & licensing information [15234]

[15236] Microsoft 365 Copilot licensing

[15237] Agent Builder & Studio documentation

[15238] Capacity, credits & consumption

[15239] Connectors & capabilities

[15240] Roadmaps & updates

## Local playbooks & templates [15242]

[15244] Departmental playbooks

[15245] Use case templates

[15246] Business cases

[15247] Process maps

[15248] Agent governance examples

[15249] Training materials

## Community evidence & insight [15251]

[15253] Weekly xGov Copilot calls

[15254] AI Engineering Lab

[15255] Community Q&A

[15256] Worked examples

[15257] Lessons learned

[15258] Emerging patterns & issues

## Sector & investment guidance [15260]

[15262] FinOps guidance

[15263] Commercial & procurement guidance

[15264] Data management & information governance

[15265] Security, privacy & assurance

[15266] Accessibility & inclusion

## External & market intelligence [15268]

[15270] Supplier blogs & updates

[15271] Industry reports

[15272] Standards bodies

[15273] Academic research

[15274] International benchmarks

[15276] Challenges of fragmentation Hard to find Out of date Inconsistent Duplication Gaps Heavy manual effort Risk of non-compliance

## The target state [15287]

[15288] A federated guidance hub: navigate, connect, understand, apply, assure, share.

[15293] Single discovery experience One place to search and navigate.

[15298] Authority & evidence clarity Clear source, status and assurance level.

[15303] Connected knowledge Linked guidance, tools, templates, use cases and decisions.

[15308] Current & relevant Version control, review dates and change alerts.

[15313] Role & scenario based pathways Tailored journeys by role, task and maturity level.

[15318] Implementation tools Checklists, decision trees, templates, readiness assessments.

[15323] Community feedback loop Capture questions, insights and lessons into guidance.

[15328] Measure & improve Usage insights, gap analysis, continuous improvement.

## Outcomes and benefits [15330]

## Consistent, proportionate and compliant AI deployment [15335]

## Faster access to the right guidance and tools [15339]

## Reduced duplication and wasted effort [15343]

## Stronger assurance and risk management [15347]

## Higher quality outcomes and public value [15351]

[15352] Back to the contents · Suggest a correction (opens GitHub)

