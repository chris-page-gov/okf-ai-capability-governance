---
type: publisher-section
title: Pick the route that matches your job today
status: draft
sources:
- title: Pick the route that matches your job today
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#start-here
x-dom-section: start-here
---

# Pick the route that matches your job today

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#start-here)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Pick the route that matches your job today [893]

[894] Task-first entry points, because people arrive with a decision to make — not an interest in our information architecture.

## How much do you already know? [895]

[896] Choose a level, then a route below. Every route and task is marked with its level.

[900] New to AI in public services, or using this site for the first time. No technical knowledge needed.

[901] Start with: The four principles and the 2-minute review triage

[905] Then: Glossary and FAQ , transparency

[911] Using, buying or approving AI in your work, and need to show it is governed.

[912] Start with: H0–H5 review model and the evidence pack

[916] Then: Transparency record , resources , signals

[923] Building, assuring, integrating or reusing this guidance, including in code.

[924] Start with: Toolkit and the metadata schema

[928] Then: Authority tiering , open data , the repository

## Routes by role [933]

## New or occasional contributor [937]

[938] "I don’t want to get this wrong."

[939] Plain-language guidance, safe defaults, confidence prompts, buddying and clear role limits.

[940] Take the 5-minute triage, then use the declaration generator.

[942] Journey: Human review triage → Evidence pack → Code of practice

## Experienced practitioner [949]

[950] "Give me the fast, correct route."

[951] Direct links to standards, patterns, conformance packs, test scripts and evidence automation.

[952] Jump to the toolkit and copy the metadata schema.

[954] Journey: Toolkit → Metadata schema → Tools

## Specialist reviewer [961]

[962] "Show me what to challenge."

[963] Source-linked evidence, issue triage, risk decisions and assurance history.

[964] Use the H-level table and reviewer checklist.

[966] Journey: Reviewer checklist → Authority tiering → Signals

## Accountable owner / SRO [973]

[974] "What am I signing?"

[975] Risk overview, approval gates, residual risk, maturity dashboard and public transparency records.

[976] Generate the transparency record and check the MoSCoW roadmap.

[978] Journey: H0–H5 review model → Transparency record → Roadmap

## Supplier or delivery partner [985]

[986] "What will I be assessed against?"

[987] Published expectations, evidence formats, accessibility and security obligations, exit terms.

[988] Filter resources by procurement and security.

[990] Journey: Resources (procurement, security) → Catalogue metadata → Assurance

## Member of the public [997]

[998] "How is AI being used on my case?"

[999] Plain-English explanation, published records, how to challenge a decision and get support.

[1000] Read the transparency and redress commitments.

[1002] Journey: Transparency → Glossary and FAQ → Contact

## Data or AI governance lead [1009]

[1010] "What is changing, and does my data estate let us govern agents?"

[1011] Weekly signals with sources, the agent registry pattern, catalogue metadata for AI assets and the review model.

[1012] Start with this week's signals.

[1014] Journey: Signals → Agent registry (TK-03) → AI asset metadata → Review model

## Common tasks [1020]

## Decide how much human review my output needs [1025]

[1026] Answer six questions and get an H0–H5 level, the reviewers required and the evidence to keep.

## Write an AI-use declaration and evidence pack [1030]

[1031] Generate a copy-ready record of sources consulted, checks made and who approved what.

## Screen a change for equality and accessibility impact [1035]

[1036] Flag protected characteristics, access needs, assisted digital and exclusion risks early.

## Draft a public transparency record [1040]

[1041] Produce an ATRS-shaped record describing the tool, its purpose, data, oversight and risks.

## Check quantum and cryptographic exposure [1045]

[1046] Score harvest-now-decrypt-later risk against NCSC migration milestones.

## Find the authoritative source for a rule [1050]

[1051] Search 69 tiered laws, standards, guidance documents and tools.

[1053] Not sure whether to use AI at all? Ask three questions first: is there a simpler non-AI way to meet the user need; can you explain the decision to the person it affects; and could you defend this use at a public inquiry? If any answer is no, stop and seek advice.

