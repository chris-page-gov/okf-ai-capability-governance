---
type: publisher-section
title: Human-centred controls for trustworthy AI work
status: draft
sources:
- title: Human-centred controls for trustworthy AI work
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#assurance
x-dom-section: assurance
---

# Human-centred controls for trustworthy AI work

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#assurance)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Human-centred controls for trustworthy AI work [19512]

[19513] Risk-based human-in-the-loop controls make sure AI never grants authority a user does not already possess, and that every material output can be defended after the fact.

## The five-stage assurance workflow [19514]

[19516] Classify — identify service impact, data sensitivity, equality and accessibility risk, security risk and model/agent autonomy. Use the triage tool →

[19519] Select — apply the standards, source guidance, skills, agents, conformance packs and review level the classification demands.

[19521] Execute — work with least privilege, mandatory source citation, deterministic checks and pair or buddy support where competence is thin.

[19523] Review — 4-eyes or 6-eyes review, specialist assurance, and no self-approval for material or high-risk outputs.

[19525] Learn — capture evidence, incidents, near-misses, feedback, source drift and model changes; feed them back into the corpus.

## The H0–H5 human review model [19527]

[19530] Review levels, when they apply and the evidence each produces

[19533] Level

[19534] Name

[19535] What it means

[19536] Typical examples

[19537] Evidence

[19540] H0

[19542] No review needed

[19544] Personal, throwaway, non-published exploration with no personal or sensitive data.

[19545] Explaining a concept to yourself; drafting private notes.

[19546] None required.

[19548] H1

[19550] Self-check

[19552] Author verifies facts, sources and accessibility before use. Low impact, easily reversible.

[19553] Internal meeting notes, first-draft ideas.

[19554] AI-use note in the document.

[19556] H2

[19558] Peer check

[19560] A second competent person checks output before it leaves the team.

[19561] Internal reports, non-public analysis, low-risk code in a sandbox.

[19562] Reviewer name, date, issues found.

[19564] H3

[19566] Specialist review (4-eyes)

[19568] A named specialist in the relevant discipline reviews. No self-approval.

[19569] Accessibility, security, legal, statistical or clinical content; production code.

[19570] Specialist sign-off + test results.

[19572] H4

[19574] Multi-specialist review (6-eyes)

[19576] Two or more specialisms plus the accountable owner. Independent challenge required.

[19577] Public-facing decisions, casework support, anything affecting entitlements.

[19578] Panel record, dissent captured, residual risk stated.

[19580] H5

[19582] Governance board and publication

[19584] Formal board approval, published transparency record and monitored deployment.

[19585] Automated or semi-automated decisions about people; national services.

[19586] ATRS record, DPIA, EQIA, monitoring plan, review date.

## Reviewer checklist [19587]

## Always check [19590]

[19592] Every citation opens, exists and says what the text claims

[19593] Numbers, dates, thresholds and legal references independently verified

[19594] Nothing asserts compliance that has not actually been tested

[19595] No personal or sensitive data was entered into an unapproved tool

[19596] Accessibility and plain-language requirements met, not assumed

[19597] Assumptions, gaps and residual risk stated explicitly

[19598] Reviewer is independent of the author at H3 and above

## Common failure patterns [19600]

[19602] • Confident fabrication — plausible citations that do not exist

[19604] • Stale authority — quoting withdrawn or superseded guidance

[19606] • Compliance theatre — a checklist ticked without a test run

[19608] • Silent scope creep — an agent doing more than was authorised

[19610] • Automation bias — reviewers rubber-stamping fluent output

[19612] • Averaged users — outputs tuned to a majority that excludes minorities

[19614] • Evidence gaps — no record of who checked what, or when

## Accountability at a glance (RACI) [19616]

[19619] Who does what in AI-assisted delivery

[19622] Activity

[19623] Responsible

[19624] Accountable

[19625] Consulted

[19626] Informed

[19629] Classifying risk and review level

[19630] Author

[19631] Service owner

[19632] Specialist reviewers

[19633] Delivery team

[19635] Verifying sources and outputs

[19636] Author

[19637] Author

[19638] Peer reviewer

[19639] Service owner

[19641] Specialist sign-off (H3+)

[19642] Named specialist

[19643] Service owner

[19644] Author

[19645] Assurance board

[19647] Equality and accessibility screening

[19648] Author

[19649] Service owner

[19650] Equality & accessibility leads

[19651] Governance board

[19653] Data protection and lawful basis

[19654] Product owner

[19655] Data controller / SIRO

[19656] DPO

[19657] ICO where required

[19659] Publishing a transparency record

[19660] Service owner

[19661] SRO

[19662] Comms, legal

[19663] Public

[19665] Incident and near-miss reporting

[19666] Anyone who spots it

[19667] Service owner

[19668] Security, DPO

[19669] Assurance board

