---
type: publisher-section
title: Tell us what is wrong, missing or unclear
status: draft
sources:
- title: Tell us what is wrong, missing or unclear
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#contact
x-dom-section: contact
---

# Tell us what is wrong, missing or unclear

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#contact)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Tell us what is wrong, missing or unclear [22178]

[22179] Every route below goes through GitHub, so it is public and auditable. There is no email route. Choose the one that fits — if you are not sure, raise an issue and we will redirect it.

## Something is broken [22183]

[22184] Broken links, tools that do not work, layout failures, incorrect calculations or console errors.

[22185] Report a bug on GitHub

## An accessibility barrier [22189]

[22190] Anything that stops you using this site with a screen reader, keyboard, magnification, voice control or any other assistive technology. These are treated as priority defects.

[22191] Report a barrier

[22193] Target first response: 5 working days.

## A feature or resource request [22196]

[22197] A tool you need, a section that is missing, or an authoritative source that should be in the library.

[22198] Request a feature

## Content is wrong or out of date [22202]

[22203] Superseded guidance, a withdrawn standard, a mis-stated legal duty or a dead authority link. Include the source that proves it.

[22204] Submit a correction

## A security vulnerability [22208]

[22209] Do not open a public issue. Use private disclosure so we can fix it before it is known. See our security policy for scope and timescales.

[22210] Report privately

## A question or an idea [22214]

[22215] Not sure it is a defect? Want to talk about approach, reuse this in your organisation, or contribute? Start there.

[22216] Use the contact form

## Write it here first [22218]

[22219] This form helps you write a clear report, then opens the GitHub contact form with it filled in. Issues are public: do not include personal data, case details or anything above OFFICIAL. For a security problem, use private reporting instead.

[22223] Your name (optional)

[22227] Organisation (optional)

[22231] What is this about?

[22233] General enquiry

[22234] Accessibility barrier

[22235] Content correction

[22236] Feature or resource suggestion

[22237] Reuse or adaptation in my organisation

[22238] Partnership or contribution

[22239] Data protection or privacy question

[22240] Something else

[22242] Subject

[22245] Which page or section does this concern? (optional)

[22249] Your message

[22253] Assistive technology you were using (optional, helps us reproduce accessibility issues)

[22258] I understand GitHub issues are public and I have not included personal or sensitive information.

[22260] Open the contact form on GitHub

[22261] Copy message instead

[22262] Clear form

[22264] A preview of your message will appear here before anything is sent.

## What happens to your message [22265]

## How it is handled [22268]

[22270] • Nothing is transmitted from this page. The form builds a report and opens GitHub with it, so you stay in control of what is posted.

[22271] • GitHub issues are public. Do not put personal or sensitive information in them.

[22272] • Accessibility reports are logged as defects with a target first response of five working days.

[22273] • Security reports follow coordinated disclosure and are never opened as public issues.

## If we cannot resolve it [22275]

[22277] • Ask for the decision to be reviewed by the accountable owner named in the transparency section.

[22278] • For accessibility complaints in the UK, you can escalate to the Equality Advisory and Support Service .

[22280] • For data protection concerns, contact the host organisation's data protection officer, then the Information Commissioner's Office .

[22282] • All correspondence about this repository is capable of being disclosed under freedom of information law.

