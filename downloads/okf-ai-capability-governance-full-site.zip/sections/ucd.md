---
type: publisher-section
title: Designed for real people, varied needs and accountable teams
status: draft
sources:
- title: Designed for real people, varied needs and accountable teams
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#ucd
x-dom-section: ucd
---

# Designed for real people, varied needs and accountable teams

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#ucd)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Designed for real people, varied needs and accountable teams [19761]

[19762] Inclusion is a delivery activity, not a compliance report. This section states what we commit to, how we test it, and how you can hold us to it.

## Design and research practice [19763]

## Start with user needs [19766]

[19767] Every asset traces to a named user need and a measurable outcome. If we cannot name the need, we do not build the feature.

[19768] Government Design Principles → (opens an external website)

## Research with the full range of users [19772]

[19773] Recruit disabled participants, assistive technology users, people with low digital confidence and people in vulnerable circumstances — in every round, not a one-off "accessibility round".

[19774] Inclusive research guidance → (opens an external website)

## Test with assistive technology [19778]

[19779] Manual testing with screen readers, magnification, voice control, switch access and keyboard-only. Automated tools catch a minority of real barriers.

[19780] ARIA Authoring Practices → (opens an external website)

## Design for the whole journey [19784]

[19785] Including offline, assisted digital, third-party support, and what happens when the AI is unavailable or wrong.

[19786] Assisted digital guidance → (opens an external website)

## Write for reading age 9 [19790]

[19791] Plain English, short sentences, no unexplained acronyms, inclusive terminology, and alternative formats on request.

[19792] Check your content →

## Measure exclusion, not just satisfaction [19795]

[19796] Track drop-out by channel and need, assisted digital volumes, complaint themes and accessibility issue ageing — and publish them.

[19797] Service Standard → (opens an external website)

## Accessibility commitments for this portal [19800]

## What we build in [19803]

[19805] Semantic HTML, landmarks and a logical heading order

[19806] Full keyboard operation with a visible, high-contrast focus indicator

[19807] Text contrast of at least 4.5:1 and 3:1 for interface components

[19808] Light, dark and high-contrast themes, plus a larger-text setting that persists

[19809] Respect for prefers-reduced-motion and no motion-only meaning

[19811] Responsive to 320 CSS px and to 400% zoom without loss of content

[19812] Status messages announced through ARIA live regions

[19813] No colour-only meaning; icons always paired with text

[19814] Descriptive link text that makes sense out of context

[19815] A print stylesheet that expands links and collapsible content

## How we test and report [19817]

[19819] Automated checks in the pipeline on every change

[19820] Manual keyboard and screen reader testing before release

[19821] Periodic testing with disabled participants

[19822] A published accessibility statement listing known gaps and fix dates

[19823] A named contact and a 5-working-day response commitment

[19824] Escalation route to the Equality Advisory and Support Service

[19825] Accessibility statement guidance → (opens an external website)

## DEIA in AI specifically [19828]

[19831] Known equity risks of AI-assisted delivery. Performance that degrades for under-represented groups; language models that default to majority dialects and names; outputs written above the reading age of the audience; automation that removes the human route people in crisis rely on; accessibility regressions in AI-generated code and content; and reviewers who trust fluent text more than accurate text.

[19834] What we do about them. Screen every change with the DEIA tool; disaggregate evaluation by affected group where lawful and proportionate; keep a human route that cannot be removed by efficiency targets; test AI-generated interfaces with assistive technology before merge; publish limitations honestly; and give people a real way to challenge an outcome.

