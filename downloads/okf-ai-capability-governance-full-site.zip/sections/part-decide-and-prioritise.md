---
type: publisher-section
title: Decide and prioritise
status: draft
sources:
- title: Decide and prioritise
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-decide-and-prioritise
x-dom-section: part-decide-and-prioritise
---

# Decide and prioritise

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-decide-and-prioritise)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[2114] Part 2 of 12 · 6 chapters

## Decide and prioritise [2115]

[2124] The evidence

## Same product. Four UK evaluations. Four answers. [2125]

[2126] What varies is method, not the tool. Uncontrolled self-report gives the highest figures; comparison-group econometrics gives mid-range; counterfactual-free evaluation of a short pilot gives the lowest. Role mix is the second driver.

[2130] 26

[2131] minutes / day

## Cross-government, GDS [2132]

[2133] 20,000 staff, self-reported

[2135] 60

[2136] minutes / week

## HMRC, randomised cohort [2137]

[2138] 3,000 licences

[2140] 19

[2141] minutes / day

## DWP, comparison group [2142]

[2143] 3,549 staff, econometric

[2145] 0

[2146] robust evidence

## DBT, no counterfactual [2147]

[2148] 1,000 licences

[2149] Never average these numbers. The spread is evidence about evaluation design. Sources: GDS findings report (Jun 2025); HMRC phase 3; DWP evaluation (Jan 2026); DBT evaluation (Aug 2025).

## Four things block the move to governed scale [2151]

## Unremediated permissions [2154]

[2155] AI surfaces what a user may already reach. Permission drift becomes an incident on day one.

[2156] Makes scaling UNSAFE

## No agent inventory [2158]

[2159] The transparency standard records algorithmic tools. It is not an operational register of agents.

[2160] Makes scaling UNGOVERNABLE

## Unpredictable consumption cost [2162]

[2163] Credits are billed per feature, not per conversation. A builder's design choice sets a budget holder's cost.

[2164] Makes scaling UNBUDGETABLE

## Unfunded human effort [2166]

[2167] Workflow redesign, local support and output verification happen but rarely appear as funded lines.

[2168] Makes scaling UNSUSTAINABLE

## Activity is running ahead of visibility [2169]

[2170] Between deployment and disclosure sits a gap no current UK instrument closes. The ATRS is a transparency mechanism, not an inventory: it does not capture team-shared agents, orphaned agents, data-source approval, consumption cost or retirement.

[2173] 21%

[2174] of bodies responding to the NAO had an AI strategy

[2175] NAO · Mar 2024

[2177] 74

[2178] use cases deployed, reported at the same date

[2179] NAO · Mar 2024

## 33 → 125 [2181]

[2182] transparency records: Jan 2025 → end-2025

[2183] PAC · OECD.AI

[2185] 28%

[2186] of central government IT is legacy

[2187] PAC · Mar 2025

## Coding agents: two findings, both real [2190]

[2191] A finding about where to deploy, not whether.

## 1 hr [2194]

[2196] saved per day — GDS cross-government trial, 50 organisations

[2197] 72% said good value; 58% would not return to working without it

## 19% [2202]

[2204] slower — METR randomised trial: experienced developers, mature code

[2205] 20% felt faster — the same developers, in the same trial

[2208] Benefit is largest on well-scoped, greenfield and boilerplate work; smallest or negative on mature, complex codebases. Developer self-assessment is unreliable in both directions. Join the AI Engineering Lab (OCTO, GDS) before procuring independently — the evidence you generate is reusable.

## What the enthusiastic version leaves out [2210]

[2211] Contrary evidence, recorded deliberately.

## 17% [2214]

[2216] of cross-government trial users noticed no clear time savings (GDS, Jun 2025)

## 7% [2219]

[2221] of Australian participants reported the tool added time (DTA, Oct 2024)

## 61% [2224]

[2226] of Australian managers could not confidently identify AI outputs (DTA, Oct 2024)

## 72% [2229]

[2231] of councils were not ready on workforce skills and expertise (LGA, Jun 2025)

[2232] Canada names a further risk no UK instrument addresses: skill atrophy and automation drift. Skill maintenance is a prerequisite for meaningful human oversight, not an optional extra (TBS Canada, May 2026).

## A caution on AI-produced research [2234]

[2235] Twenty sources in one AI research draft. What checking found:

[2238] 7

[2239] verified precisely

[2241] 6

[2242] verified in substance

[2244] 4

[2245] not verified as cited

[2247] 1

[2248] could not be located

[2249] None of the unverifiable entries was obvious: each was correctly formatted, plausibly dated, attributed to a real institution. Treat AI-produced research as a hypothesis-generating artefact, never an evidence base — and keep the verification log with the output.

## Evidence labels used across this app [2250]

[2253] Verified fact — supported by official, regulatory, audit or primary sources

[2256] Organisation-reported — reported by the organisation itself, not independently measured

[2259] Supplier claim — authoritative for product terms; interested-party evidence for value

[2262] Interpretation — analytical judgement drawn from cited evidence

[2265] Recommendation — action proposed, not established practice

[2268] Unresolved — evidence incomplete, conflicting or arrangement-specific

[2270] Back to the contents · Suggest a correction (opens GitHub)

[2282] Use cases & evidence

## Where AI creates value across government and public services [2283]

[2284] Eighteen categories, from productivity tools to enterprise agents — supporting people, processes and public outcomes. Use AI and agents responsibly to enhance the work of public servants and improve outcomes for citizens.

[2288] 1. Knowledge retrieval & insight Find, summarise and synthesise information from trusted sources

[2291] 2. Content & correspondence Draft, edit and refine high-quality content and communications

[2294] 3. Contact centres & helpdesks Support staff and citizens with accurate, consistent responses

[2297] 4. Casework & service operations Streamline case handling, triage and workflow automation

[2300] 5. Citizen services & engagement Deliver simpler, faster and more accessible services

[2303] 6. Meetings & collaboration Capture, summarise and turn meetings into actions and outcomes

[2306] 7. Data analysis & reporting Analyse data, create summaries and produce management information

[2309] 8. Software engineering & IT operations Accelerate development, testing and secure operations

[2312] 9. HR & people management Improve people processes and the employee experience

[2315] 10. Finance & procurement Enhance financial planning, analysis and supplier management

[2318] 11. Education, training & skills Personalise learning and improve knowledge retention

[2321] 12. Programme & project management Plan, track and report with intelligent support

[2324] 13. Health & care Support clinical and administrative workflows safely and securely

[2327] 14. Policing, justice & public safety Improve investigations, evidence handling and public protection

[2330] 15. Regulatory & compliance Monitor compliance and produce regulatory outputs

[2333] 16. Policy & strategy development Scenario analysis, option generation and evidence synthesis

[2336] 17. Communications & media Create campaigns, content and prepare responses

[2339] 18. Research & horizon scanning Scan trends, research and emerging opportunities

## Cross-cutting capabilities — enablers for all use cases [2343]

[2344] Secure access to trusted data & knowledge AI agents & orchestration (autonomy with oversight) Human oversight & accountability Privacy, security & data protection Quality assurance & model evaluation Observability, monitoring & auditability Integration with systems & workflows Change management & adoption FinOps & cost management

## Foundational enablers [2355]

[2356] Data quality & governance Information management Access management Standards & interoperability Skills & culture Ethics & responsible AI

## The use-case evidence card [2363]

[2364] A consistent way to describe, evaluate and share AI use-case evidence: what the capability does, who it helps, how it works, the value it delivers, and the evidence that supports it. Evidence first. Value always. Capture consistently, share openly, decide confidently.

[2367] 1. Basic information Use case name · Short description · Unique ID · Date created · Last updated · Author / owner

[2370] 2. Problem & purpose Problem / opportunity · Purpose & objectives · Success criteria

[2373] 3. Users & context Primary user groups · Who benefits · Operating context / environment · Geography / organisation

[2376] 4. Solution & capability AI capability / agent type · Key features / functions · How it works (high level) · Human oversight points

[2379] 5. Data & information Key data sources · Type of data · Data sensitivity · Information governance

[2382] 6. Implementation & integration Platform / technology · Systems / tools integrated · Deployment model · Date went live / expected · Resource requirements

[2385] 7. Outcomes & value Quantitative outcomes (measured) · Qualitative outcomes (observed) · Value delivered (how & for whom)

[2388] 8. Costs & financials Cost model (licence, usage, etc.) · Estimated / actual cost · Cost per user / transaction · Ongoing cost considerations · Funding source / owner

[2391] 9. Risks & assurance Key risks · Mitigations in place · Assurance / evaluation approach

[2394] 10. Evidence & validation Evidence summary · Evidence sources · What evidence is available (performance results, user feedback, evaluation report, audit / review, other)

[2397] 11. Limitations & lessons Known limitations / constraints · Lessons learned / recommendations

[2400] 12. Transferability & reuse Potential for reuse (high / medium / low) · Reusable artefacts available · Transferability notes

[2403] 13. Lifecycle & review Lifecycle stage (ideation, pilot, live, scaled, retired) · Review frequency · Next review date · Sunset / retirement plan

## Evidence strength [2407]

[2409] Strong — Independently validated

[2411] Medium — Reported results with some validation

[2413] Emerging — Pilot / early indications

[2415] Weak — Unverified claims

[2417] Unknown — Insufficient evidence

## Evidence status [2420]

[2421] Live / in use Pilot / trial Planned Retired / stopped Unknown

## Worked, failed and unproven [2427]

[2428] Sharing the full picture — successes, failures and emerging ideas — so we learn faster and build smarter. Transparent evidence helps the public sector avoid repeating mistakes and scale what works. The cases below are illustrative.

[2431] Worked — repeatable success

[2432] Evidence shows value, quality and user benefit.

## Case: ACAS 'Haste' helpline knowledge assistant [2433]

[2434] Helps advisers quickly find accurate, impartial information during calls.

## What worked [2435]

[2437] Grounded in authoritative, approved and consistent formats

[2438] Tested with 1,000 differently worded questions

[2439] High accuracy and consistency across impartiality and bias checks

[2440] Clear roles, assistant, not decision maker

[2441] Positive adviser feedback and time savings

## Outcomes [2442]

[2444] Faster information retrieval

[2445] Improved accuracy and consistency

[2446] Better adviser experience

[2447] Scalable to wider teams

[2449] Failed — learned & corrected

[2450] Initial attempt did not deliver — lessons captured and applied.

## Case: AI-assisted NHS document processing [2451]

[2452] Automated extraction from clinical documents produced high initial error rate.

## What went wrong [2453]

[2455] Poor data quality and inconsistent document formats

[2456] Incomplete metadata and missing context

[2457] Model hallucinations and incorrect extractions

[2458] Insufficient validation and no independent review loop

[2459] Rushed from prototype to wider use

## What we did next [2460]

[2462] Reduced manual re-keying and error tracking

[2463] Good accuracy in structured readings

[2464] Went back with clear agendas and permissions

[2465] User trust and change impact still being assessed

[2466] Scalability and cost model not yet validated

[2468] Unproven — promising, not yet validated

[2469] Early potential identified — evidence still limited.

## Case: Agent automatically summarises meeting action agent [2470]

[2471] Summarises meeting decisions, actions and sends updates to owners.

## What we know so far [2472]

[2474] Long-term testing across teams and meeting types

[2475] Long-term accuracy and retention unknown

[2476] Cost at scale and return on investment not established

[2477] Governance and data sensitivity assessments in progress

## Next steps [2478]

[2479] Extended pilot, independent evaluation, costing and governance review before scaling

[2481] Data quality and validation are critical

[2482] Human review and iterative testing prevent scale of error

## How we succeed together [2484]

[2485] Share openly, including failures Ground in authoritative sources Test with real users Measure impact and value Capture lessons and publish patterns Reuse and continuously improve

## Four proven delivery patterns [2492]

[2493] Each pattern is a pipeline with human oversight built in — not a single tool. Use them as the starting shape for a new use case.

## Meeting intelligence pipeline [2495]

[2496] Transforming conversations into decisions, actions and organisational memory

[2497] 1. Meeting planning 2. Consent & capture 3. Transcript creation 4. AI processing & summarisation 5. Decisions & actions 6. Risks & insights 7. Distribution & integration 8. Organisational memory

## Authoritative knowledge assistant [2507]

[2508] Delivering trusted, accurate answers grounded in authoritative sources, with human expertise in the loop

[2509] 1. Define need 2. Retrieve 3. Evaluate & ground 4. Generate response 5. Human review 6. Deliver answer 7. Feedback & learn 8. Maintain sources

## AI-assisted engineering lifecycle [2519]

[2520] Secure. Quality. Production-ready. Human in control.

[2521] 1. Discover & plan 2. Architect & design 3. Build & code 4. Test & validate 5. Review & assure 6. Deploy & release 7. Operate & monitor

## AI-assisted programme & portfolio management [2530]

[2531] Smarter oversight. Better decisions. Greater impact.

[2532] 1. Capture & ingest 2. Analyse & understand 3. Plan & optimise 4. Monitor & track 5. Decide & recommend 6. Collaborate & execute 7. Learn & improve

[2540] Back to the contents · Suggest a correction (opens GitHub)

[2552] Decide and prioritise · public sector case library

## What central, local and devolved government has already done [2553]

[2554] Sourced cases from central government, councils, the Scottish, Welsh and Northern Ireland governments and health bodies. Each carries its source and an evidence grade. Supplier-published figures stay graded as reported.

[2558] Central government · Generative Corroborated

## Humphrey: Consult, Parlex, Minute, Redbox and Lex [2562]

## DSIT · i.AI, now part of GDS [2563]

[2564] A package of AI tools for civil servants: consultation analysis, parliamentary search, meeting transcription, document summarisation and legal research.

[2565] Governance lesson: Consult was tested on past consultations before live use.

## Source: UKAuthority ↗ [2567]

[2569] Central government · Generative Verified

## Extract: digitising planning documents [2573]

## i.AI with MHCLG [2574]

[2575] Extract digitises planning documents. Early testing completed a one-to-two-hour manual task in under a minute.

[2576] Governance lesson: Check extraction against the source before it feeds planning decisions.

## Source: Roadmap for modern digital government ↗ [2578]

[2580] Devolved: Scotland · Generative Verified

## Consult tested live on a Scottish Government consultation [2584]

## i.AI with the Scottish Government [2585]

[2586] The first live test of Consult used a Scottish Government consultation, followed by several other government consultations.

[2587] Governance lesson: Compare AI theming with human analysts before relying on it.

## Source: Roadmap for modern digital government ↗ [2589]

[2591] Local government · Generative Verified

## Minute trialled in frontline local services [2595]

## i.AI [2596]

[2597] Minute, a transcription and summarisation tool, was trialled in frontline local services in July 2025.

[2598] Governance lesson: Settle consent and retention for recordings before a trial starts.

## Source: Roadmap for modern digital government ↗ [2600]

[2602] Local government · Generative Verified

## Magic Notes in adult social care [2606]

## Kingston Council with Beam [2607]

[2608] Piloted AI recording and summarising of assessments to free social workers for direct care.

[2609] Governance lesson: A DPIA examined data flows, storage and access. The privacy notice was updated and practitioners get consent to record.

## Source: Local Government Association ↗ [2611]

[2613] Local government · Generative Reported

## Magic Notes scaled to over 1,000 staff [2617]

## Kent County Council [2618]

[2619] After 29 practitioners piloted the tool, more than 1,000 frontline staff use it. An evaluation reported seven hours a week saved on average.

[2620] Governance lesson: Figures are supplier-published. Validate locally before using them in a business case.

## Source: techUK ↗ [2622]

[2624] Local government · Generative Verified

## Service-level privacy notice for AI transcription [2628]

## Hartlepool Borough Council [2629]

[2630] A privacy notice for Magic Notes in adult social care sets out purposes, legal basis and rights.

[2631] Governance lesson: A published, service-level privacy notice is a reusable transparency artefact.

## Source: Hartlepool Borough Council ↗ [2633]

[2635] Local government · Generative Corroborated

## AI recording in adult social care [2639]

## Swindon Borough Council [2640]

[2641] Piloted AI to improve the quality and speed of recording assessment conversations.

[2642] Governance lesson: Evaluate quality of the record, not only time saved.

## Source: Socitm ↗ [2644]

[2646] Local government · Declarative Verified

## Data & Analytics Board for data and AI governance [2650]

## Belfast City Council [2651]

[2652] Set up a Data & Analytics Board to oversee data and AI governance, alongside a council-wide generative AI policy and staff training.

[2653] Governance lesson: Data and AI governance sit under one board.

## Source: Belfast City Council ↗ [2655]

[2657] Devolved: Scotland · Agentic Verified

## Scotland’s AI Strategy 2026–2031 [2661]

## Scottish Government [2662]

[2663] Published 20 March 2026. An eight-layer “AI Stack” and a data matchmaking pilot for trusted public-sector datasets by 2027.

[2664] Governance lesson: Public-sector AI use is made visible through the Scottish AI Register.

## Source: gov.scot ↗ [2666]

[2668] Devolved: Scotland · Generative Verified

## AI guidance on the Digital Scotland Service Manual [2672]

## Scottish Government Public Sector AI Team [2673]

[2674] A suite of AI guidance and resources published on the Digital Scotland Service Manual in August 2026.

[2675] Governance lesson: Guidance lives in the service manual teams already use.

## Source: Digital Scotland blog ↗ [2677]

[2679] Devolved: Wales · Generative Verified

## AI Cymru: the AI Plan for Wales [2683]

## Welsh Government [2684]

[2685] AI adoption across health, education and local government, with a commitment that AI works equally well in Welsh and English.

[2686] Governance lesson: Public bodies assess risks to vulnerable groups and consider offline users.

## Source: gov.wales ↗ [2688]

[2690] Devolved: Wales · Generative Reported

## Office for AI finds duplicated AI work [2694]

## Welsh Government Office for AI [2695]

[2696] A baselining exercise found public bodies duplicating AI work. The office now coordinates adoption and says not every pilot should go live.

[2697] Governance lesson: Duplication is a governance failure; a shared register and reuse check fix it.

## Source: Resultsense via UKAuthority ↗ [2699]

[2701] Devolved: Wales · Agentic Reported

## Senedd research on generative AI and agents [2705]

## Senedd Research [2706]

[2707] A briefing on generative AI in Welsh public services covers inaccurate outputs, discrimination, privacy and the added security and accountability challenges of AI agents.

[2708] Governance lesson: Agent autonomy brings separate security and accountability questions.

## Source: Think Digital Partners ↗ [2710]

[2712] Health · Generative Reported

## AI scribing in children’s neurodevelopmental services [2716]

## Cwm Taf Morgannwg University Health Board with CDPS [2717]

[2718] A pilot assessing whether AI scribing reduces clinicians’ administrative workload.

[2719] Governance lesson: Pilot and evaluate before scaling clinical documentation tools.

## Source: BusinessIn Wales ↗ [2721]

[2723] Devolved: Northern Ireland · Agentic Verified

## Draft Northern Ireland AI Strategy [2727]

## The Executive Office [2728]

[2729] Consultation from 12 August to 7 October 2026. Eight principles include human oversight, accountability and redress, and data governance.

[2730] Governance lesson: Proposes human oversight teams, a cross-sector AI governance board and inventories of AI projects.

## Source: Executive Office ↗ [2732]

[2734] International comparator · Generative Corroborated

## Guidelines for AI in the public service [2738]

## Government of Ireland [2739]

[2740] Advises against free generative AI tools because information given to them could be used for training.

[2741] Governance lesson: A clear position on consumer tools reduces shadow AI.

## Source: RTÉ ↗ [2743]

[2744] 17 cases in the library. Gathered from public sources on 19 October 2026. Re-check each source before citing it.

[2745] Back to the contents · Suggest a correction (opens GitHub)

[2757] Responsible AI · assess a use case

## Classify first, then answer only what your tier needs [2758]

[2759] As AI can see more, do more and act more independently, the assurance required rises. Criticality & gates scores the service impact; this chapter sets the route from what the AI itself can do.

[2764] Class

## 1. Ask [2766]

[2768] Answer and assist

[2769] Provides information, answers or summaries based on a prompt.

[2770] Example: Ask about a policy or summarise a document.

## 2. Create [2773]

[2775] Generate content

[2776] Creates new content, analysis, images or code.

[2777] Example: Draft a briefing, a presentation or code.

## 3. Connect [2780]

[2781] Use organisational information

[2782] Retrieves and works with data from organisational sources and external systems.

[2783] Example: Search SharePoint or analyse internal data.

## 4. Act [2786]

[2788] Take actions

[2789] Makes changes in systems, files or records, or triggers workflows.

[2790] Example: Create a record, send an email or start a process.

## 5. Delegate [2793]

[2795] Complete multi-step work

[2796] Plans and performs several steps with tools and limited supervision.

[2797] Example: Research, analyse, write a report and share it.

## 6. Persist [2800]

[2802] Operate proactively

[2803] Runs autonomously or on a schedule, monitoring and acting over time.

[2804] Example: Monitor changes, raise tickets or act on triggers.

## Information access [2807]

[2809] User-provided only

[2810] User-provided only

[2811] Organisational sources

[2812] Organisational and system

[2813] Multiple sources and tools

[2814] Ongoing and broad

## System access [2816]

[2818] None

[2819] None

[2820] Read (typically)

[2821] Read and write

[2822] Multiple systems

[2823] Multiple systems, scheduled

## Autonomy [2825]

[2827] User led

[2828] User led

[2829] User led

[2830] User led, with action

[2831] Partial autonomy

[2832] High autonomy

## Persistence [2834]

[2836] Single interaction

[2837] Single interaction

[2838] Single or repeated use

[2839] Repeated use

[2840] Multi-step tasks

[2841] Continuous or scheduled

## Human oversight [2843]

[2845] Review output

[2846] Review output

[2847] Review output and sources

[2848] Review before or after action

[2849] Ongoing oversight

[2850] Defined oversight and monitoring

## Assurance depth [2852]

[2854] Lightweight

[2855] Lightweight

[2856] Standard

[2857] Enhanced

[2858] High

[2859] Specialist

## Generative, declarative and agentic: the three capability types [2860]

[2861] The capability classes say what the AI can do; the capability type says how it is built. Both set the assurance.

[2862] goes deeper on choosing between them.

## Generative [2867]

[2868] Creates content in response to a prompt: text, summaries, images or code. A person decides what happens next.

## Declarative [2872]

[2873] Configured, not coded. Purpose, instructions, knowledge and permitted actions are declared; the platform supplies the model and orchestration.

## Agentic [2877]

[2878] Plans and takes actions across tools under delegated authority, choosing its own path to a goal, sometimes on a schedule.

[2884] Class

[2885] Usual capability type

[2886] Minimum assurance

[2889] Ask

[2890] Generative

[2891] Review the output.

[2893] Create

[2894] Generative

[2895] Review the output; label AI involvement.

[2897] Connect

[2898] Generative, grounded · or Declarative with knowledge sources

[2899] Test what the index and connectors expose; review sources.

[2901] Act

[2902] Declarative with actions · or Agentic

[2903] Approval before action; log every action; least-privilege connectors.

[2905] Delegate

[2906] Agentic

[2907] Full agent route: identity, tool permissions, approval points, behavioural tests.

[2909] Persist

[2910] Agentic, scheduled or proactive

[2911] Specialist assurance: defined oversight, monitoring and a kill switch.

## What to assure: Generative [2914]

[2915] Output quality, grounding sources, data entered, transparency labels.

## T3 · T4 · T6 [2916]

## What to assure: Declarative [2918]

[2919] The declared configuration: instructions, knowledge sources, actions, owner, version and publishing scope. Reviewed like code.

## T7 · A2 prompt and skills record [2920]

## What to assure: Agentic [2922]

[2923] The whole human-agent system: identity, tools, approval points, escalation, logs, cost caps and the kill switch.

## T7 · T8 · T10 · agent register [2924]

## Capability and risk classification [2927]

## 1. The most it will do in this use case [2928]

## 2. What raises the stakes [2929]

## 3. Deterministic alternative test [2930]

[2932] Assurance route

## Choose a capability class [2933]

[2934] Start with the most the tool will do in this use case, not the most it could do.

## Assessment questions [2937]

[2939] 0 of 60 answered · 0 concerns · 0 not known

[2942] Feeds: T1 Opportunity Brief · T2 Duplication Check

[2944] What need does the tool meet?

[2945] Is an approved capability already available?

[2946] Is AI necessary?

[2947] Who benefits and who may be adversely affected?

[2948] What evidence supports expected value?

[2949] Can the outcome be evaluated?

[2950] Answers stay in this browser. “Concern” and “Not known” items carry into the decision record as conditions or open questions.

## Decision record outcomes [2951]

## Approve [2954]

[2955] Proceed within the documented scope and controls.

## Approve with conditions [2957]

[2958] Proceed once named conditions are met; conditions are tracked.

## Pilot [2960]

[2961] Controlled authority for a limited population, time and data set.

## Restrict [2963]

[2964] Narrow the users, data or actions permitted.

## Extend [2966]

[2967] Extend a pilot to gather the missing evidence.

## Stop [2969]

[2970] Do not proceed. Record the reason and lessons.

[2971] Back to the contents · Suggest a correction (opens GitHub)

[2983] Criticality & assurance gates

## Usage is not the same as criticality [2984]

[2985] Evaluate across ten dimensions to identify the agents that need stronger governance, assurance and operational support. Score each 1 (very low) to 5 (very high); the total sets the criticality tier and the action.

## 1. Usage & adoption [2989]

[2990] How many people use it and how often?

## 2. Audience & reach [2991]

[2992] Who relies on it? Internal teams, partners, other organisations, or the public?

## 3. Business impact [2993]

[2994] How important is it to achieving business outcomes or service delivery?

## 4. Decision impact [2995]

[2996] Does it influence, recommend or make decisions that have significant consequences?

## 5. Data & information [2997]

[2998] What is the sensitivity, value and regulatory significance of the data it uses or produces?

## 6. Autonomy level [2999]

[3000] How independently can the agent act? Human-in-the-loop versus autonomous.

## 7. Irreversibility [3001]

[3002] How easy is it to reverse an error or unintended action?

## 8. Integration & dependencies [3003]

[3004] How integrated is it with other systems, processes or agents?

## 9. Risk & compliance [3005]

[3006] What are the legal, regulatory, security and reputational risks?

## 10. Public consequence [3007]

[3008] Could failure cause harm, loss of trust or impact citizens?

[3011] CRITICALITY SCORE

[3012] — —

[3015] 0 of 10 dimensions scored

## Score every dimension for a criticality tier. [3016]

## From score to action [3018]

[3019] 12–20 Low Monitor, light governance, owner accountable

## 21–30 [3025]

[3027] Moderate Standard governance, regular review and quality checks

## 31–40 [3031]

[3033] High Enhanced assurance, monitoring, human oversight required

## 41–50 [3037]

[3039] Very high Enterprise governance, formal support, continuity and audit

## Scoring guide [3043]

[3045] 1 Very low — Minimal impact or exposure

[3047] 2 Low — Limited impact or exposure

[3049] 3 Moderate — Noticeable impact or exposure

[3051] 4 High — Significant impact or exposure

[3053] 5 Very high — Critical impact or exposure

## Example agents across tiers [3056]

[3057] Low Personal research assistant used by creator only

[3059] Moderate Team policy search agent used by a department

[3061] High Case triage agent influencing case allocation and actions

[3063] Very high Citizen service agent that makes determinations or commitments

## Key questions to ask [3066]

[3068] Who owns it and is responsible for its use?

[3069] What happens if it gives the wrong answer?

[3070] Where does it get its information from?

[3071] How is it tested, monitored and reviewed?

[3072] Does it support a critical business process?

[3073] Is it shared outside its original team or creator?

[3074] Could it become business or citizen critical?

## Important reminders [3076]

## High usage does not equal high criticality [3077]

## Low usage can still be business critical [3078]

## Reassess regularly as agents, usage and context change [3079]

## When in doubt, apply the higher level of control [3080]

## Right controls at the right level of risk and impact [3081]

[3082] Assurance increases with audience, autonomy, information sensitivity, criticality and consequence. Pick a tier to see the gate required before use.

[3083] Audience Who is affected? Information What data? Autonomy What can it do? Criticality How essential? Consequence What is the impact?

[3095] Tier 2 · Departmental

## Departmental capability · more users, more data [3096]

[3099] Audience Department / multiple teams

[3102] Autonomy Acts with human approval

[3105] Information sensitivity Moderate

[3108] Criticality Medium

[3112] ASSURANCE GATE — REQUIRED BEFORE USE Formal assessment (risk & data review)

## Key controls [3116]

[3118] Data source approval

[3119] Access controls

[3120] Human-in-the-loop

[3121] Quality checks

[3123] Oversight & accountability Business owner + data/info owner

[3126] Evidence & logging Audit log · decisions recorded

[3129] Review frequency Monthly

## Notes on using the tiers [3134]

[3136] Use the lowest tier that achieves the required outcome.

[3137] Reassess tier when usage, data, autonomy or audience changes.

[3138] When in doubt, escalate the risk and apply higher-tier controls.

## Assurance principles [3140]

## Proportionate to risk [3145]

## Risk-based and evidence-led [3149]

## Human oversight at the right level [3153]

## Transparent and explainable [3157]

## Continuously improved [3161]

## Assurance by design, proportionate by risk, continuous by evidence [3162]

[3163] A holistic, cross-disciplinary approach ensuring AI systems and agents are safe, secure, reliable, fair — and deliver public value.

## Assurance domains [3166]

[3167] Security Privacy & data protection Data & information governance Ethics & fairness Transparency & explainability Human oversight & accountability Reliability & safety Evaluation & testing Auditability & evidence Risk management Legal & compliance Accessibility & inclusion

## Applied across the lifecycle [3181]

[3182] 1. Plan & design Define purpose, risks, requirements and success measures

[3184] 2. Build & deploy Develop, test, assure and prepare for secure deployment

[3186] 3. Operate & monitor Monitor performance, risks, usage and emerging issues

[3188] 4. Review & improve Learn from evidence, update controls and improve continuously

## Key assurance questions [3191]

[3193] What are we trying to achieve and for whom?

[3194] What could go wrong and who could be harmed?

[3195] Is the data appropriate, accurate and lawful?

[3196] How will decisions be explained and challenged?

[3197] Can we evidence compliance and responsible use?

[3198] How will we monitor, learn and improve?

## Evidence & assurance artefacts [3200]

[3202] Risk assessments

[3203] Data & DPIA records

[3204] Model cards & evaluations

[3205] Test results & red-team reports

[3206] Decision logs & audit trails

[3207] Policies, standards & guidance

[3208] Change logs & reviews

## The human oversight and accountability chain [3209]

[3210] Agents must operate within clearly defined accountability and oversight boundaries, with named owners and transparent decision trails. Clear accountability at every step; human judgement at the right points.

## Source owner [3214]

[3216] Owns the authoritative information and data made available.

[3217] Ensure accuracy and currency

[3218] Define permitted use

[3219] Manage access and permissions

## Agent owner [3222]

[3224] Owns the agent's purpose, behaviour and operation.

[3225] Define purpose and scope

[3226] Configure behaviour and guardrails

[3227] Monitor performance and usage

## Reviewer [3230]

[3232] Reviews AI outputs, recommendations and actions.

[3233] Validate accuracy and relevance

[3234] Check for bias, risk and compliance

[3235] Decide to approve, edit or escalate

## Decision-maker [3238]

[3240] Accountable for the decision and its consequences.

[3241] Make or authorise the decision

[3242] Consider impact on people and services

[3243] Record the rationale

## Service owner [3246]

[3248] Accountable for the service, outcomes and performance.

[3249] Ensure outcomes are achieved

[3250] Manage risks, incidents and issues

[3251] Provide assurance and improvements

## Audit & redress [3254]

[3256] Provides independent assurance and holds the organisation to account.

[3257] Audit and review activity and controls

[3258] Ensure records, transparency and compliance

[3259] Enable challenge and redress

## Human oversight points [3262]

[3263] 1. Source approval Information is approved for use by the agent.

[3265] 2. Configuration review Agent design and guardrails are reviewed and authorised.

[3267] 3. Output review Outputs are checked for quality, risk and compliance.

[3269] 4. Decision authorisation Final decision is made or authorised by a person.

[3271] 5. Outcome monitoring Outcomes and performance are monitored and reviewed.

[3273] 6. Independent assurance Independent review, audit and redress are available.

## Benefits [3276]

[3277] Clear accountability Better decisions Reduced risk Greater trust Stronger public value

[3283] Back to the contents · Suggest a correction (opens GitHub)

[3295] Maturity & assurance · illustrative frameworks

## Where you are, and how much control that needs [3296]

[3297] Two illustrative frameworks from the capability report: a seven-stage maturity model for organisations, and six assurance tiers for agents. Neither scores named organisations; both are diagnostic tools to calibrate against evidence. Over-control halts adoption; under-control creates unmanaged exposure.

## The seven-stage maturity model [3299]

[3301] Observable evidence at stage 2

[3302] Bounded pilots; named sponsors; temporary funding; largely self-reported benefit evidence.

## Evidence to collect before claiming progression [3303]

[3304] Named owners, repeatable gates, measured outcomes — not licensed tools.

## Leadership & service ownership [3308]

[3310] Named accountable owners, clear outcomes, risk appetite and decision records.

## People & workforce [3313]

[3315] Role-based training, protected learning time, inclusive adoption measures, staff consultation.

## Technology & agents [3318]

[3320] Register, architecture, approved platforms, integrations, autonomy level, observability.

## Data & information [3323]

[3325] Authoritative sources, metadata, permissions remediation, retention, provenance.

## Security & assurance [3328]

[3330] Threat model, DPIA where required, evaluation evidence, incident route, audit logs.

## Commercial & supplier [3333]

[3335] Licensing clarity, usage data, audit rights, exit, substitution, support terms.

## Finance & FinOps [3338]

[3340] Forecasts, showback, anomaly alerts, unit economics, value attribution.

## Community learning [3343]

[3345] Reusable artefacts, supersession, contribution workflow, evidence of reuse.

## Six agent assurance tiers — controls scale with autonomy [3346]

[3347] Bounded autonomy and recoverability adopted from Government of Canada agentic-AI guidance (May 2026).

[3352] Personal assistant Drafting, summarisation and retrieval for one accountable user

[3355] Acceptable-use policy, permissions hygiene, human verification, retention and transparency guidance.

[3360] Personal or team agent Bounded knowledge and repeatable team tasks

[3363] Registered owner, approved sources, test prompts, sharing gate, usage telemetry.

[3368] Departmental reusable agent Multiple teams or a repeatable departmental process

[3371] Business, technical, information, risk and support owners; service level; change control; retirement plan.

[3376] Operational agent Acts on records, workflows or line-of-business systems

[3379] Distinct identity, least privilege, action logging, rollback, incident response, continuous monitoring.

[3384] Citizen-impacting agent Influences access, rights, safety, services or public communication

[3387] Impact assessment, legal basis, accessibility and equality assessment, transparency, redress, independent assurance.

[3392] Autonomous / multi-agent Delegated goals, tools, sub-agents or long-running actions

[3395] Sandboxing, constrained authority, short-lived credentials, kill switch, behavioural monitoring, dependency mapping.

## Tier finder — two questions set the tier at intake [3397]

[3398] What may this agent do without asking, and what can be undone when it goes wrong?

[3399] Back to the contents · Suggest a correction (opens GitHub)

