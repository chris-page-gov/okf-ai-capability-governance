---
type: publisher-section
title: Design and build
status: draft
sources:
- title: Design and build
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-design-and-build
x-dom-section: part-design-and-build
---

# Design and build

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-design-and-build)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[3408] Part 3 of 12 · 8 chapters

## Design and build [3409]

[3418] Responsible AI · implement AI

## Twelve stages, twelve gates, one evidence chain [3419]

[3420] Each stage answers one question, produces one artefact and passes one gate. Select a stage to filter the templates. The Agent journey chapter follows a single agent through the same path.

[3422] Explore Assess and design Deploy and enable Operate and evolve

[3428] Key gates

[3430] Validated need Stage 1

[3433] Reuse decision Stage 2

[3436] Assessment approval Stage 4

[3439] Pilot authority Stage 6

[3442] Deployment approval Stage 9

[3445] Continued authority Stage 10

[3448] Closure confirmed Stage 12

## Where each phase lives, what it produces, who does it [3451]

[3457] Portal section

[3458] Key outputs

[3459] Primary roles

[3462] Start here

[3463] Opportunity brief · initial questions · support and contact

[3464] All colleagues

[3466] Find an AI tool

[3467] Catalogue search · tool comparison · reuse decision

[3468] Users · IT and digital

[3470] Assess a use case

[3471] Risk classification · data and privacy assessments · supplier and model review · approval record

[3472] Project team · risk, security, privacy · data and information

[3474] Implement AI

[3475] Design record · pilot plan · evaluation report · deployment checklist

[3476] Product owner · technical team · users and change leads

[3478] Operate and monitor

[3479] Usage, cost and outcome data · incident and risk records · change-impact assessments · continuous improvement

[3480] Service owner · operational support · governance and assurance

[3482] Learn and reuse

[3483] Lessons learned · updated guidance · patterns and templates · retirement record

[3484] All teams · community of practice · centre of excellence

## Templates and artefacts · 12 core, 7 added [3485]

[3488] T1 · Core · stage 1

## AI Opportunity Brief [3489]

[3491] Reference, title, owner and team

[3492] Problem evidence and affected users

[3493] Current process and non-AI options

[3494] Desired outcome and success measures

[3495] Inputs, outputs, decisions and systems

[3496] Accessibility need, urgency and constraints

[3498] T2 · Core · stage 2

## Existing-Capability and Duplication Check [3499]

[3501] Required capability

[3502] Catalogue and pattern searches

[3503] Existing tools, agents, prompts and skills reviewed

[3504] Gap and configuration assessment

[3505] Reuse, extend, build or buy rationale

[3506] Decision and consulted owners

[3508] T3 · Core · stage 3

## Capability and Risk Classification [3509]

[3511] Ask, Create, Connect, Act, Delegate, Persist

[3512] Information sensitivity and personal data

[3513] System access and autonomy

[3514] Consequential decisions and vulnerable users

[3515] Scale, reversibility and public visibility

[3516] Risk tier and assurance route

[3518] T4 · Core · stage 4

## Information and Data Readiness Assessment [3519]

[3521] Sources, owners and classification

[3522] Personal data and DPIA needs

[3523] Permissions and business need

[3524] Metadata, filenames, titles and indexing

[3525] Quality, authority, retention and deletion

[3526] Traceability, aggregation and training use

[3528] T5 · Core · stage 4

## Supplier, Model and Deployment Assessment [3529]

[3531] Supplier, edition and deployment route

[3532] Models, provider and automatic selection

[3533] Subprocessors, locations and retention

[3534] Contract, policy and admin controls

[3535] Logging, change notice and deprecation

[3536] Exit plan and unresolved uncertainties

[3538] T6 · Core · stage 4

## Responsible AI and Human Oversight Assessment [3539]

[3541] Task and decisions affected

[3542] Reviewer, competence and evidence access

[3543] Uncertainty, challenge and override

[3544] Automation bias and prohibited uses

[3545] Failure, refusal and conflict handling

[3546] Redress and oversight effectiveness

[3548] T7 · Core · stage 5

## Agent Design Record [3549]

[3551] Purpose, owner, identifier and status

[3552] Model, instructions, skills and knowledge

[3553] Identity, permissions, tools and credentials

[3554] Triggers, schedules, actions and other agents

[3555] Approval points, escalation and stopping

[3556] Tests, logging, monitoring, kill and review

[3558] T8 · Core · stage 6

## Pilot Plan [3559]

[3561] Hypothesis, population, duration and environment

[3562] Permitted data and tasks, and exclusions

[3563] Support and training

[3564] Quality, accessibility, cost, trust and risk measures

[3565] Comparison and baseline design

[3566] Stop criteria and evidence ownership

[3568] T9 · Core · stage 7

## Evaluation and Benefits Record [3569]

[3571] Outcomes, quality and reliability

[3572] Accessibility, wellbeing and user outcome

[3573] Time, review and rework

[3574] Cost, adoption and sustainability

[3575] Unintended effects and limitations

[3576] Evidence status and recommendation

[3578] T10 · Core · stage 9

## Deployment Readiness Checklist [3579]

[3581] Catalogue and ownership

[3582] Assessments and approvals

[3583] Permissions and indexing tests

[3584] Oversight and accessibility

[3585] Guidance, support and monitoring

[3586] Incident, kill, retention, review and retirement

[3588] T11 · Core · stage 11

## Change-Impact Assessment [3589]

[3591] Trigger: model, supplier, data, permission, action, interface, cost or policy

[3592] Impact on risks and controls

[3593] Evidence and documents to update

[3594] No, partial or full reassessment

[3595] Continue, restrict, suspend or retire decision

[3597] T12 · Core · stage 12

## Retirement Record [3598]

[3600] Reason and replacement

[3601] User communication

[3602] Disable agents and actions, and revoke access

[3603] Disconnect integrations and dispose of data

[3604] Update records and supplier access

[3605] Residual risks, lessons and closure approval

[3607] A1 · Added · stage 9, 10

## Adoption and capability plan [3608]

[3610] Senior sponsor and local champions

[3611] Protected learning time

[3612] Local communications

[3613] Accessible training and reinforcement

[3614] Support

[3616] A2 · Added · stage 5, 10

## Prompt and skills product record [3617]

[3619] Owner, version and purpose

[3620] Approved users

[3621] Test set and security checks

[3622] Cost profile

[3623] Retirement

[3625] A3 · Added · stage 5, 9

## Support and service record [3626]

[3628] Support route and service dependencies

[3629] Escalation

[3630] Known limitations

[3631] Incident response

[3632] Service-level position

[3634] A4 · Added · stage 6, 7

## Comparative task-test template [3635]

[3637] Baseline tool versus proposed capability

[3638] Task, time and cost

[3639] Review effort and output quality

[3640] Failure modes

[3641] Accessibility

[3643] A5 · Added · stage 4, 7

## Ways-of-working impact assessment [3644]

[3646] Delegation and role development

[3647] Workload and meeting volume

[3648] Professional review

[3649] Change-management effects

[3651] A6 · Added · stage 5, 9

## Guest and cross-tenant access plan [3652]

[3654] Resource location

[3655] Permissions

[3656] Alternate access route

[3657] Accessible distribution

[3659] A7 · Added · stage 11

## Release and guidance change record [3660]

[3662] Product terminology and screenshots

[3663] Training assets

[3664] Affected audiences

[3665] Communication date

[3666] Back to the contents · Suggest a correction (opens GitHub)

[3678] Design and build · capability classes

## Generative, agentic and declarative [3679]

[3680] Three ways of using the same underlying models, with different failure modes and therefore different controls. Most real deployments combine all three, which is exactly why the class needs naming before the controls are chosen.

## Generative [3683]

[3684] Produces content, analysis or options on request. Nothing changes until a person acts on the output.

[3685] You specify: A prompt, grounding sources and an output format.

[3687] Drafting, summarising, translating Analysis and option generation Search and question answering Code and test generation

[3694] Primary failure Plausible but wrong output accepted without review. Tier tendency Usually low to moderate: consequence sits with the person who acts on the output.

[3698] Controls that carry the weight

[3700] Accuracy and grounding evaluation

[3701] Citation and provenance

[3702] Disclosure that AI was used

[3703] Human review before use

## Agentic [3705]

[3706] Takes actions across tools and systems under delegated authority, deciding its own path to a goal.

[3707] You specify: A goal, tools, permissions, guardrails and approval thresholds.

[3709] Triage and routing Multi-step workflow execution System updates within limits Orchestration across services

[3716] Primary failure Correct-looking action taken outside intended scope, or an irreversible action taken without approval. Tier tendency Moderate to high: the agent itself changes the world, so authority and reversibility dominate.

[3720] Controls that carry the weight

[3722] Capability separated from authority

[3723] Least-privilege permissions and recertification

[3724] Approval gates for consequential actions

[3725] Full action logging and rollback

## Declarative [3727]

[3728] You state the outcome, rules and boundaries; the platform resolves how they are met and keeps behaviour inside the declaration.

[3729] You specify: Instructions, knowledge sources, permitted actions and constraints — as configuration, not code.

[3731] Configured assistants defined by a manifest Policy and rules expressed as configuration Low-code flows with declared triggers Templated agents published to a team

[3738] Primary failure The declaration drifts from intent, or nobody owns the specification that is now running in production. Tier tendency Varies with what is declared: the specification is the control surface, so review it as you would code.

[3742] Controls that carry the weight

[3744] Version control over the declaration

[3745] Named owner for the specification

[3746] Change assessment on every edit

[3747] Regression tests against the declared outcome

## Side by side [3748]

[3749] Generative Agentic Declarative

[3753] What you supply Prompt and sources Goal, tools and authority Instructions, sources and constraints

[3758] Who chooses the path The person The agent, within guardrails The platform, within the declaration

[3763] What changes Nothing until a person acts Systems and records directly Whatever the declaration permits

[3768] Primary failure Wrong content believed Wrong action taken Wrong specification running

[3773] Assurance emphasis Output quality and provenance Permissions, approval and rollback Change control over the declaration

[3778] Register fields that matter most Sources, evaluation, review point Permitted actions, authority level, escalation Version, owner, constraints, publication scope

## Which class is this? [3783]

[3784] Three questions. The answer sets the controls that matter most — not whether the work is allowed.

## Does it change anything outside the conversation? [3786]

## Who decides the steps? [3787]

## Can its effects be undone without a person? [3788]

## Most deployments are all three at once [3789]

## Declarative shell [3792]

[3793] The declaration sets purpose, sources, permitted actions and limits — and is the artefact under change control.

## Generative core [3795]

[3796] Inside those limits, the model drafts, summarises and reasons; evaluation and provenance apply here.

## Agentic actions [3798]

[3799] Only declared actions run, each with its permission, approval threshold and audit trail.

[3801] Record the class in the register alongside purpose and authority. It tells a reviewer which controls to look for before they open the evidence — and it makes the difference between an agent that drafts and an agent that acts visible without reading the configuration.

[3802] Back to the contents · Suggest a correction (opens GitHub)

[3814] Skill studio · modular instruction block

## Build the instruction. Inject the skill. [3815]

[3816] A reusable way to brief any assistant: seven parts, a directives layer that always applies, validation that is always on, and a library loop so good prompts get kept, shared and versioned — not rediscovered.

## The block — seven parts [3820]

[3821] Skill focus — pick any

[3824] System directives — always applied

[3825] Be accurate & truthful Be helpful & relevant Be safe & secure Be fair & inclusive Cite sources when possible Declare limits & assumptions

[3833] Assembled block

[3834] SYSTEM DIRECTIVES: be accurate and truthful; be helpful and relevant; be safe and secure; be fair and inclusive; cite sources when possible; declare limits and assumptions.

[3836] Validation — always on · 0 of 8 passed

[3839] Governance & safety rails

[3840] Confidentiality & privacy. respect data boundaries and permissions

[3842] Security & compliance. follow policies, standards and legal requirements

[3844] Trust & transparency. show reasoning, sources and confidence levels

[3846] Fairness & non-discrimination. avoid bias; promote equity and inclusion

[3848] Human oversight. AI supports; humans decide and take accountability

[3850] Monitoring & audit. logs, reviews, feedback and continuous improvement

[3853] Risk & harm prevention

[3854] Misinformation Privacy breach Overreliance Bias & exclusion Unsafe content Hallucination

[3861] DEIA considerations

[3862] Accessibility by design Inclusive language Cultural & regional awareness Multiple perspectives Bias detection & mitigation Cognitive load & readability

[3871] Learning & improvement loop

## Use [3874]

[3875] Apply the prompt in real work

## Review [3877]

[3878] Evaluate output and experience

## Refine [3880]

[3881] Improve prompt and instructions

## Capture [3883]

[3884] Add to library; share learnings

## Evolve [3886]

[3887] Retire, update or version prompts

[3888] The reusable library holds role-based, task-based and domain prompts, scenario templates, anti-pattern examples — tested and versioned, with supersession history.

[3890] Success signals

[3891] Useful Trusted Inclusive Accessible Traceable Actionable Impactful

[3899] Principles at the core: human-centred · inclusive by design · transparent · accountable · reliable · respectful · secure · sustainable · equitable.

[3900] Back to the contents · Suggest a correction (opens GitHub)

[3912] Responsible AI · agents and skills

## Assure the whole human-agent system, not only the output [3913]

[3914] What starts an agent, how it plans, what it can reach, where people stay in control, and what it leaves behind. Skill studio builds the instruction block; Autonomy boundaries sets the limits.

## 1. Trigger [3918]

[3919] What starts the agent?

[3921] User request

[3922] Scheduled task

[3923] Event: new email, meeting or file

[3924] System trigger: ticket or alert

[3925] API or webhook

[3926] Another agent

## 2. Agent core [3928]

[3929] How it thinks, plans and decides

[3931] Instructions and goals: system prompt, skills, guardrails

[3932] Model: chosen models and settings

[3933] Knowledge and context: organisational data, memory, external sources

[3934] Reasoning and orchestration: plans tasks, selects tools, handles errors

## 3. Tools and actions [3936]

[3937] What it can reach and do

[3939] Search and retrieve across approved sources

[3940] Call APIs and applications

[3941] Delegate to other agents

[3942] Create and update content, records, messages and code

## 4. Human oversight [3944]

[3945] Where people stay in control

[3947] Approval before high-risk actions

[3948] Review and validation of outputs and sources

[3949] Challenge and feedback

[3950] Stop or override at any point

## 5. Outcome [3952]

[3953] What it delivers

[3955] Completed task or output

[3956] System update or action taken

[3957] Notification or communication

[3958] Log and evidence: what happened, when and why

## Cross-cutting control rails [3959]

## Identity and permissions [3962]

[3963] Who the agent is and what it can reach

## Information and data controls [3965]

[3966] Classification and retention

## Monitoring and logging [3968]

[3969] Activity, actions and decisions

## Cost and consumption [3971]

[3972] Budgets, limits and alerts

## Security and privacy [3974]

[3975] Risks, DPIA and incident response

## Accessibility and inclusion [3977]

[3978] Usable for all

## Sustainability [3980]

[3981] Environmental impact

## Kill switch and retirement [3983]

[3984] Stop and close safely

## Risks the agent route must test [3985]

## Prompt and skill supply chain [3988]

[3989] A shared skill or instruction changed without review changes every agent that loads it.

[3990] Proposed

## External input and prompt injection [3992]

[3993] Documents, web pages and emails can carry instructions that redirect the agent.

[3994] Proposed

## Identity, delegation and shared accounts [3996]

[3997] Agents acting through shared or delegated contexts can reach more than the requester could.

[3998] Reported

## Unexpected discovery [4000]

[4001] Permissions alone may not stop titles, filenames and metadata surfacing through the index.

[4002] Reported

## Multi-agent orchestration [4004]

[4005] Agents calling agents need identity, approval points and automated records at each hop.

[4006] Reported

## Telemetry gaps [4008]

[4009] Agent activity logs may not show enough to reconstruct what happened.

[4010] Reported

## Continuous assurance [4011]

[4013] 1. Test before deployment Behaviour, safety and access

[4016] 2. Monitor in operation Usage, outcomes and incidents

[4019] 3. Learn and improve Feedback and evaluation

[4022] 4. Reassess on change Model, tools, data and permissions

[4025] 5. Retire when no longer needed Revoke access, close data, capture lessons

## Prompts and skills as organisational products [4030]

[4031] A personal prompt stays personal. Once a prompt, skill or agent instruction is shared, it needs an owner, a version, a test set, security checks, a cost profile and a retirement date, and it goes in the prompt and skills register.

[4033] Is the prompt or skill personal or organisational?

[4034] Does it need version control and approval?

[4035] Has it been tested for safety, consistency and cost?

[4036] Could deterministic automation do the job better?

[4037] Can it be shared or changed without review?

[4038] How will it be withdrawn?

[4040] Deterministic alternative test

## Before building a generative skill or agent, check whether conventional automation is safer, cheaper and more consistent. [4041]

[4042] If a rule, form, flow or script can do the job reliably, use it. Generative AI earns its place where judgement over unstructured material is the actual task.

[4043] Back to the contents · Suggest a correction (opens GitHub)

[4055] Design and build · connectors, MCP and integrations

## Every connector is a new data path and, often, a new action [4056]

[4057] MCP servers, connectors, plugins, add-ins and APIs turn a generative tool into one that can reach, and change, other systems. Each needs an owner, a scope and a log.

[4063] MCP server An open-protocol endpoint that exposes tools and resources to any MCP-capable client. Tools can be discovered at runtime, so capability can change without the agent being republished.

[4068] Connector Brings an external system’s content into an AI tool’s index or grounding, such as Copilot connectors.

[4073] Plugin or action A packaged custom action, such as an MCP or API plugin in a declarative agent, that lets an agent read or change data.

[4078] Add-in or app An extension that runs inside a host application, such as an Office add-in or a chat app.

[4083] API and webhook Direct integration through REST APIs, OpenAPI descriptions or event webhooks.

[4088] Integrator or gateway A platform that brokers many connections, applies policy and logs traffic, such as an MCP gateway or integration platform.

## Platform directory [4090]

[4091] Graded claims from supplier documentation. Where a route is unresolved, confirm it with the supplier before connecting.

[4094] Microsoft 365, Copilot and Copilot Studio Verified

[4097] Declarative agents call MCP servers and REST APIs through MCP and API plugins. Copilot Studio adds MCP servers through an onboarding wizard, and servers can be registered in Agent 365.

## Routes: MCP plugin · API plugin · Copilot connectors · Power Platform connectors [4098]

[4100] Controls: Tools are discovered at runtime unless pinned in the manifest. Register MCP servers in Agent 365 and review each tool’s read and write scope.

## MCP and API plugins for declarative agents ↗ [4102]

## Connect Copilot Studio to an MCP server ↗ [4103]

## Declarative agents for Microsoft 365 Copilot ↗ [4104]

[4107] GitHub Verified

[4110] GitHub maintains a remote MCP server for repositories, issues and pull requests. Microsoft’s walkthrough wraps it as a plugin in a declarative agent.

## Routes: Remote MCP server · GitHub Apps · Actions [4111]

[4113] Controls: One OAuth app per organisation, repositories scoped, no write tools without approval, and no secrets in prompts.

## Build a declarative agent plugin from the GitHub MCP server ↗ [4115]

## Atlassian: Jira, Confluence, Jira Service Management, Bitbucket, Loom [4120]

[4122] Corroborated

[4123] The official Rovo MCP server reached general availability on 4 February 2026. It is cloud-hosted and authenticates with OAuth 2.1 or API tokens.

## Routes: Remote MCP server, v2 endpoint · Rovo agents [4124]

[4126] Controls: Admins choose which AI tools and domains may connect, destructive tool groups stay off until enabled, and every tool call is written to the audit log. Atlassian Cloud only, not Data Center.

## Getting started with the Rovo MCP server ↗ [4128]

## atlassian-mcp-server on GitHub ↗ [4129]

[4132] Anthropic Claude Reported

[4135] Claude connects to Microsoft 365 and other systems through connectors built on MCP. Its Microsoft 365 connector reads Outlook, Teams, SharePoint and OneDrive and writes to the last two.

## Routes: Connectors · remote MCP servers · Skills [4136]

[4138] Controls: Set connector write scope per user, keep an admin allow-list, and record each connector in the data-source register.

[4140] No verified documentation linked yet.

[4143] Google Workspace and Gemini Unresolved

[4146] Gemini works with Workspace content and connected data. Confirm the current MCP and extension routes with Google before use.

## Routes: Workspace grounding · extensions · APIs [4147]

[4149] Controls: Confirm data location, admin controls and audit logging for each extension.

[4151] No verified documentation linked yet.

[4154] Slack Unresolved

[4157] Slack can be a source or a destination for agent work. Confirm the official MCP or app route and its data residency before connecting.

## Routes: App · MCP server · webhooks [4158]

[4160] Controls: Scope channels, keep private channels out without approval, and align retention.

[4162] No verified documentation linked yet.

[4165] Service and line-of-business systems Proposed

[4168] ServiceNow, Salesforce, Dynamics 365 and case-management systems publish connectors, APIs or MCP servers. Each is a new data path and a new action surface.

## Routes: Connector · API plugin · MCP server · integration platform [4169]

[4171] Controls: Treat any write tool as Act class, require approval before change, and log to the incident trail.

[4173] No verified documentation linked yet.

[4176] Model Context Protocol, the standard Corroborated

[4179] An open standard that lets an AI client call tools and read resources on an outside system through one interface.

## Routes: Specification · registry · gateways [4180]

[4182] Controls: Prefer official servers, pin tools where possible, review tool descriptions for injected instructions and route calls through a gateway that logs them.

## modelcontextprotocol.io ↗ [4184]

## Nine controls for every connector, plugin and MCP server [4186]

[4188] Register every connector, plugin and MCP server in the tool and data-source registers, with a named owner.

[4189] Record read and write scope separately. Any write tool makes the use case at least Act class.

[4190] Prefer official, supplier-maintained servers over community ones, and record which is in use.

[4191] Pin tools or versions where the platform allows. Dynamic discovery means capability can change without republishing.

[4192] Authenticate with OAuth and least privilege. No shared service accounts for user-level data.

[4193] Log every tool call to an audit trail the service owner can read.

[4194] Review tool descriptions and returned content for prompt injection.

[4195] Check where each connected system stores and processes data, and whether it sits inside your data boundary.

[4196] Keep a revoke route: users can withdraw authorisations and admins can disable a connector at once.

## A connector can change the capability class [4198]

[4199] A generative chat tool with a read connector is Connect class. Add a write tool and it is Act class; let it run on a schedule and it is Persist. Reclassify whenever a connector or tool is added, and record it in the change register.

[4200] Back to the contents · Suggest a correction (opens GitHub)

[4212] Architecture & quality

## Principles with tests, gates with teeth [4213]

[4214] A three-tier canon governs everything that influences how something is built — prototypes explicitly included, because most principle breaches enter the estate through prototypes that were never intended to survive, and then did.

## Tier 1 — mandated, cited not restated [4216]

[4217] T1-01 Secure by Design T1-02 CAF & GovAssure T1-03 Technology Code of Practice T1-04 GDS Service Standard T1-05 AI Playbook T1-06 Data protection & public records T1-07 WCAG 2.2 AA

[4225] Tier 1 conformance is binary: the principle applies and is met, or a recorded exception exists. No informal partial conformance.

## Tier 2 — the core seven, each with a test [4226]

## AP-01 [4229]

## Federated, not centralised [4231]

[4233] Test: Can each element be traced to a named authoritative owner outside the central platform? Looks compliant, is not: "We will federate later, once everything is in one place."

## AP-02 [4238]

## Discovery separated from access [4240]

[4242] Test: Can a user discover an asset exists without thereby gaining access to it? Looks compliant, is not: Endpoint or credential details published as discovery metadata for convenience.

## AP-03 [4247]

## Human-in-the-loop by design [4249]

[4251] Test: Can any automated component write to the record without recorded human approval? Looks compliant, is not: "The user can always review it" — optional review presented as a control.

## AP-04 [4256]

## Traceability & provenance mandatory [4258]

[4260] Test: Take any output at random: can you reconstruct inputs, owner, decision and evidence without asking a person? Looks compliant, is not: Evidence linked at closure rather than at capture.

## AP-05 [4265]

## Reuse before build [4267]

[4269] Test: Is there a recorded reuse assessment that predates the build decision? Looks compliant, is not: Reuse assessment performed after the build decision, to justify it.

## AP-06 [4274]

## Accessible & inclusive by design [4276]

[4278] Test: Is accessibility evidence produced before release? Does every status carry a non-colour cue? Looks compliant, is not: "We will run an accessibility audit before go-live" as the only accessibility activity.

## AP-07 [4283]

## Guardrails enforced, not documented [4285]

[4287] Test: Attempt to breach the control through the normal interface. Does it succeed? Looks compliant, is not: A mandatory gate with no exception path — guaranteeing informal workarounds.

[4290] Prototype promotion gate. A prototype may not be promoted toward live use until Tier 1 and Tier 2 conformance is assessed and recorded. Record intended lifespan and disposal point at creation; record deferred principles; re-assess them at the gate. Human-in-the-loop applies in full even at prototype stage — autonomy introduced early is rarely removed later. Promotion is a decision, not a drift.

## The assurance-gated agentic pattern [4293]

[4294] From the AI Engineering Lab's reference implementation: the transferable innovation is not any one use case — it is the operating model around it. Specialist agents routed by an orchestrator; a challenger agent that reviews outputs; a compliance agent; assurance gates executed in the workflow; immutable audit trails; human approval before anything writes to the record. The same pattern serves capability management, catalogue operations, workforce planning and architecture governance.

[4295] Specialist agents Orchestrator routing Challenger agent Compliance agent Assurance gates in-workflow Immutable audit trail Human approval to write Escalation paths

## The quality gate — score prototypes like you mean it [4304]

[4305] A gate, not a form: run at the end of every iteration. Tier 0 is the brake — the only tier that can argue for less; a veto is the instrument doing its job. Scores are capped by evidence strength, unscoreable items go on an open register published with the score, and demo drift — a level-3 prototype someone useful quietly relies on — is the most common governance failure in this class of work.

[4308] Quick index — ten dimensions, 1–5

## Security [4309]

## Privacy & data protection [4310]

## Accessibility [4311]

## Usability [4312]

## Performance & resilience [4313]

## Maintainability [4314]

## Observability [4315]

## Data quality & provenance [4316]

## Trust & transparency [4317]

## Sustainability & handover [4318]

## — [4321]

## Sophistication index — Σ scores ÷ 50 × 100 [4322]

[4323] Score the dimensions for a reading

[4324] The ladder: Tier 0 proportionality gate → Tiers 1–6 architecture compass → Tier 7 self-* autonomic → Tier 8 human & institutional sustainability. Evidence-rung caps; accessibility floors at human testing, not automated checks; an empty removal ledger three iterations running is itself a Tier 0 veto. Dimensions here are representative — attach the full template for real assessments.

[4326] Back to the contents · Suggest a correction (opens GitHub)

[4338] Knowledge foundation

## From weekly call to institutional memory [4339]

[4340] Transforming conversations into trusted, discoverable knowledge that drives action and public value. Capture once, reuse everywhere — the seven-step pipeline and the record it produces.

## 1. Capture [4344]

## Capture the moment [4345]

[4347] Record meeting

[4348] Capture chat

[4349] Collect shared files

[4350] Note live questions

[4351] Identify demos

## Raw recording, chat and artefacts [4352]

## 2. Transcribe [4354]

## Make it searchable [4355]

[4357] Generate transcript

[4358] Speaker identification

[4359] Time-stamped content

[4360] Redact sensitive information

## Transcript with timestamps [4361]

## 3. Summarise [4363]

## Extract the essence [4364]

[4366] Executive summary

[4367] Key points

[4368] Decisions

[4369] Unresolved questions

[4370] Action items

## Structured summary and outcomes [4371]

## 4. Curate [4373]

## Add context and quality [4374]

[4376] Add metadata and taxonomy

[4377] Link to related topics

[4378] Classify sensitivity

[4379] Verify facts and sources

[4380] Assign owners

## Curated, classified session record [4381]

## 5. Connect [4383]

## Link and enrich [4384]

[4386] Link to use cases, agents and data assets

[4387] Classify sensitivity

[4388] Verify facts and sources

[4389] Assign owners

## Connected knowledge with relationships [4390]

## 6. Publish [4392]

## Make it discoverable [4393]

[4395] Publish to knowledge hub

[4396] Update indexes

[4397] Set permissions

[4398] Notify communities

[4399] Version control

## Discoverable knowledge asset [4400]

## 7. Reuse & learn [4402]

## Drive action and value [4403]

[4405] Apply in projects and services

[4406] Share improvements

[4407] Capture feedback and results

[4408] Update and improve

## Impact, feedback and new learning [4409]

## What we capture [4412]

[4413] Discussions and insights Questions and challenges Decisions and agreements Actions and owners Shared links and resources Demos and use cases Risks and issues Ideas and opportunities Lessons learned

## Enablers of institutional memory [4424]

[4426] Clear governance and ownership

[4427] Consistent metadata and taxonomy

[4428] Security, privacy and access control

[4429] Quality assurance and validation

[4430] Retention and lifecycle management

[4431] Community curation and care

[4432] Usage analytics and feedback

[4433] Integrated tools and platforms

## The benefits [4435]

[4436] Easier to find Searchable, organised knowledge at your fingertips

[4438] Avoid duplication Learn from others' experience and mistakes

[4440] Stronger decisions Better informed choices backed by evidence

[4442] Faster delivery Reuse patterns, guidance and assets to go faster

[4444] Assured and trusted Quality, governance and provenance you can rely on

[4446] Greater public value Better services, outcomes and trust for citizens

## The session evidence pack [4448]

[4449] Twelve components that turn a conversation into a reusable organisational asset. Session record · community owned · governed and secure · discoverable and reusable · continuously improved.

[4454] 1. Session details Title & description · Date, time, duration · Community / forum · Participants & roles · Host / facilitators

[4456] 2. Recording & transcript Recording link · Transcript / captions · Time-stamped version · Accessibility info

[4458] 3. Summary & key points Executive summary · Key discussion points · Important context · What was agreed

[4460] 4. Questions & answers Questions raised · Answers provided · Outstanding questions · Follow-up needed

[4463] 5. Demonstrations & artefacts Demos & walkthroughs · Screens / diagrams · Code / configs · Resources shared

[4465] 6. Decisions & agreements Decisions taken · Agreements reached · Scope confirmations · Changes approved

[4467] 7. Actions & owners Action items · Owners · Due dates · Status / progress

[4469] 8. Linked resources & references Related publications · Previous sessions · External references

[4472] 9. Classification & sensitivity Information classification · Sensitivity level · Handling instructions · Access permissions

[4474] 10. Evidence & insights Evidence referenced · Impact / value assessed · Metrics mentioned · Outcomes expected

[4476] 11. Lessons & insights Key takeaways · Update history · Supersedes / superseded · Recommendations

[4478] 12. Review & lifecycle Review cycle · Update history · Supersedes / superseded · Retention

## How it flows [4482]

[4484] 1. Capture — Capture during or after the session

[4486] 2. Structure — Organise using the standard evidence pack template

[4488] 3. Classify — Apply classification, tags and sensitivity controls

[4490] 4. Publish — Store in governed repositories and make discoverable

[4492] 5. Link — Connect to related assets, agents, use cases, and more

[4494] 6. Reuse — Teams find, reuse and build on the knowledge

[4496] 7. Improve — Feedback and updates improve content continuously

## Evidence status on every claim [4499]

[4500] Verified Independently confirmed

[4502] Reported / emerging Reported by a source, not yet validated

[4504] In progress / unvalidated Being worked through

[4506] Contradictory / needs review Sources disagree

[4508] Outdated / superseded Replaced by newer content

## The knowledge lifecycle [4510]

[4511] Good knowledge is captured once, curated well, reused often and improved continuously — and its status is always visible.

[4514] Create & capture 1. Capture Capture knowledge, evidence and experiences from sessions, projects or operations.

[4518] Create & capture 2. Classify & tag Add metadata, taxonomy, topics, sensitivity and links to related assets.

[4522] Curate & govern 3. Curate & quality Check accuracy, completeness, relevance and quality. Remove duplicates.

[4526] Curate & govern 4. Validate & approve Subject matter and governance review. Approve for use and assign lifecycle status.

[4530] Share & use 5. Publish & discover Publish to trusted repositories and make discoverable through search, portals and APIs.

[4534] Share & use 6. Use & reuse Apply knowledge in work, decisions and services. Share feedback and outcomes.

[4538] Share & use 7. Review & update Review on a regular cycle or when triggered by change. Update content, links, owners and status.

[4542] Share & use 8. Sunset, supersede or archive Retire outdated content, mark as superseded or archive with retention and audit trail.

## Evidence status through the lifecycle [4546]

[4549] Draft Newly captured. Not yet reviewed.

[4552] Reviewed Peer or owner reviewed. Accuracy and relevance checked.

[4555] Validated Approved by subject matter and governance for use.

[4558] Published Officially published and visible to intended audience.

[4561] Superseded Outdated or replaced by newer content. Retained for reference.

[4564] Archived No longer active. Retained in accordance with policy.

## One discovery layer, many trusted sources [4566]

[4567] Information is scattered across teams, tools and tenancies, which causes duplication, inconsistency and poor discoverability. Federate rather than migrate: connect the sources, add a metadata and governance layer, and put one discovery layer on top.

## Today — fragmented and hard to find [4570]

[4571] Chats & calls SharePoint sites Personal OneDrives Email & attachments Departmental file shares GitHub repositories Slack / other channels Knowledge hub Spreadsheets & lists Recordings & transcripts Documents & guidance External links & references

## Target — federated knowledge service [4585]

[4586] Unified discovery layer Single search & navigation · Smart filters & facets · Recommendations & related content · Personalised views

[4588] Metadata & governance layer Common taxonomy · Metadata standards · Classification & sensitivity · Ownership & accountability · Lifecycle management

[4590] Federated source connectors Source systems remain in place — connect, do not migrate

## Tomorrow — connected and valuable [4593]

[4594] Find faster One place to search across the estate with better results

[4596] Trust & assurance Clear ownership, quality signals, classification and provenance

[4598] Reuse & collaborate Easily share, reference and reuse patterns, guidance and code

[4600] Learn & improve Insights and lessons flow back to improve practice continuously

[4602] Deliver more value Better decisions, less duplication, faster delivery and stronger outcomes

## The agent information supply chain [4604]

[4605] High-quality information in, trusted retrieval and reasoning, accurate answers or actions, human review, better sources. Every link has a quality gate.

## 1. Authoritative sources [4608]

[4610] Trusted, approved information assets

[4611] Policies & procedures

[4612] Knowledge bases

[4613] Case law & guidance

[4614] Data & reference sets

[4615] Forms & templates

[4616] Expert directories

## 2. Metadata & discovery [4618]

[4620] Make content findable and understandable

[4621] Metadata & tagging

[4622] Taxonomy & keywords

[4623] Semantic models

[4624] Lineage & provenance

[4625] Classification & sensitivity

[4626] Permissions & access

## 3. Retrieval [4628]

[4630] Find the right information in the right context

[4631] Hybrid search (keyword + semantic)

[4632] Filters (date, owner, source, role)

[4633] Rank by relevance & authority

[4634] Permission check

## 4. Agent reasoning & processing [4636]

[4638] Synthesise and reason using retrieved content

[4639] Understand intent

[4640] Ground in source content

[4641] Reason & generate

[4642] Cite sources

[4643] Guardrails & policies

## 5. Response / action proposal [4645]

[4647] Answer with citations, drafts or recommended actions

[4648] Answer with citations

[4649] Draft content

[4650] Suggest next steps

[4651] Propose system actions

## 6. Human review & oversight [4653]

[4655] Humans verify, approve and take responsibility

[4656] Check accuracy

[4657] Validate sources

[4658] Confirm applicability

[4659] Decision logged

[4660] Approve / reject

## 7. Feedback & capture [4662]

[4664] Capture feedback, use and outcomes

[4665] Was it useful?

[4666] Was it correct?

[4667] What was missing?

[4668] New knowledge identified

[4669] Add & monitor

## 8. Source improvement & governance [4671]

[4673] Improve sources, policies and models

[4674] Update content

[4675] Fix gaps

[4676] Improve metadata

[4677] Retire outdated

[4678] Review & approve

## Key metrics for the chain [4680]

[4681] Answer accuracy rate Citation coverage User satisfaction score Time to answer Re-use rate of content Feedback captured Source improvements

## Where should the information live? [4689]

[4690] Work down the questions in order. The first "yes" is your answer — the goal is the right information, to the right people, at the right time, securely and efficiently.

## 1. Is the information already in an authoritative source (for example an existing SharePoint site, policy library, DMS)? [4693]

[4695] Yes → Use existing authoritative location — keep content in place, ensure agent uses existing permissions, maintain single source of truth, lower duplication and maintenance risk.

## 2. Can the agent be granted access via existing permissions? [4699]

[4701] Yes → Grant access via existing permissions — respect least privilege, use groups and roles already in place, review access periodically.

## 3. Can permissions be adjusted for a new site (or team) without creating excessive oversharing or security risk? [4705]

[4707] Yes → Adjust permissions or create a secure location — create dedicated site or library if needed, configure granular permissions, review with the information owner.

## 4. Is copying or moving content necessary for the agent to function effectively? [4711]

[4713] Yes → Copy or move content with strong controls — risk of duplication and divergence, increased maintenance and update process, maintain links back to source of truth, confirm retention and records handling.

## If every answer is no — reconsider the approach [4717]

[4719] Use metadata, views, filters or connectors

[4720] Use automated search over authoritative sources

[4721] Build a knowledge layer or index

[4722] Avoid unnecessary duplication

## Key considerations [4724]

[4726] Audience — Who will use the agent and what access do they need?

[4728] Permissions — Does the agent respect existing SharePoint permissions?

[4730] Information governance — Is the content authoritative, current and controlled?

[4732] Duplication risk — Will copying create multiple versions or conflicting answers?

[4734] Maintenance — Can the team keep copies current and in sync with the source?

[4736] Licensing & cost — Do users have the right licences? Any connector or storage costs?

[4738] Records & retention — Where is the record of business? How long must it be kept?

[4740] Security & risk — Does the agent minimise risk of overexposure or data leakage?

## A knowledge graph and a shared prompt layer [4742]

[4743] Connecting people, communities, data, decisions and capabilities to power trusted AI — and a common language layer that improves responses, saves time and builds organisational memory.

## What the graph connects [4746]

## Questions it answers [4748]

[4750] Who owns this AI agent and what use cases is it used for?

[4751] What data sources ground the answers provided by this agent?

[4752] Which policies and controls apply to this use case?

[4753] What outcomes are we expecting and how are we measuring them?

[4754] What other capabilities or agents could be reused?

## Why a knowledge graph [4756]

[4757] Connects what sits apart Links people, data, agents and outcomes

[4759] Improves discovery and reuse Find what already exists before building

[4761] Provides context for AI Grounded, related, permissioned context

[4763] Supports governance, assurance and value Ownership, lineage and measurable benefit

[4767] 1. Organisational prompt library Curated collection of high-quality prompts · Categorised by task, role and domain · Example prompts and use guidance

[4770] 2. Prompt lab & testing Experiment and refine prompts safely · Compare results and measure quality · Promote best prompts to the library

[4773] 3. Business glossary & acronym dictionary Common definitions and terminology · Acronyms, abbreviations and plain-government terms · Versioned and community-maintained

[4776] 4. Domain & policy knowledge packs Topical guidance, policies, frameworks · Approved content summaries for AI use · Content packs for specific domains

[4779] 5. Technology-agnostic prompt patterns Reusable patterns that work across tools and models · Task-based templates and structures · Adapts to different AI platforms and models

## How the layer works [4782]

[4785] 1. Create & contribute Users contribute prompts, definitions and knowledge

[4788] 2. Curate & review Experts review for quality, accuracy and safety

[4791] 3. Publish & tag Approved items are tagged and published to the layer

[4794] 4. Use & apply AI tools and users discover and apply in their work

[4797] 5. Feedback & improve Results and feedback feed back to improve content

[4799] Back to the contents · Suggest a correction (opens GitHub)

[4811] Responsible autonomy boundaries

## The right level of autonomy for the right task at the right risk [4812]

[4813] Autonomy is a privilege, not a default. Human oversight increases with risk, impact and consequence — and the human role is named at every level, not implied.

[4817] Human control People remain accountable

[4820] Proportionate by risk Match autonomy to impact

[4823] Transparent & explainable Make actions understandable

[4826] Safe by design & default Guardrails built in

[4829] Continuously monitored Detect, learn and improve

[4831] LOW AUTONOMY HIGH AUTONOMY

[4835] Level 2 of 6

## Recommend [4836]

## Suggest options [4837]

[4840] Agent recommends options or actions for human consideration.

## Examples [4842]

[4844] Recommend next action

[4845] Suggest content or draft

[4846] Flag risks or anomalies

## The human role [4848]

## Human decision [4849]

[4850] User reviews and decides

## Factors that increase autonomy [4853]

[4855] Low risk to people

[4856] Reversible outcomes

[4857] High data quality

[4858] Clear objectives

[4859] Strong monitoring

## Factors that reduce autonomy [4861]

[4863] High impact or risk

[4864] Irreversible outcomes

[4865] Sensitive data

[4866] Uncertain environments

[4867] Weak monitoring

## Decision factors [4869]

## Risk & impact [4874]

## Legal / regulatory [4878]

## Data sensitivity [4882]

## Complexity [4886]

## Frequency [4890]

## Public trust [4894]

## Guardrails always on, and the override set [4898]

## 0 of 7 guardrails and 0 of 4 override controls in place. Guardrails are always on — autonomy is a privilege, not a default. [4900]

[4901] GUARDRAILS (ALWAYS ON) ESCALATION & OVERRIDE

## Accountability [4906]

## Named owners for agents [4909]

## Clear responsibility for decisions [4912]

## Traceable actions and outcomes [4915]

## Key reminder [4917]

## Increase autonomy only when the value outweighs the risk, controls are effective and humans can intervene. [4918]

[4919] Back to the contents · Suggest a correction (opens GitHub)

