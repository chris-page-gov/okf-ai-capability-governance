---
type: publisher-section
title: Assure and govern
status: draft
sources:
- title: Assure and govern
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-assure-and-govern
x-dom-section: part-assure-and-govern
---

# Assure and govern

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-assure-and-govern)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[4928] Part 4 of 12 · 13 chapters

## Assure and govern [4929]

[4938] Responsible AI · govern and assure

## One control plane for any tool, model or agent [4939]

[4940] Consistent principles, proportionate assurance and reusable components. Evidence and transparency records sit with the controls because they are how each control is shown to work.

## Principles and risk [4946]

[4947] Capability-based classification sets the assurance depth.

## Information and data [4951]

[4952] Readiness, metadata, indexing, provenance and retention.

## Security and privacy [4956]

[4957] Threat model, DPIA, transfers, subprocessors and DLP.

## Human oversight [4961]

[4962] Reviewer competence, evidence access, override and stop.

## Accessibility and inclusion [4966]

[4967] Accessibility of AI, AI for accessibility, alternatives and adjustments.

## Cost and FinOps [4971]

[4972] User-visible cost, caps, alerts, budget owners and value criteria.

## Sustainability [4976]

[4977] Supplier evidence, usage indicators and proportionate use.

## Transparency and records [4981]

[4982] AI involvement statements, labelling and audit evidence.

## Monitoring and assurance [4986]

[4987] Control effectiveness, incidents and reviews.

## Change and lifecycle [4991]

[4992] Change watchlist, reassessment triggers and retirement.

## Who owns what [4993]

[4999] Role

[5000] Accountable for

[5003] Senior responsible owner

[5004] Risk acceptance, sponsorship and the decision to proceed or stop.

[5006] Service owner

[5007] Day-to-day operation, monitoring, support and retirement.

[5009] Technical owner

[5010] Configuration, identity, permissions, release and change.

[5012] Commercial owner

[5013] Contract, licences, consumption, supplier commitments and exit.

[5015] Assurance owner

[5016] Assessments, evidence, exceptions and reviews.

[5018] Budget owner

[5019] Caps, alerts and spend against value evidence.

[5021] Agent, prompt or skill owner

[5022] Version, tests, approved users and withdrawal.

## Exceptions and the shadow AI route [5025]

[5026] Unmanaged external use falls when asking for an approved alternative is quicker than working around the rules.

[5028] Search your organisation's catalogue for an approved alternative.

[5029] If none fits, request one through a use case with the reason it is needed.

[5030] Get an interim decision within an agreed time, with conditions.

[5031] Record the exception in the decision register with an expiry date.

[5032] Review at expiry: approve, restrict or close.

## Communication authenticity [5034]

[5035] Keep clear labels on AI-sent messages and disclose material AI involvement. Removing a label is prohibited where transparency is required.

## Evidence and transparency records [5036]

## AI involvement statements [5039]

[5040] What AI did in producing a document, decision or message.

## Source records [5042]

[5043] The sources an output drew on, so a reader can check them.

## Human verification [5045]

[5046] Who checked the output, against what, and when.

## Decision-support records [5048]

[5049] How AI informed a decision and who made it.

## Code records [5051]

[5052] Provenance and review of AI-generated code.

## Agent action logs [5054]

[5055] What an agent did, when and why.

## Audit evidence [5057]

[5058] Configuration, approvals and test results for assurance.

## Evidence grades for product and supplier claims [5059]

[5060] These sit alongside the guide's own conventions (verified, interpretation, proposal, illustrative). They grade claims about products and suppliers, many of which come from community calls.

## Verified [5063]

[5064] Confirmed against authoritative supplier documentation or a live configuration.

## Corroborated [5066]

[5067] Reported by more than one independent source or session.

## Reported [5069]

[5070] Raised in a community call or channel. Not yet confirmed.

## Proposed [5072]

[5073] A design recommendation in this portal, not a finding.

## Unresolved [5075]

[5076] An open question. Do not rely on it until answered.

[5077] Back to the contents · Suggest a correction (opens GitHub)

[5089] Assure and govern · data and information governance

## AI governance is data governance with actions attached [5090]

[5091] Whatever an AI tool can reach, it can surface, summarise and act on. Data and information governance sets what it should reach, and treats what it produces as records.

[5097] Ownership and accountability Every source has an information asset owner; the senior information risk owner accepts residual risk.

[5102] Classification and handling Classification travels with content into prompts, indexes and outputs.

[5107] Data protection UK GDPR lawful basis, DPIA, transfers, rights and service-level privacy notices.

[5112] Quality and authority Grounding sources are authoritative, current and fit for the decision they inform.

[5117] Metadata and discoverability Titles, filenames and metadata can surface through AI. Discovery is not access.

[5122] Records and retention Prompts, outputs, transcripts and agent logs are records with retention rules.

[5127] Access and permissions Least privilege, oversharing clean-up, delegated and shared contexts tested.

[5132] Sharing and reuse Data-sharing agreements, data boundaries and trusted reuse such as data matchmaking.

## Data controls at each lifecycle stage [5134]

[5140] Stage

[5141] Data and information control

[5142] Where it is recorded

[5145] 1 Discover

[5146] Identify the information assets involved and their owners

[5147] T1 Opportunity Brief

[5149] 2 Check

[5150] Reuse existing datasets, catalogues and indexes before creating new ones

[5151] T2 Duplication Check

[5153] 3 Classify

[5154] Classification, personal data and special category data

[5155] T3 Classification

[5157] 4 Assess

[5158] DPIA, lawful basis, transfers and subprocessors, data quality and authority

[5159] T4 Data Readiness · T5 Supplier

[5161] 5 Design

[5162] Metadata, index scope, permissions, connectors and retention rules

[5163] T7 Agent Design Record · data-source register

[5165] 6 Pilot

[5166] Minimisation, test data, consent and privacy notices

[5167] T8 Pilot Plan

[5169] 10 Operate

[5170] Access reviews, DLP, records of AI outputs and agent logs

[5171] Monitoring and assurance record

[5173] 11 Reassess

[5174] New sources, connectors or locations trigger review

[5175] T11 Change-Impact Assessment

[5177] 12 Retire

[5178] Disposal, records transfer and revoked access

[5179] T12 Retirement Record

## What AI creates is information too [5180]

## Prompts and instructions [5183]

[5184] Retain where they shaped a decision or a published output; organisational prompts are versioned products.

## AI outputs [5186]

[5187] Treat as drafts until a person verifies them; keep the verified version with an AI involvement statement.

## Transcripts and recordings [5189]

[5190] Consent notice, retention period and deletion route set before recording starts.

## Agent action logs [5192]

[5193] Keep for audit and incident review; owner can read them.

## Indexes and embeddings [5195]

[5196] Derived copies of source data; inherit the source classification and retention.

## Evaluation data [5198]

[5199] Test sets and results are evidence for the decision record.

## Frameworks this aligns with [5202]

[5203] Data Ethics Framework ↗ (opens an external website) UK government framework for using data responsibly in policy and services.

[5206] Government Data Quality Framework ↗ (opens an external website) Principles and practices for assessing and improving data quality.

[5209] ICO guidance on AI and data protection ↗ (opens an external website) How UK GDPR applies to AI, including fairness, transparency and DPIAs.

[5212] Northern Ireland draft AI Strategy ↗ (opens an external website) Data governance is one of the eight proposed principles.

[5215] Scotland’s AI Strategy 2026–2031 ↗ (opens an external website) Data framed as a public asset, with a data matchmaking pilot.

## Seen in practice [5219]

[5220] Kingston Council ran a DPIA on data flows, storage and access before going live with AI note-taking, and updated its privacy notice. Hartlepool publishes a service-level privacy notice for the same kind of tool. Belfast City Council put data and AI governance under one Data & Analytics Board.

[5221] Back to the contents · Suggest a correction (opens GitHub)

[5233] Architecture of trust

## Governing AI agents as digital workers [5234]

[5235] A continuous cycle that governs AI agents as digital workers to deliver trusted public services and outcomes. The agent at the centre is purpose driven, accountable, supervised, transparent, secure and ethical. Trust at every step: right agent, right authority, right outcome.

## Identity [5240]

## Know the agent [5241]

[5243] Define purpose and role

[5244] Register and record

[5245] Assign owners

## Capability [5248]

## What it can do [5249]

[5251] Define capabilities

[5252] Tools, data, knowledge

[5253] Evaluate and test

## Authority [5256]

## What it is allowed to do [5257]

[5259] Set boundaries

[5260] Permissions & limits

[5261] Approval thresholds

## Policy & guardrails [5264]

## How it must operate [5265]

[5267] Policies & rules

[5268] Ethics & responsible AI

[5269] Guardrails & constraints

## Approval [5272]

## Authorise to operate [5273]

[5275] Risk assessment

[5276] Assurance sign-off

[5277] Go-live approval

## Execution [5280]

## Act within context [5281]

[5283] Perform tasks

[5284] Interact with users

[5285] Create outputs

## Evidence & traceability [5288]

## Prove what happened [5289]

[5291] Logging and audit trails

[5292] Data provenance

[5293] Decisions explained

## Audit & assurance [5296]

## Check and challenge [5297]

[5299] Monitor & review

[5300] Independent assurance

[5301] Compliance checks

## Learning & improvement [5304]

## Get better over time [5305]

[5307] Feedback loops

[5308] Model & process updates

[5309] Continuous improvement

## Exit & retirement [5312]

## End safely and cleanly [5313]

[5315] Revoke access

[5316] Archive & retain records

[5317] Decommission & review

## Guiding principles [5320]

[5321] Human accountability Safety, security and privacy Lawful, ethical and fair Transparency and explainability Inclusive and accessible Proportional and risk-based Evidence based and measurable Sustainable and value for money

## Foundation standards [5330]

[5331] Service Standard Technology Code of Practice AI Playbook & Responsible AI Data & AI Ethics Framework Security & Privacy Standards ATRS & Transparency

## Outcomes for public services [5339]

[5340] Better services Simpler, faster and more responsive

[5342] Trusted decisions Fair, consistent and well governed

[5344] Efficient operations Automate safely, reduce burden

[5346] Empowered workforce Augmented capability, not replaced

[5348] Improved outcomes Better impact for citizens, business and communities

[5350] Stronger public trust Accountable, transparent and responsible AI use

## Enabling foundations — built in, not bolted on [5353]

[5356] Security by design Protect systems, data and users

[5359] Privacy by design Respect and protect personal data

[5362] Human in control Meaningful oversight at all times

[5365] Impact aware Consider equality, ethics and public impact

[5368] Transparent Open about how and why agents are used

[5371] Measured & monitored Track performance, risk and value

[5374] Continuously improved Learn, adapt and evolve responsibly

[5376] Back to the contents · Suggest a correction (opens GitHub)

[5388] Enterprise AI governance operating model

## Nine layers, one accountable line of sight [5389]

[5390] A layered model for governing AI agents as digital workers to deliver trusted public services. Each layer answers one question — from why we do it, to the impact we create together.

## Strategy & public value [5394]

[5396] Set direction, objectives and principles aligned to mission, public value and national priorities.

## Why we do it [5398]

## Policy & governance [5401]

[5403] Establish policies, roles, responsibilities, decision rights and governance structures.

## Who is accountable and how [5405]

## Standards & guidance [5408]

[5410] Apply mandatory standards and guidance (Service Standard, TCoP, AI Playbook, Responsible AI, data and security standards, ATRS).

## What good looks like [5412]

## Assurance & risk management [5415]

[5417] Identify, assess, mitigate and monitor risks across the AI lifecycle. Assure compliance, safety, ethics and performance.

## How we manage risk and quality [5419]

## Platforms & foundations [5422]

[5424] Provide secure, scalable, reliable platforms, data foundations, tools, shared services and reusable components.

## What we build on [5426]

## Services & solutions [5429]

[5431] Design and deliver AI-enabled services and solutions that solve real problems and meet user needs.

## What we deliver [5433]

## AI agents as digital workers [5436]

[5438] Managed AI agents with defined purpose, capabilities, authority, guardrails, tools, data access and human oversight.

## Who or what performs the work [5440]

## Users & workforce [5443]

[5445] Civil servants, partners and operational teams who work with AI agents, provide feedback and maintain oversight.

## Who uses and oversees [5447]

## Public outcomes & impact [5450]

[5452] Better services, fairer decisions, improved efficiency and outcomes for citizens, businesses and communities.

## The impact we create together [5454]

## Enablers across all layers [5457]

[5458] People & capability Roles, skills, training, culture and change enablement.

[5460] Security & privacy Secure by design, privacy by design, data protection and resilience.

[5462] Ethics & inclusion Fairness, equality, accessibility, human rights and inclusion.

[5464] Transparency & ATRS Transparency records, explainability, traceability and open publication where appropriate.

[5466] Data & knowledge Quality data, governance, lineage, provenance and knowledge management.

[5468] Technology & architecture Interoperability, open standards, cloud first, modular and secure architectures.

[5470] Continuous improvement Measure, learn, iterate and improve services, models and operations.

## Outcomes for citizens, businesses and society [5473]

[5475] Accessible, inclusive and easy to use services

[5476] Safe, secure and trustworthy use of AI

[5477] Fairer decisions and improved experiences

[5478] Better outcomes, efficiency and productivity

[5479] Value for money and responsible use of resources

[5480] Stronger public trust, legitimacy and democratic accountability

## Our commitment: governed AI agents that are safe, effective and accountable — empowering our workforce to deliver better public services. [5481]

[5482] Back to the contents · Suggest a correction (opens GitHub)

[5494] Key risks & mitigations matrix

## Identify early. Control appropriately. Monitor continuously. Improve relentlessly. [5495]

[5496] Proactive risk management so AI agents operate safely, lawfully and effectively as digital workers. Human accountability remains non-delegable. Residual ratings assume the controls listed are in place and effective.

## 1. Inaccurate outputs (hallucination) [5501]

[5503] Residual: Low

## Description & impact [5506]

[5508] Agent generates incorrect, fabricated or misleading information.

[5509] Poor decisions, loss of trust, reputational and service impact.

## Examples [5511]

[5513] Factual errors

[5514] Fabricated citations

[5515] Incorrect summaries

[5516] Outdated information

## Key mitigations / controls [5518]

[5520] Grounding with trusted sources

[5521] Retrieval + citation requirements

[5522] Confidence thresholds

[5523] Human review for high-risk outputs

## Assurance & monitoring [5525]

[5527] Output evaluation

[5528] Spot checks & sampling

[5529] User feedback loops

[5530] Red-teaming

## Well controlled with evidence of accuracy and oversight. [5531]

## 2. Data privacy & leakage [5535]

[5537] Residual: Low

## Description & impact [5540]

[5541] Sensitive or personal data is exposed, misused or shared inappropriately.

[5542] Breach of privacy law, fines, individual harm, loss of trust.

## Examples [5544]

[5546] Prompt injection

[5547] Unintended data exposure

[5548] Insecure data handling

[5549] Over-broad access

## Key mitigations / controls [5551]

[5553] Data classification & handling rules

[5554] Least privilege access

[5555] Data masking & filtering

[5556] Secure environments & logging

## Assurance & monitoring [5558]

[5560] Access monitoring

[5561] Data loss prevention (DLP)

[5562] Privacy impact reviews

[5563] Audit trails

## Strong controls and continuous monitoring in place. [5564]

## 3. Automation bias & over-reliance [5568]

[5570] Residual: Medium

## Description & impact [5573]

[5574] Users over-trust agent outputs and fail to challenge or validate them.

[5575] Poor decisions, unintended harm, reduced critical thinking.

## Examples [5577]

[5579] Acceptance without review

[5580] Over-trust in suggestions

[5581] Deskilling of staff

[5582] Suppressed escalation

## Key mitigations / controls [5584]

[5586] Human-in-the-loop for key decisions

[5587] Clear UI prompts & explanations

[5588] Challenge culture & training

[5589] Escalation pathways

## Assurance & monitoring [5591]

[5593] User behaviour analytics

[5594] Review rates

[5595] Escalation metrics

[5596] User training effectiveness

## Managed through oversight and user behaviour. [5597]

## 4. Over-authorisation & scope creep [5601]

[5603] Residual: Medium

## Description & impact [5606]

[5608] Agent given more authority or access than necessary or approved.

[5609] Unauthorised actions, data misuse, policy breach, financial loss.

## Examples [5611]

[5613] Excessive permissions

[5614] Unapproved action types

[5615] Gradual expansion

[5616] Weak change control

## Key mitigations / controls [5618]

[5620] Least privilege & role-based access

[5621] Capability versus authority separation

[5622] Change management process

[5623] Approval for new actions

## Assurance & monitoring [5625]

[5627] Permission reviews

[5628] Access recertification

[5629] Change audit logs

[5630] Control effectiveness testing

## Requires ongoing review and re-authorisation. [5631]

## 5. Bias & fairness issues [5635]

[5637] Residual: Medium

## Description & impact [5640]

[5641] Agent outputs unfair, discriminatory or disproportionate results.

[5642] Inequitable outcomes, legal challenge, reputational harm, loss of legitimacy.

## Examples [5644]

[5646] Biased training data

[5647] Proxy discrimination

[5648] Unequal performance

[5649] Lack of representation

## Key mitigations / controls [5651]

[5653] Fairness assessments

[5654] Diverse data & testing

[5655] Bias detection tools

[5656] Human oversight & appeal

## Assurance & monitoring [5658]

[5660] Fairness metrics

[5661] Outcome monitoring

[5662] Equality impact reviews

[5663] Independent assurance

## Continuing evaluation reduces but does not eliminate risk. [5664]

## 6. Security threats & misuse [5668]

[5670] Residual: Medium

## Description & impact [5673]

[5674] Agent exploited, manipulated or used maliciously by attackers.

[5675] System compromise, data theft, service disruption, fraudulent actions.

## Examples [5677]

[5679] Prompt injection

[5680] Model exploitation

[5681] Adversarial attacks

[5682] Tool misuse

## Key mitigations / controls [5684]

[5686] Secure by design

[5687] Input validation & guardrails

[5688] Threat modelling

[5689] Anomaly detection

## Assurance & monitoring [5691]

[5693] Security monitoring

[5694] Pen testing & red teaming

[5695] Vulnerability scans

[5696] Incident response testing

## Risk managed with robust security controls. [5697]

## 7. Model drift & performance degradation [5701]

[5703] Residual: Low

## Description & impact [5706]

[5707] Agent performance declines over time as data, context or patterns change.

[5708] Reduced accuracy, poor outcomes, inefficiency, user dissatisfaction.

## Examples [5710]

[5712] Changing data patterns

[5713] Outdated knowledge

[5714] Domain shifts

[5715] Feedback ignored

## Key mitigations / controls [5717]

[5719] Continuous evaluation

[5720] Monitoring & alerting

[5721] Retraining & updates

[5722] Feedback integration

## Assurance & monitoring [5724]

[5726] Performance dashboards

[5727] Drift detection

[5728] KPI tracking

[5729] Periodic revalidation

## Active monitoring keeps risk low. [5730]

## 8. Accountability & governance gaps [5734]

[5736] Residual: Low

## Description & impact [5739]

[5740] Unclear ownership, missing controls or weak governance arrangements.

[5741] Unclear responsibility, compliance breach, regulatory scrutiny, loss of trust.

## Examples [5743]

[5745] No named owner

[5746] Weak oversight

[5747] Missing documentation

[5748] Poor auditability

## Key mitigations / controls [5750]

[5752] Named owners & RACI

[5753] Governance framework

[5754] Mandatory documentation (ATRS)

[5755] Clear policies & escalation

## Assurance & monitoring [5757]

[5759] Governance reviews

[5760] Audit & compliance checks

[5761] ATRS records reviewed

[5762] Board reporting

## Strong governance minimises risk. [5763]

## Foundational principles that reduce all risks [5765]

[5768] Human accountability People remain answerable.

[5771] Lawful & ethical use Compliant, fair and responsible.

[5774] Transparency & explainability Understandable actions and outputs.

[5777] Security & privacy by design Protect data and systems.

[5780] Inclusive & equitable Designed for all users and groups.

[5783] Measure & improve Evidence based continuous improvement.

[5786] Monitor & adapt Stay responsive to change.

[5789] Document & record Keep clear, complete and auditable records.

[5791] Back to the contents · Suggest a correction (opens GitHub)

## The full catalogue schema — eighteen fields [5803]

[5804] A single source of truth for AI agents: discoverable, governed and actionable. The four-group record above is the minimum; this is the full blueprint, with an illustrative value for each field.

[5806] Why Visibility, control, safe adoption and reuse Who Owners, users and support What Purpose, function and behaviour Where Data sources, systems and environment How Controls, assurance and monitoring Cost & value Usage, cost and outcomes

[5821] 1. Identity Agent ID (unique) · Name · Description · Version · Status e.g. AG-2026-015

[5824] 2. Purpose & function Purpose · Primary functions · Typical tasks · Intended outcomes e.g. Summarise policy documents and answer internal questions

[5827] 3. Ownership Business owner · Creator / builder · Technical owner · Information owner · Risk owner · Service owner e.g. Policy Team Lead

[5830] 4. Users & audience Primary users · User groups · Audience size · Geographies / organisations e.g. 250 staff in 2 departments

[5833] 5. Platform & model Platform (e.g. M365, Copilot Studio) · Model(s) used · Model version · Region / residency e.g. GPT-4o via Microsoft 365 Copilot

[5836] 6. Data & information sources Source systems · Information assets · Grounding method (RAG, connectors) · Data sensitivity e.g. SharePoint libraries, Policy DB, HR system

[5839] 7. Access & permissions Access model · Authentication · Permissions set · Least privilege confirmed e.g. Entra ID group based access

[5842] 8. Sharing & distribution Sharing scope (personal / team / department / cross-gov) · Channels / locations · Public-facing? Y/N e.g. Teams tab, shared with 3 teams

[5845] 9. Risk & criticality Risk category · Criticality (low/med/high) · Impact areas · Consequences e.g. Medium — operational impact

[5848] 10. Controls & assurance Guardrails / controls · Human oversight points · Testing completed · Assurance status e.g. Human review before action

[5851] 11. Usage & performance Usage level · Key metrics · Quality indicators · Last reviewed e.g. 1,250 queries / month, 92% helpful

[5854] 12. Cost & consumption Licensing / pricing model · Tokens / credits used · Estimated monthly cost · Cost owner e.g. Pay-as-you-go, £320 / month, IT

[5857] 13. Integrations & dependencies Connected systems · APIs / connectors · Dependencies · Third parties e.g. Graph API, Power Automate

[5860] 14. Monitoring & observability Logging enabled · Monitoring tools · Alerts & thresholds · Incident contact e.g. Purview logs, alerts via Sentinel

[5863] 15. Change & release Change process · Release history · Last updated · Next review date e.g. v1.2 — 12 Aug 2026, review 12 Nov 2026

[5866] 16. Support & operations Support model · Support owner · SLA / hours · Escalation path e.g. IT Service Desk P1–P3, 24×7

[5869] 17. Benefits & value Expected benefits · Measured outcomes · Baseline / target · Value owner e.g. Saves 10 hrs/week, faster responses

[5872] 18. Retirement & archiving Retirement criteria · Data retention · Archive location · Decommission plan e.g. Retire if inactive 180 days

## Status [5876]

[5877] Active In review Planned Retired Draft

## Quick filters [5883]

[5884] By owner By department By status By risk By platform By data sensitivity

## Governance at a glance [5892]

[5893] Policy & standards Aligned to organisational AI policy, standards and acceptable use.

[5895] Approval & publishing Clear gates for publication and sharing at each tier of use.

[5897] Ongoing review Regular reviews of risk, performance, cost and relevance.

[5899] Discovery & reuse Easily discoverable to avoid duplication and share good practice.

[5901] Audit & accountability Traceable ownership, decisions, changes and evidence.

## Agent lifecycle overview [5904]

[5906] 1. Idea — Identify need or opportunity

[5908] 2. Build — Create and test in a safe space

[5910] 3. Share — Share with team or small group

[5912] 4. Assess — Evaluate risk, quality and value

[5914] 5. Approve — Approve for wider use

[5916] 6. Operate — Monitor, support and optimise

[5918] 7. Review — Regular review of performance and risk

## Three registers, working together [5920]

[5921] Integrated, not duplicated. Each serves a distinct purpose and links to the others for discovery, control and reuse — over one set of shared foundational services. Single source of truth · integrated, not duplicated · accessible and discoverable · governed and accountable.

## Information asset register [5924]

[5925] Maintain authoritative inventory of information assets for governance, compliance and risk management.

## Contains [5926]

[5927] Policies, standards & procedures Documents & records Data sets & databases Forms & templates Knowledge bases Reference data Expert directories

## Key attributes [5935]

[5936] Owner & accountability · Classification & sensitivity · Retention & disposal · Legal & regulatory · Quality & governance

## Data catalogue [5938]

[5939] Make data easy to find and understand to promote reuse, reduce duplication and improve decision-making.

## Contains [5940]

[5941] Data sets & data products APIs & data services Metrics & KPIs Data dictionaries & models Knowledge bases Lineage & relationships Usage & popularity

## Key attributes [5949]

[5950] Data definition · Owner & steward · Lineage & relationships · Quality & freshness · Access & usage

## Agent register / catalogue [5952]

[5953] Register and govern AI agents and agentic capabilities to ensure safe, accountable and effective use.

## Contains [5954]

[5955] Agents & agent teams Purpose & use cases Intended users & audience Data sources & tools Risk & criticality Controls & assurance Lifecycle & status

## Key attributes [5963]

[5964] Agent owner & creator · Purpose & scope · Data sources & tools · Risk & criticality · Lifecycle & review

## Shared foundational services [5967]

[5968] Identity & access management Security & privacy controls Metadata & standards (terms, definitions) Integration & APIs (data & systems) Audit & monitoring (usage, changes) Quality management (validation, rules) Search & discovery (federated)

## How they work together [5977]

[5978] 1. Create / ingest — New information, data or agents are identified and registered

[5980] 2. Link & relate — Relationships are captured between assets, data and agents

[5982] 3. Use & leverage — People and agents find and use trusted sources and capabilities

[5984] 4. Monitor & assure — Activity, quality, risk and compliance are monitored across the landscape

[5986] 5. Improve & evolve — Feedback drives better sources, smarter agents and stronger controls

## The observability control tower [5988]

[5989] Real-time visibility of agents, usage, performance, risk and value — insight into every agent, control where it matters, confidence in outcomes. These are the panels the register needs to earn its keep.

[5992] Agents by status Active · In review · Retired

[5995] Usage over time Total agents against active agents, last 30 days

[5998] Top agents by interactions Ranked list with trend sparklines

[6001] Risk distribution Very high · High · Medium · Low

[6004] Agents by owner type Individual · Team · Department · Enterprise

[6007] Spend by agent Cost per agent, highest first

[6010] Quality & reliability Success rate · Response time · Feedback score · Error rate

[6013] Sharing & discovery Shared · Public to organisation · Cross-organisation

[6016] Alerts & needs attention Agents with no active owner · Breached sharing thresholds · Not reviewed in 60+ days · Rising error rate

[6019] Recommended actions Assign ownership and confirm purpose · Review sharing scope · Confirm continued value and risks · Validate cost and usage patterns

## Filter by dimension [6022]

[6023] Owner Department Agent type Platform / tool Data sensitivity Risk level Lifecycle status Tags / capability Geography

[6033] Back to the contents · Suggest a correction (opens GitHub)

[6045] Internal ATRS registry · AI agent transparency record

## A transparency record for every agent used inside the organisation [6046]

[6047] Based on the principles of the Algorithmic Transparency Recording Standard. Purpose: to ensure transparency, accountability and responsible use of AI agents by recording key information about their purpose, authority, data, risks, controls and lifecycle. The registry integrates with enterprise systems for identity, security, monitoring, risk, audit and knowledge management.

## Agent identity [6052]

[6054] Agent name

[6055] Unique identifier

[6056] Version

[6057] Owners (SRO, service, technical)

[6058] Sponsor / business unit

[6059] Service supported

## Business context & purpose [6062]

[6064] User needs addressed

[6065] Problem statement

[6066] Intended outcomes

[6067] Users and stakeholders

[6068] Public impact assessment

[6069] Success measures

## Authority & permissions [6072]

[6074] Actions permitted

[6075] Actions prohibited

[6076] Decisions supported

[6077] Escalation triggers

[6078] Human approval requirements

[6079] Delegated authority level

## Data & knowledge [6082]

[6084] Data sources & types

[6085] Data classification

[6086] Knowledge sources

[6087] Retention & disposal

[6088] Provenance & lineage

[6089] Data sharing & flows

## Responsible AI considerations [6092]

[6094] Fairness & bias assessment

[6095] Equality & inclusion impact

[6096] Accessibility considerations

[6097] Ethical considerations

[6098] Human oversight approach

[6099] Potential harms & mitigations

## Assurance & controls [6102]

[6104] Security review

[6105] DPIA completed

[6106] Risk assessment

[6107] Evaluation results

[6108] Red-teaming

[6109] Compliance checks

[6110] Approval & sign-off

## Operational management [6113]

[6115] Monitoring & logging

[6116] Performance metrics

[6117] Incident management

[6118] Alerting & thresholds

[6119] Kill switch / disable

[6120] Rollback process

[6121] Support & escalation

## Lifecycle & status [6124]

[6125] Lifecycle stage (proposed, pilot, live, restricted, suspended, retired)

[6127] Start date

[6128] Review frequency

[6129] End of life plan

[6130] Decommission date

## Benefits [6133]

[6135] Builds trust and accountability

[6136] Supports assurance and audit

[6137] Enables oversight and control

[6138] Promotes continuous improvement

[6139] Aligns with public sector standards

## Outputs & uses [6141]

[6142] Central inventory of AI agents Transparency for oversight Evidence for audits & assurance Risk management & reporting Informed decision making Public sector standards compliance Learning & improvement

[6150] Record quality: keep the record accurate, up to date and complete. Review at defined intervals or when significant changes occur.

[6151] Back to the contents · Suggest a correction (opens GitHub)

[6163] Failure & recovery loop

## Learn fast. Fix the issue. Prevent recurrence. Share the lesson. [6164]

[6165] Turning errors into stronger systems and better outcomes. Nine stages, and the ninth feeds the first: every failure is a source of learning. Work a live issue through the loop and record where you are.

[6167] Transparency Surface issues quickly Accountability Own and act on problems Learning Capture and share lessons Continuous improvement Strengthen continuously Proportionate Respond to risk and impact

## 0 of 9 stages recorded [6179]

[6181] Stage 1 of 9

## Detect & identify [6182]

[6183] Identify that something has gone wrong.

[6184] Errors, unexpected outputs User feedback Monitoring & alerts Quality checks

## Typical triggers [6191]

[6194] Inaccurate or incorrect outputs

[6197] Outdated or incorrect data sources

[6200] Prompt or model misbehaviour

[6203] User confusion or misuse

[6206] System or integration failure

[6209] Policy or compliance breach

## Success indicators [6211]

[6213] Issues detected early

[6214] Risks contained

[6215] Root causes addressed

[6216] Controls strengthened

[6217] Lessons shared and applied

[6218] Fewer repeat incidents

[6219] Improved outcomes and trust

## Enablers [6221]

## Leadership sponsorship [6226]

## Clear roles & responsibilities [6230]

## Policies & standards [6234]

## Quality data & governance [6238]

## Security & privacy by design [6242]

## Observability & monitoring [6246]

## Skilled teams & training [6250]

## Open feedback culture [6254]

## Tools & automation support [6258]

[6259] Back to the contents · Suggest a correction (opens GitHub)

[6271] Human oversight · principles

## The human directs; AI is in the loop [6272]

[6273] Ten principles for keeping people in charge of AI-assisted work: oversight is a competence to build and measure, not a box to tick. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

## P1 The human directs; AI is in the loop [6278]

[6279] Accountability

[6281] The person is always in the director position. AI works inside a scope the person sets, and is given agency only if, when and where it is warranted. Oversight competence means setting good bounds, reading the evidence that they are wrong, and withdrawing agency without the service collapsing.

[6282] Evidence grade: Proposed

## P2 Control intensity follows consequence [6284]

[6285] Proportionality

[6287] Classify every deployment as assist, recommend or determine before choosing controls. The productivity evidence comes from drafting, summarising and analysis; none of it comes from determining anything about a person. Drafting-grade controls on determination is the real risk; determination-grade controls on drafting forfeits real value.

[6288] Evidence grade: Proposed

## P3 Attention is a budget, not a tax [6290]

[6291] Proportionality

[6293] Most interactions should carry no friction. High-consequence, high-uncertainty and novel cases get the full set. The first control is to reduce what reaches a person at all: triage, confidence-gating and risk-proportionate friction. You cannot train your way out of a capacity problem.

[6294] Evidence grade: Proposed

## P4 Measure oversight; never assume it [6296]

[6297] Assurance

[6299] Every UK instrument makes human oversight the primary safeguard and none checks whether it still works. Behavioural signals lead; self-report, attestation and training completion do not count as evidence.

[6300] Evidence grade: Proposed

## P5 Measure the system, never the person [6302]

[6303] Privacy and trust

[6305] Oversight measurement is aggregate and non-attributable, enforced in code with minimum cohort sizes. Individual-level oversight measurement is ruled out in any form. Unions are design partners before build, on a just-culture basis.

[6306] Evidence grade: Proposed

## P6 Assured oversight unlocks autonomy [6308]

[6309] Delivery

[6311] Evidence of maintained oversight is what lets a team take the human out of more loops safely. Positioned as a brake it will be routed around; positioned as the route to more autonomy, delivery teams will ask for it.

[6312] Evidence grade: Proposed

## P7 Verify, never fabricate [6314]

[6315] Integrity

[6317] No figure, citation, claim or capability is asserted unless it can be reproduced from a source or the data. What cannot be reproduced is labelled modelled, estimated or unconfirmed on the face of the artefact. Treat any AI-produced draft as hypotheses.

[6318] Evidence grade: Proposed

## P8 Compensating is not substituting [6320]

[6321] Inclusion

[6323] Using AI to get past a stable barrier (structuring a draft, checking tone, holding many things in mind) is assistive technology. Using it to replace a judgement you could form yourself is where skill atrophy lives. A blanket rule to keep using skills unaided would be an accessibility regression.

[6324] Evidence grade: Proposed

## P9 Disclose AI assistance at the right level [6326]

[6327] Transparency

[6329] Classify AI-assisted work by audience (internal, peer co-design, external) and apply the matching disclosure. The human keeps the framework, structure, final selection and original contributions; AI output is raw material that is reviewed, accepted, rejected and shaped.

[6330] Evidence grade: Proposed

## P10 Evidence-led, with a stated exit [6332]

[6333] Integrity

[6335] If longitudinal research finds no material oversight decay in administrative settings, the currency regime scales back to sampling only. Stating in advance what would change our mind is what keeps the programme evidence-led.

[6336] Evidence grade: Proposed

[6337] Back to the contents · Suggest a correction (opens GitHub)

[6349] Human oversight · controls

## Controls that keep oversight real [6350]

[6351] 30 controls, each placed by who applies it (layer), what it does (prevent, detect, recover) and the lowest class of deployment it applies to: assist, recommend or determine. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

[6358] Control

[6359] Layer

[6360] Function

[6361] From class

[6362] What it does

[6363] Grade

[6366] Predict-then-reveal

[6367] End user

[6368] Prevent

[6369] recommend

[6370] Record the reviewer's provisional judgement before the machine output is shown. Prevents anchoring, generates a continuous unaided baseline as a by-product of normal work, and sidesteps the industrial-relations problem because it is a workflow feature rather than an assessment. At director level the same pattern applies upstream: state in advance what you expect the agent to produce and what would cause you to withdraw its grant.

[6371] Proposed

[6373] Confidence-gated disclosure

[6374] End user

[6375] Prevent

[6376] recommend

[6377] Withhold the recommendation where model uncertainty is highest, concentrating independent reasoning exactly where the machine is least reliable.

[6378] Proposed

[6380] Disconfirmation panel

[6381] End user

[6382] Prevent

[6383] recommend

[6384] Surface what contradicts the recommendation, not what justifies it. Explanations alone do not reduce overreliance and may increase it.

[6385] Proposed

[6387] Structured reason capture

[6388] End user

[6389] Detect

[6390] recommend

[6391] Approval requires a reason, not a button. Mild forcing function, quality signal, and the audit trail that makes decisions defensible.

[6392] Proposed

[6394] Anti-streak intervention

[6395] End user

[6396] Detect

[6397] recommend

[6398] After a run of unmodified approvals the interface changes state. Rubber-stamping has a behavioural signature and can be interrupted where it appears.

[6399] Proposed

[6401] Suggesting versus doing

[6402] End user

[6403] Prevent

[6404] any

[6405] Unmistakable, persistent visual distinction between an agent proposing and an agent acting, with a plain-language capability statement shown every time.

[6406] Proposed

[6408] Provenance typing

[6409] End user

[6410] Prevent

[6411] any

[6412] Distinguish retrieved fact, computed value and generated inference within one output. Reviewers apply different scrutiny to each and currently cannot tell them apart.

[6413] Proposed

[6415] Graceful degradation path

[6416] End user

[6417] Respond

[6418] any

[6419] An explicit work-without-the-agent mode as a first-class path. If the unaided path is slow or missing, unaided practice will not happen whatever the policy says.

[6420] Proposed

[6422] Mode by context

[6423] Developer

[6424] Prevent

[6425] any

[6426] Explanation mode by default in unfamiliar or security-critical code; generation mode where the developer already holds the model. Usage pattern matters more than the tool.

[6427] Proposed

[6429] Comprehension gates at pull request

[6430] Developer

[6431] Detect

[6432] any

[6433] Before merge, the author answers a generated question about their own diff. Targets comprehension debt where it is created rather than where it causes an incident.

[6434] Proposed

[6436] Protect debugging specifically

[6437] Developer

[6438] Preserve

[6439] any

[6440] Keep incident response and root-cause work assistant-free by default. Debugging degrades most and is exactly what validates everything else.

[6441] Proposed

[6443] Measure review depth, not throughput

[6444] Developer

[6445] Detect

[6446] any

[6447] Throughput rising while time-in-review per change falls is the signature of oversight collapse, and looks like a productivity win on standard metrics.

[6448] Proposed

[6450] Rebase knowledge metrics

[6451] Developer

[6452] Detect

[6453] any

[6454] Truck-factor and ownership metrics assume the committer understands the code. Once much of it is machine-generated, organisations believe they have knowledge coverage they do not have.

[6455] Proposed

[6457] Independent test provenance

[6458] Developer

[6459] Prevent

[6460] any

[6461] Tests for agent-generated code should not come from the same agent in the same pass, or verification and artefact share a failure mode.

[6462] Proposed

[6464] Standard oversight event schema

[6465] Platform

[6466] Detect

[6467] assist

[6468] One event per interaction, comparable across the estate. Building this per-department guarantees incomparable data and no exportable artefact.

[6469] Proposed

[6471] Privacy-enforcing aggregation

[6472] Platform

[6473] Prevent

[6474] any

[6475] Minimum cohort sizes enforced in code, so individual analysis is structurally unavailable rather than merely prohibited. Far more credible to staff than a policy promise.

[6476] Proposed

[6478] Canary injection service

[6479] Platform

[6480] Detect

[6481] determine

[6482] Synthetic known-bad outputs at low randomised rate with guaranteed downstream suppression. The sharpest instrument available and the fastest way to lose the programme if sequenced wrong.

[6483] Proposed

[6485] Model version change trigger

[6486] Platform

[6487] Detect

[6488] determine

[6489] Human trust calibration is built against a specific error profile. A silent upgrade resets it and every reviewer's intuition is tuned to a system that no longer exists.

[6490] Proposed

[6492] Currency ledger

[6493] Platform

[6494] Preserve

[6495] any

[6496] Records last unaided practice, canary exposure and comprehension check — by role, never by person.

[6497] Proposed

[6499] Resourced oversight declaration

[6500] Organisation

[6501] Prevent

[6502] assist

[6503] Deployment plans must state the oversight burden, who carries it, the headcount cost and how approval fatigue is mitigated as volume scales.

[6504] Proposed

[6506] Owner-tied agent lifecycle

[6507] Organisation

[6508] Respond

[6509] assist

[6510] Named owner with delegate; pause, reassign or deactivate on offboarding; explicit transfer of accountability or the agent stops.

[6511] Proposed

[6513] Degraded-mode operating standard

[6514] Organisation

[6515] Respond

[6516] determine

[6517] Periodically demonstrate the service runs without the agent at acceptable quality. A continuity exercise, not a workforce assessment — which also avoids the industrial-relations problem.

[6518] Proposed

[6520] Risk-proportionate friction

[6521] Organisation

[6522] Prevent

[6523] any

[6524] Attention is a budget. Most interactions get none; high-consequence, high-uncertainty, novel cases get the full set. The system should read as removing friction from routine work.

[6525] Proposed

[6527] Earned autonomy

[6528] Organisation

[6529] Respond

[6530] any

[6531] Agency is granted, not assumed. Teams that show sustained catch performance and good outcome sampling earn lighter per-item oversight and wider agent scope. Every grant states, before it is issued, what the director expects the agent to produce, what evidence would trigger withdrawal, and a costed path to withdraw it without the service collapsing (the degraded-mode standard).

[6532] Proposed

[6534] Junior role redesign

[6535] Organisation

[6536] Preserve

[6537] any

[6538] Rebuild entry-level roles around verification, evaluation and supervised judgement. The longest-lead item here, and the only risk no other control addresses.

[6539] Proposed

[6541] Procurement conditionality

[6542] Organisation

[6543] Prevent

[6544] any

[6545] Require draft-only defaults, immutable logging, explainable action chains, declared autonomy level, and evidence that the approval interface does not induce rubber-stamping.

[6546] Proposed

[6548] Prior-capture component

[6549] Platform

[6550] Prevent

[6551] any

[6552] A reusable component that captures the human's provisional judgement before revealing the agent's output. this is the highest-value single primitive.

[6553] Proposed

[6555] Conformance suite

[6556] Platform

[6557] Detect

[6558] any

[6559] A test harness verifying that a product implements P1–P6 correctly. Built on Inspect, this doubles as the procurement conformance test and the exportable artefact.

[6560] Proposed

[6562] Provenance annotation on code

[6563] Developer

[6564] Detect

[6565] any

[6566] Mark AI-generated hunks — to route review attention and enable D4 and D5, explicitly not to penalise authors. State that purpose openly, or the annotation will be gamed.

[6567] Proposed

[6569] Progression criteria for developers

[6570] Developer

[6571] Preserve

[6572] any

[6573] Unaided debugging and design reasoning remain part of promotion and hiring assessment. If the profession stops selecting for it, no downstream control will preserve it.

[6574] Proposed

[6575] Back to the contents · Suggest a correction (opens GitHub)

[6587] Human oversight · telemetry

## Measure the system, never the person [6588]

[6589] Signals that show whether human oversight is working, read across the service rather than used to rate individuals. Rubber-stamping, drift and lost skill show up in the shape of the data before they show up in incidents. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

## Conformance tiers [6592]

## Minimum viable oversight telemetry [6595]

[6596] How fast are decisions being made, by class of deployment, and what proportion are accepted unchanged? Enough to detect a fast-approval mode appearing. Fields: event_id, emitted_at, service_id, deployment_class, cohort_id, interaction.disposition, interaction.time_to_decision_ms.

## Engagement measurable [6598]

[6599] Is engagement declining? Are streaks lengthening? Did behaviour change when the model changed? Fields: interaction.edit_distance_normalised, interaction.reason_text_present, interaction.consecutive_unmodified_count, case_risk_class, model.model_version.

## Effectiveness measurable [6601]

[6602] Are known-bad outputs actually being caught, and what is unaided judgement doing over time? This is the only tier that measures oversight effectiveness rather than proxies for it. Fields: canary.*, human_prior.*, governance.*.

## Signals [6603]

[6608] Signal

[6609] Kind

[6610] What to look for

[6611] Grade

[6614] Time-to-decision distribution

[6615] leading

[6616] Not the mean — the shape Bimodality with a large fast mode is the rubber-stamping signature

[6617] Proposed

[6619] Edit distance

[6620] leading

[6621] Difference between suggestion and final output Cheapest continuous proxy for engagement; a collapse toward zero is the clearest early warning Threshold: slope < -0.002 per period → medium; < -0.006 → high

[6623] Proposed

[6625] Override rate and override quality

[6626] leading

[6627] Rate is nearly meaningless alone; quality is graded from reason text on a sample A falling override rate with rising override quality is healthy; both falling is decay

[6628] Proposed

[6630] Canary catch rate

[6631] leading

[6632] Proportion of injected known-bad outputs caught, and time-to-detection The only direct measure of oversight effectiveness Threshold: slope < -0.002 → high

[6634] Proposed

[6636] Unaided baseline delta

[6637] leading

[6638] Human-alone accuracy versus agent accuracy, tracked over time The core skill-atrophy measure; this is free Superseded: the human comparator is noisy (two expert groups agreed 55% of the time), so read this through reasoned-disagreement sampling, never as an error rate.

[6639] Proposed

[6641] Prior-agreement pattern

[6642] leading

[6643] Whether human priors converge on agent outputs over time Detects anchoring even where accuracy holds

[6644] Proposed

[6646] Escalation appropriateness

[6647] leading

[6648] Sampled grading of what was escalated and what should have been Detects erosion of judgement about the boundary of competence

[6649] Proposed

[6651] Novel-case handling

[6652] leading

[6653] Performance on cases unlike recent case mix Early warning for the H3 base-rate problem

[6654] Proposed

[6656] Consecutive-approval streaks

[6657] leading

[6658] Run length without modification Actionable in real time, unlike anything else on this list

[6659] Proposed

[6661] Sub-4-second approvals

[6662] instrument

[6663] Share of decisions made faster than plausible reading time. A growing fast mode is the rubber-stamping signature.

[6664] Proposed

[6666] Unmodified streak length

[6667] instrument

[6668] Run length of accepts without modification. Actionable in real time, unlike anything else here.

[6669] Proposed

[6671] Override rate

[6672] instrument

[6673] Rate alone is nearly meaningless — a falling override rate with rising override quality is healthy. Read alongside reason capture. Threshold: modify/reject/escalate share; no threshold

[6675] Proposed

[6677] Reason capture rate

[6678] instrument

[6679] Share of approvals carrying a written rationale. Doubles as the evidential basis for contestability under the DUA Act.

[6680] Proposed

[6682] Reasoned disagreement

[6683] instrument

[6684] Where an independent human prior differs from the machine AND carries a rationale. Never scored as error by either party. Threshold: disagreement AND rationale present

[6686] Proposed

[6688] Self-reported vigilance

[6689] instrument

[6690] Carried only to be contradicted. Where it diverges from behavioural signals, the behavioural signals govern.

[6691] Proposed

[6693] Lagging indicators

[6694] lagging

[6695] Complaint and appeal volumes; overturn rates at review, tribunal or ombudsman; defect escape rate by provenance; incident post-mortems citing missed agent error; audit findings

[6696] Proposed

[6698] Automation-drift signals (system-side)

[6699] system

[6700] Action-type distribution against approved scope; permission-use drift; tool-call patterns diverging from design baseline; output distribution shift; latency and cost anomalies; sub-agent proliferation; any action not in the labelled activity permission set

[6701] Proposed

[6703] Signals to avoid

[6704] anti-signal

[6705] Confidence self-ratings; training completion rates; attestation; anything a person can answer about themselves

[6706] Proposed

[6708] Developer signals (D4)

[6709] developer

[6710] Time-in-review per unit of change; comment density on AI-authored hunks; defect escape rate by provenance

[6711] Proposed

[6713] Analyser refusal thresholds

[6714] privacy gate

[6715] Refuse if identifier columns present (user_id, staff_id, email, name, person_id, username, employee_id, staff_number); fewer than 3 cohorts; fewer than 200 events. Python Aggregator k-floor = 10.

[6716] Proposed

[6717] Back to the contents · Suggest a correction (opens GitHub)

[6729] Human oversight · risks

## Skill atrophy, automation drift and how oversight programmes fail [6730]

[6731] The risks sit on the human side of AI use: skills fading through disuse, trust drifting into rubber-stamping, and oversight schemes failing because they are built as staff surveillance or as a brake on delivery. The priorities say what to do first. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

## Risks [6734]

[6739] Risk

[6740] Family

[6741] Likelihood

[6742] What happens and the mitigation

[6743] Grade

[6746] Designed as individual performance monitoring

[6747] Programme

[6748] Most likely

[6749] Unions contest it and it is withdrawn; staff rationally game it, which destroys the measurement. Mitigation is architectural: aggregate, non-attributable reporting enforced in code, on a just-culture basis, with unions as design partners before build.

[6750] Proposed

[6752] Positioned as a brake on delivery

[6753] Programme

[6754] Likely

[6755] Lands as friction on people already told to go faster. Mitigation is the framing: evidence of maintained oversight is what unlocks higher-autonomy deployment.

[6756] Proposed

[6758] Built for the centre, never reaches local government

[6759] Programme

[6760] Likely

[6761] Councils do the statutory casework where deskilling bites hardest and adopt fastest where oversight capacity is thinnest. Mitigation: the playbook window, this quarter.

[6762] Proposed

[6764] Published internationally before implemented domestically

[6765] Programme

[6766] Moderate

[6767] A standard we do not meet is worse than silence. Mitigation: sequencing discipline.

[6768] Proposed

[6770] Over-specified ahead of the evidence

[6771] Programme

[6772] Moderate

[6773] Becomes compliance theatre. Mitigation: the exit criterion, published in advance.

[6774] Proposed

[6776] Absorbed by the reorganisation

[6777] Programme

[6778] New

[6779] Machinery of government changes typically consume twelve to eighteen months of senior capacity. The one genuinely closing window will close while everyone stands up new departments.

[6780] Proposed

[6782] Measurement pathologies

[6783] Oversight measurement

[6784] Not rated

[6785] Goodhart on catch rate; differential impact of cognitive forcing; observation effect inflates baselines

[6786] Proposed

[6788] Oversight layer as attack surface

[6789] Oversight measurement

[6790] Not rated

[6791] Adversary targets oversight via volume attacks inducing approval fatigue, timing, routine-looking outputs; brings NCSC in

[6792] Proposed

[6794] Anti-patterns

[6795] Oversight measurement

[6796] Not rated

[6797] Training completion as assurance; explanation panels as overreliance control; uniform friction; individual dashboards; self-assessment; retrospective-only monitoring; blanket AI-free days; per-department schemas; canaries without prior union agreement and ethics approval

[6798] Proposed

[6800] Say no to

[6801] Oversight measurement

[6802] Not rated

[6803] Bespoke UK instrument rather than extending Inspect; individual-level dashboards; publishing standard before item 1 produces a number; per-department schemas; uniform friction

[6804] Proposed

[6806] Hallucination

[6807] AI adoption

[6808] Not rated

[6809] The Department for Business and Trade found no robust evidence that time savings were leading to improved productivity, despite high user satisfaction. 22 per cent of respondents identified hallucinations.

[6810] Proposed

[6812] Managers cannot identify AI outputs

[6813] AI adoption

[6814] Not rated

[6815] 61 per cent of managers in the Australian trial pulse survey could not confidently identify Copilot outputs.

[6816] Proposed

[6818] Self-report perception gap

[6819] AI adoption

[6820] Not rated

[6821] A randomised controlled trial published by METR found 16 experienced open-source developers took 19 per cent longer to complete 246 real tasks in their own mature repositories when allowed to use AI tools, while estimating afterwards that AI had made them around 20 per cent faster.

[6822] Proposed

[6824] Permission drift / oversharing

[6825] AI adoption

[6826] Not rated

[6827] Content reachable by more people than intended, usually through accumulated permission drift. Pre-exists AI; AI makes it discoverable by intent. AI does not create permissions. It makes content that had been obscured by volume discoverable by intent, so accumulated permission drift becomes a day-one incident rather than a latent risk.

[6828] Proposed

[6830] Prompt injection

[6831] AI adoption

[6832] Not rated

[6833] Instructions hidden in content an AI system reads, causing it to act against the user's intent. In coding agents the vector is repository content, issues and fetched pages.

[6834] Proposed

[6836] Orphaned agents

[6837] AI adoption

[6838] Not rated

[6839] A deployed agent with no current named owner.

[6840] Proposed

[6842] Vendor lock-in / procurement mismatch

[6843] AI adoption

[6844] Not rated

[6845] The Committee of Public Accounts found government procurement approaches ill-suited to a dynamic, fast-paced market, increasing risks to value for money from vendor lock-in and from an inability to adapt.

[6846] Proposed

[6848] Central aggregated agreement as single point of political and commercial failure

[6849] AI adoption

[6850] Not rated

[6851] GSA removed Anthropic from USAi.gov and the Multiple Award Schedule on 27 February 2026 following a presidential directive, and restored it on 3 April 2026 following a preliminary injunction. Illustrates that a central aggregated agreement is a single point of political as well as commercial failure.

[6852] Proposed

[6854] Prepaid capacity waste

[6855] AI adoption

[6856] Not rated

[6857] Prepaid Copilot Credit capacity is monthly and does not roll over, which can make under-used prepaid capacity more expensive per unit than pay-as-you-go.

[6858] Proposed

[6860] Productivity not evidenced despite satisfaction

[6861] AI adoption

[6862] Not rated

[6863] The Department for Business and Trade found no robust evidence that time savings were leading to improved productivity, despite high user satisfaction. 22 per cent of respondents identified hallucinations.

[6864] Proposed

[6866] Skills and legacy barriers

[6867] AI adoption

[6868] Not rated

[6869] The National Audit Office reported that 37 per cent of responding government bodies had deployed AI, 21 per cent had an AI strategy with a further 61 per cent planning one, 70 per cent reported skills as a barrier, and 74 AI use cases had already been deployed. The Committee of Public Accounts found that as at January 2025 only 33 ATRS records had been published, an estimated 28 per cent of central government IT systems are legacy, and around 50 per cent of roles advertised in civil service digital and data campaigns in 2024 were unfilled.

[6870] Proposed

[6872] Publication bias

[6873] AI adoption

[6874] Not rated

[6875] Organisations tend to publish evaluations that found something. The Department for Business and Trade publishing a null result is unusual. There is no way to count unpublished null results.

[6876] Proposed

[6878] Fabricated / unverifiable citations in AI drafts

[6879] AI adoption

[6880] Not rated

[6881] None of the faulty citations was identifiable from the draft itself. Each was correctly formatted, plausibly dated and attributed to a real institution; several linked to an organisation's homepage rather than the document asserted. A European Commission programme cited in the AI-produced draft, with a specific name and date, could not be located in two independent verification passes.

[6882] Proposed

[6884] Inconsistent trial figures in the public record

[6885] AI adoption

[6886] Not rated

[6887] The number of participating organisations in the cross-government experiment is recorded inconsistently in the public record: the written ministerial statement (HCWS669) states 12 major government organisations, while the HMRC evaluation refers to 11 participating departments. The DTA states the trial made Copilot available to over 7,600 staff across more than 60 agencies, while its own full evaluation report states over 5,765 licences were distributed. Press accounts describe the NHS pilot as involving three named trusts, against NHS England's own statement of more than 30,000 workers across 90 organisations.

[6888] Proposed

[6890] Accessibility regression from blanket skill-maintenance rules

[6891] AI adoption

[6892] Not rated

[6893] Applied unchanged to people who use AI to compensate for a disability or a different way of working, a “keep your skills” rule would be an accessibility regression.

[6894] Proposed

[6896] Skill atrophy and automation drift

[6897] Human oversight

[6898] Not rated

[6899] Sustained offloading leaves staff less practised and slower to notice errors, while the automated system drifts beyond approved scope. Because every UK instrument relies on human oversight as the principal control, erosion of that capability is a silent failure of the control itself.

[6900] Proposed

## Priorities (MoSCoW) [6901]

[6906] Code

[6907] Priority

[6908] Tier

[6909] Note

[6912] M0

[6913] Classify every deployment as assist, recommend or determine, and apply controls by class.

[6914] Must

[6915] The first control.

[6917] M1

[6918] Human-side risk register including skill atrophy and automation drift.

[6919] Must

[6922] M2

[6923] Delegation competence precondition, applied to determine-class only: whoever directs an agent can set its bounds, read the evidence that they are wrong, and withdraw its agency without the service collapsing.

[6924] Must

[6925] Narrowed from universal application (Sep 2026), then reframed from task-audit competence to delegation competence in this consolidation, following the human-as-director principle.

[6927] M3

[6928] Reasoned-disagreement sampling: grade quality of reasoning on both sides; never treat divergence as error.

[6929] Must

[6930] Re-specified. The original unaided-baseline control assumed a reliable human ground truth that the 55% figure disproves.

[6932] M4

[6933] Resourced oversight declaration, with supervision cost in the business case.

[6934] Must

[6935] Strengthened to a total-cost-of-ownership requirement.

[6937] M5

[6938] Owner-tied agent lifecycle, including deactivation on offboarding.

[6939] Must

[6942] M6

[6943] Reversibility precondition: no determination about an individual is automated where it cannot be identified, explained and reversed.

[6944] Must

[6945] Promoted from Could.

[6947] M7

[6948] Degraded-mode capability: demonstrate the service operates without the agent.

[6949] Must

[6950] Continuity framing moves this onto risk registers that already have authority.

[6952] S1

[6953] Oversight currency scheme.

[6954] Should

[6955] Downgraded to conditional on baseline findings. Do not build ahead of the evidence.

[6957] S2

[6958] Cross-government agent register.

[6959] Should

[6960] Blocked on agent identity, which is unstarted.

[6962] S3

[6963] Skill-decay metrics in assurance, aggregate and platform-enforced.

[6964] Should

[6965] Strengthened on privacy.

[6967] S4

[6968] Competency framework specifying maintenance as well as acquisition.

[6969] Should

[6972] S5

[6973] Procurement clauses including substantiation standards and oversight-burden disclosure.

[6974] Should

[6975] Expanded.

[6977] S6

[6978] Junior role redesign around verification and supervised judgement.

[6979] Should

[6980] The longest-lead item.

[6982] S7

[6983] Mode-of-use design standards; explanation-mode defaults in unfamiliar contexts.

[6984] Should

[6985] Highest actionability for the cost.

[6987] C1

[6988] Oversight red-teaming with seeded errors in live workflows.

[6989] Could

[6992] C2

[6993] Longitudinal skill-decay research in an administrative setting.

[6994] Could

[6997] C3

[6998] Calibrated-trust design patterns in the design system.

[6999] Could

[7002] C4

[7003] Total cognitive load measurement.

[7004] Could

[7005] Potentially the most internationally distinctive item — nobody has done it.

[7007] C5

[7008] Published standard and open-licensed toolkit.

[7009] Could

[7012] W1

[7013] Statutory oversight-competence duty.

[7014] Won't

[7015] Requires primary legislation. Watching brief on EU enforcement experience.

[7017] W2

[7018] Mandatory whole-of-government AI policy on the Australian model.

[7019] Won't

[7020] Decision sits above this level.

[7022] W3

[7023] Individual certification or licensing of oversight officers.

[7024] Won't

[7025] Disproportionate on current evidence.

[7027] W4

[7028] Individual-level oversight measurement, in any form.

[7029] Won't

[7030] Hard prohibition, enforced at the platform layer.

[7032] W5

[7033] Matching private-sector adoption pace as an objective in itself.

[7034] Won't

[7035] Pace is a means. The incentive structures differ.

[7036] Back to the contents · Suggest a correction (opens GitHub)

[7048] Human oversight · verification

## Treat AI output as a draft to check, not a source [7049]

[7050] Practices for checking AI-assisted research, analysis and artefacts before they are relied on, and failure patterns seen in public sector work. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

## Evidence handling [7053]

[7055] Treat an AI-produced research draft as hypotheses only. An AI-produced research draft was treated as a source of hypotheses only. None of its assertions was carried forward unchecked. Each source in that draft was located independently, and the result of every check was recorded, including failures.

[7057] Keep unverifiable claims, marked. Claims that could not be substantiated were kept and marked. Deleting them would remove the evidence of the checking.

[7059] Provenance travels with each claim. The unit here is the claim, not the document. In a portal people land on one assertion without meeting the caveats that make it safe to use, so the provenance travels with each claim.

[7061] Label researcher interpretation. Interpretations are labelled, never presented as findings (enforced by CHK-004).

[7063] Prefer counterfactual evaluations. The comparison against which a benefit is measured, typically a group not using the tool. An evaluation without one cannot separate the tool's effect from everything else. The two evaluations with a comparison or randomised design, DWP and HMRC, report lower figures than those without. Expect that pattern to hold elsewhere.

[7065] Treat supplier evidence as interested-party. Supplier — treated as interested-party evidence; verified independently wherever possible.

[7067] Grounding quality. Supplying an AI system with specific approved source material so its output is based on that material. Grounding quality is a function of source quality and currency.

[7069] Read live rate cards at point of use. Supplier terms. Read the live rate card at the point of building any business case; do not quote these figures from the portal.

[7071] Ask for realised-outcome evidence rather than inferring it. The NHS England rollout date has arrived, so ask NHS England for realised-outcome evidence rather than inferring it.

## Security and privacy [7073]

[7075] Use the DPIA as a design tool from day one. Embed DPIA as a design tool at the start of every build; non-digital fallback routes; test with affected groups; document Equality Act/PSED compliance by default.

## Delivery [7077]

[7079] Due diligence on AI-assisted development. Due diligence on AI-assisted development methodology should cover GDS delivery alignment, AI assistance scope, IPR and Crown copyright, spend assurance (GDS spend controls were withdrawn on 1 April 2026 and replaced by the Digital Assurance Playbook), data handling and ethical AI use.

## Self-check pattern [7081]

[7083] Every case cites at least one source, and every source exists. A check that runs on the artefact itself. It exists because of the defect shown.

[7085] Every figure carries a status label and a resolvable source. A check that runs on the artefact itself. It exists because of the defect shown.

[7087] Every case has a known mechanism and every mapped control resolves. A check that runs on the artefact itself. It exists because of the defect shown.

[7089] Dates are valid year-month values. A check that runs on the artefact itself. It exists because of the defect shown.

[7091] Case and source identifiers are unique. A check that runs on the artefact itself. It exists because of the defect shown.

[7093] No attributed death count appears on the face of any case. A check that runs on the artefact itself. It exists because of the defect shown.

[7095] Anchor case states the causation limit before any consequence claim. A check that runs on the artefact itself. It exists because of the defect shown.

[7097] Figures add up: the fines total is computed, not typed. A check that runs on the artefact itself. It exists because of the defect shown.

[7099] Anything not re-verified this release is listed as carried, not shown as fact. A check that runs on the artefact itself. It exists because of the defect shown.

[7101] Sources are fresh (checked within 90 days of viewing). A check that runs on the artefact itself. It exists because of the defect shown.

[7103] Coverage spans sectors and all four UK nations. A check that runs on the artefact itself. It exists because of the defect shown.

[7105] Every challenge states what the objection gets right and the limit of the claim. A check that runs on the artefact itself. It exists because of the defect shown.

[7107] Displayed money totals stay within 0.5% of the computed figure. A check that runs on the artefact itself. It exists because of the defect shown.

[7109] Vendor documentation is labelled supplier evidence, and only vendor sources carry that label. A check that runs on the artefact itself. It exists because of the defect shown.

[7111] Every connection states the tie and the action, and every link is a full https address. A check that runs on the artefact itself. It exists because of the defect shown.

[7113] Counts written into the text match the data. A check that runs on the artefact itself. It exists because of the defect shown.

[7115] Citations of the standard do not depend on the retiring co-cddo organisation. A check that runs on the artefact itself. It exists because of the defect shown.

[7117] Every post referenced in the seam, triad and resolution register exists in the join-up map. A check that runs on the artefact itself. It exists because of the defect shown.

[7119] The resolution register covers every mechanism and every case, and cites only real cases. A check that runs on the artefact itself. It exists because of the defect shown.

[7121] Every computed placeholder in the text has a value. A check that runs on the artefact itself. It exists because of the defect shown.

[7123] Every case has a DAM Policy assessment, and each case's rules agree with each rule's cases. A check that runs on the artefact itself. It exists because of the defect shown.

[7125] Proposed return rules use the workspace's own grammar and every in-scope case is answered by one. A check that runs on the artefact itself. It exists because of the defect shown.

[7127] verified / reported / estimate / supplier evidence / author's account; sums of estimates are not audited totals; vendor docs labelled supplier evidence only (K14).. A check that runs on the artefact itself. It exists because of the defect shown.

## Failure patterns to recognise [7129]

## The Hidden Tab Pattern [7132]

[7133] Responsible data use

[7135] Files and messages leave organisations carrying more personal data than the sender can see or intended to send; the sensitivity/handling label sits in a register or catalogue entry that stays behind and does not travel with the file to the point of release, so nothing at the boundary can read it.

[7136] Case: MOD (UK Special Forces HQ), February 2022: a spreadsheet believed to hold about 150 Afghan relocation applicants carried, invisibly, details of about 18,700. Twin case: PSNI, August 2023, a second tab on an FOI answer exposed every officer (ICO fine £750,000).

## Synthetic data presented as real [7138]

[7139] Verifying AI-assisted work

[7141] An AI assistant described synthetic events as real output, and an early build of the oversight instrument repeated it. Anything generated must be labelled on its face.

[7142] Case: Found and corrected during review, 2026.

## Hand-typed figures drift from the data [7144]

[7145] Verifying AI-assisted work

[7147] A figure typed rather than computed drifts from the data it claims to summarise. Compute totals; never type them.

[7148] Case: A figure typed into an appraisal differed materially from the figure computed from its data; caught by a check that recomputes totals.

[7149] Back to the contents · Suggest a correction (opens GitHub)

