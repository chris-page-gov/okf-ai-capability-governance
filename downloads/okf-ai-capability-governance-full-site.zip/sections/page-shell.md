---
type: publisher-section
title: Page shell and ungrouped content
status: draft
sources:
- title: Page shell and ungrouped content
  resource: https://cyberdudeuk.github.io/ai-capability-governance/
x-dom-section: page-shell
---

# Page shell and ungrouped content

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[52] Menu

[55] Start

[60] Playbook

[76] Tools

[87] Assurance and delivery

[95] Knowledge

[103] About

[117] AI PLAYBOOK Ten principles for AI use across government, published 10 February 2025 (opens an external website)

[121] ATRS Algorithmic transparency records required for central government departments (opens an external website)

[125] NCSC Guidelines for secure AI system development, agreed with international partner agencies (opens an external website)

[129] EU AI ACT Digital Omnibus defers stand-alone high-risk duties to 2 December 2027; AI used by public authorities must comply by 2 August 2030 (opens an external website)

[133] SCOTLAND AI Strategy 2026 to 2031 published 20 March 2026, guided by the OECD AI Principles (opens an external website)

[137] DUAA 2025 Automated decision-making safeguards (Articles 22A to 22D) in force from 5 February 2026 (opens an external website)

[141] WCAG 2.2 AA Accessibility evidence required before release under the 2018 regulations (opens an external website)

[145] Pause

[229] Contents drawer

[234] Filter playbook chapters

[242] Start 2

[248] Overview

[251] Find your route

[254] Agent governance playbook

[257] Part 1 Start here 5

[264] 1.1 Overview

[269] 1.2 Can I use AI for this?

[274] 1.3 How to use this guide

[279] 1.4 The playbook

[284] 1.5 Capability domains

[290] Part 2 Decide and prioritise 6

[297] 2.1 Evidence before assertion

[302] 2.2 Use cases & evidence

[307] 2.3 Public sector case library

[312] 2.4 Classify & assess

[317] 2.5 Criticality & gates

[322] 2.6 Assurance tiers

[328] Part 3 Design and build 8

[335] 3.1 Lifecycle & templates

[340] 3.2 Capability classes

[345] 3.3 Skill studio

[350] 3.4 Agent assurance X-ray

[355] 3.5 Connectors, MCP & integrations

[360] 3.6 Architecture & quality

[365] 3.7 Knowledge foundation

[370] 3.8 Autonomy boundaries

[376] Part 4 Assure and govern 13 New

[384] 4.1 Control plane & evidence

[389] 4.2 Data & information governance

[394] 4.3 Architecture of trust

[399] 4.4 Governance operating model

[404] 4.5 Risks & mitigations

[409] 4.6 Registers & lifecycle

[414] 4.7 Internal ATRS registry

[419] 4.8 Failure & recovery

[424] 4.9 Human oversight principles New

[430] 4.10 Oversight controls New

[436] 4.11 Measuring oversight New

[442] 4.12 Human-side risks and priorities New

[448] 4.13 Verifying AI-assisted work New

[455] Part 5 Operate and oversee 7 New

[463] 5.1 Portfolio control tower

[468] 5.2 Monitoring & reassessment

[473] 5.3 Agent journey

[478] 5.4 Agent employment

[483] 5.5 Public service impact

[488] 5.6 Observatory & barometer

[493] 5.7 Oversight runbook and templates New

[500] Part 6 Fund and buy 4

[507] 6.1 Cost, value & investment

[512] 6.2 FinOps & models

[517] 6.3 Commercial & suppliers

[522] 6.4 Dependency & exit

[528] Part 7 People and adoption 12 New

[536] 7.1 Multidisciplinary teams

[541] 7.2 AI service team

[546] 7.3 Roles & pathways

[551] 7.4 Capability academy

[556] 7.5 Capability & maturity

[561] 7.6 Inclusive adoption

[566] 7.7 Adoption journey

[571] 7.8 Agent rollout

[576] 7.9 Community engagement

[581] 7.10 Operating model

[586] 7.11 Adoption & change model

[591] 7.12 Neuroinclusive AI at work New

[598] Part 8 Live pilot 9

[605] 8.1 The pilot in one view

[610] 8.2 What it tests

[615] 8.3 Candidate selection

[620] 8.4 Pilot roles

[625] 8.5 Assurance model

[630] 8.6 Journey & ceremonies

[635] 8.7 Communications

[640] 8.8 Success & feedback

[645] 8.9 Decision & toolkit

[651] Part 9 Product documentation 8

[658] 9.1 Product requirements

[663] 9.2 Functional & technical spec

[668] 9.3 Solution architecture

[673] 9.4 High-level design

[678] 9.5 Low-level design

[683] 9.6 Theory of change

[688] 9.7 Personas & journeys

[693] 9.8 Gov.uk AI resources

[699] Part 10 Knowledge and navigation 4

[706] 10.1 Thesaurus

[711] 10.2 Taxonomies & ontology

[716] 10.3 Platforms & repositories

[721] 10.4 Federated guidance service

[727] Part 11 Deploy for real 4

[734] 11.1 Service atlas

[739] 11.2 Case generator

[744] 11.3 Worked examples

[749] 11.4 What this does not cover

[755] Part 12 Reference 5 New

[763] 12.1 UK nations

[768] 12.2 International

[773] 12.3 Pace & parity

[778] 12.4 Oversight crosswalk New

[784] 12.5 Obligations register New

[791] Tools 8 New

[798] All working tools

[801] Can I use AI for this?

[804] Human review triage

[807] Evidence pack

[810] DEIA impact screen

[813] Transparency record

[816] Quantum readiness

[819] Plain language

[823] Assurance and delivery 5

[829] Toolkit assets 18

[833] Assurance model

[836] Asset catalogue

[839] UCD and DEIA

[842] Code of practice

[846] Knowledge 5

[852] Authority tiers

[855] Resource library 69

[859] Signals 29

[863] Glossary 174

[867] Knowledge map

[871] About 4

[877] Transparency

[880] How the playbook was made

[883] Roadmap

[886] Contact

## Make guidance usable, testable and accountable. [22285]

[22286] Start with the corpus, encode the metadata, publish the skills, bound the agents, enforce the review — and keep improving it in the open.

## Site footer [22293]

## Get started [22313]

[22315] Start here

[22317] Review triage

[22319] Evidence pack

[22321] DEIA screen

## Toolkit [22324]

[22326] All assets

[22328] Metadata catalogue

[22330] Assurance model

[22332] Quantum readiness

## Standards [22335]

[22337] Resource library

[22339] Authority tiering

[22341] Code of practice

[22343] Glossary and FAQ

## Accountability [22346]

[22348] Transparency and governance

[22350] Accessibility commitments

[22352] Roadmap and gaps

[22354] Report a problem

## Key external sources [22357]

[22359] GOV.UK Service Manual (opens an external website)

[22362] GOV.UK Design System (opens an external website)

[22365] WCAG 2.2 (opens an external website)

[22368] NCSC secure AI (opens an external website)

[22371] ICO AI guidance (opens an external website)

[22996] Colophon: one portal, generated in part from data/playbook.json · version 3.4.0 · 2026-11-22 · Figtree typeface under the SIL Open Font Licence · CC BY 4.0 (content) / MIT (code)

