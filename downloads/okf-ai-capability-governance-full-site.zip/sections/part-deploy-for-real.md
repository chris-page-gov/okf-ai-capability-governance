---
type: publisher-section
title: Deploy for real
status: draft
sources:
- title: Deploy for real
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-deploy-for-real
x-dom-section: part-deploy-for-real
---

# Deploy for real

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-deploy-for-real)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[15361] Part 11 of 12 · 4 chapters

## Deploy for real [15362]

[15371] Deploy for real · where the work actually is

## Fifty-four public services, placed [15372]

[15373] The highest-volume services across UK central government, local government and the NHS, placed on two axes that decide almost everything else: how much of it there is, and what happens when it is wrong. Select a quadrant or a factor to filter. Open any service to load it into the generator.

[15375] 54 services 4 quadrants 10 factors 27 land in Tier 4 34 sit in the dangerous quadrant

[15381] One agent, end to end, in each quadrant

[15382] Filter by factor

## Services [15385]

[15387] 54 of 54 shown

## How to read this, and how not to [15389]

[15390] Volume bands come from published transaction data; criticality and the factor tags are an assessment of consequence, not a classification you can cite. The value is not the placement — it is that placing a service forces a conversation about consequence that a business case usually skips. Move anything you disagree with, and record why you moved it.

[15391] Back to the contents · Suggest a correction (opens GitHub)

[15403] Deploy for real · working tool

## Derive the governance set for any agent [15404]

[15405] Two bands and ten factors in. Tier, autonomy cap, oversight regime, currency window, evaluation set, threat priorities, DPIA route, contract clauses, workforce actions, register fields and kill criteria out — with the rules that produced them, so the answer can be argued with rather than accepted.

## Volume [15409]

## Criticality [15411]

## Extended factors [15415]

[15417] No factors selected

[15421] Q1

## Automate with sampling [15423]

## Tier 1 · Light [15425]

[15426] The strongest agent case in government. Volume pays for the governance; a mistake is recoverable. The risk here is not harm, it is quietly losing the ability to do the work.

[15429] Effective criticality

## 1 / 14 [15430]

[15432] Autonomy cap

## L4 [15433]

[15434] Act with post-hoc sampling — exceptions escalate

[15436] Challenge-rate floor

## 0.5% [15437]

[15438] Below this, suspect oversight, not excellence.

[15440] Sign-off

## Service owner [15441]

## Oversight regime [15444]

[15445] 2% random sample, weekly

## Data protection route [15447]

## Screening assessment, recorded and dated [15448]

[15449] A screening that concludes no full DPIA is needed is still evidence. Keep it, and re-run it when scope changes.

## Evaluations that must exist [15452]

## Golden-set regression [15453]

[15454] A frozen set of real historical cases with agreed correct outputs, re-run on every model or prompt change.

## Refusal and out-of-scope set [15455]

[15456] Cases the agent must decline, escalate or flag rather than attempt.

## Cost and latency envelope [15457]

[15458] Per-transaction cost and response time, with the ceiling that triggers review.

## Threat priorities [15460]

[15461] Prompt injection via ingested content High

[15464] Any document, email or record the agent reads is untrusted input. Test with adversarial content in every ingestion path.

[15465] Tool over-permission High

[15468] The agent holds broader credentials than its task needs. Scope per action, not per agent.

## Contract clauses that become mandatory [15471]

## Model change notification [15472]

[15473] Written notice before any model, weight or default change that affects behaviour, with a defined notice period.

## Log and evidence export [15474]

[15475] All prompts, outputs, tool calls and decisions exportable in a documented open format, during and after the contract.

## No training on our data [15476]

[15477] Explicit prohibition, with the right to evidence of compliance.

## Exit and portability [15478]

[15479] Prompts, instruction blocks, eval sets and grounding indexes are ours, exportable, and documented well enough to rebuild elsewhere.

## Workforce actions [15481]

## Say where the freed capacity went [15482]

[15483] Volume automation releases hours. Publish where they were redeployed. Unnamed savings become quiet headcount reduction with no decision behind it.

## Consultation before design freeze [15484]

[15485] Staff and unions see the job-redesign proposal while it can still change. After the build is a briefing, not a consultation.

## Register fields beyond the baseline [15488]

## Accountable officer [15489]

[15490] A named person, not a team or a role inbox.

## Reversal path [15491]

[15492] How an effect is undone, tested, with the last test date.

## Currency holders [15493]

[15494] Who currently holds valid approval authority, and when each window expires.

## Kill criteria [15496]

## Challenge rate falls below floor [15497]

[15498] Reviewers overturning less than 0.5% of outputs. Either the agent is perfect or oversight has stopped. Assume the second.

## Golden-set regression unexplained [15499]

[15500] Any drop on the frozen set that cannot be explained and fixed within the rollback SLA.

## An outcome nobody can explain [15501]

[15502] A single decision the accountable officer cannot account for in plain language.

## Why it produced that answer [15504]

[15506] Low criticality sets a base of 1.

[15507] Effective criticality 1 of 14 places this in Tier 1 · Light.

[15508] Very high volume with low criticality places this in Q1 · Automate with sampling.

[15509] The weights are a defensible starting point, not a measured value. Change them with your assurance function and record the change — a tool whose reasoning is hidden cannot be challenged, and a governance answer nobody can challenge is not governance.

[15510] Back to the contents · Suggest a correction (opens GitHub)

[15522] Deploy for real · four agents, one per quadrant

## Correspondence triage, mandate to operation [15523]

[15524] Every artefact filled in, including the ones that are uncomfortable. Very high volume, moderate criticality — the case most departments would call easy. Named honestly it lands in Tier 3 · Enhanced , and that is the most useful thing in this chapter.

[15527] These four agents are composites, not case studies. The figures are internally consistent and illustrative, and the decisions are the ones the sources support. Your organisation will ratify and adapt every one of them.

## Mandate [15531]

## 1 of 10 [15533]

[15534] Signed by the service owner before any build. One page, and it fits.

## Problem [15537]

[15539] Inbound correspondence arrives across six channels into one queue. Median time to first correct routing is four days; 11% is routed wrong at least once. Statutory deadlines are met by escalation, not by process.

## In scope [15542]

[15544] Classify inbound correspondence to one of 34 work queues, extract sender, reference, subject and any stated deadline, and draft a suggested reply from the approved template set.

## Explicitly out of scope [15547]

[15549] Deciding any case. Sending anything. Replying to anyone. Handling correspondence flagged as a complaint, a legal threat, a safeguarding concern or a data-subject request — those route to a human unopened by the agent.

## Success measures [15552]

[15554] Time to correct routing, misroute rate, deadline breaches, and reviewer challenge rate. Not volume processed, and not staff satisfaction alone.

## Decision rights [15557]

[15559] The agent proposes. A caseworker commits. Nothing leaves the organisation without a named person attached to it.

## Funding and duration [15562]

[15564] Twelve months, one delivery team, with a stop point at month four and a re-authorisation decision at month twelve.

## What would make us stop [15567]

[15569] Any statutory deadline missed because of the agent, or a challenge rate below 5% sustained for two months.

## What changes the answer inside this quadrant [15571]

[15572] Same agent, same quadrant, one factor different. Each variant below is scored by the generator on this page, not asserted — so what moves and what does not is the tool's own arithmetic.

[15574] The agent sends the reply itself Tier moves

[15577] + Irreversible Tier 4 · Critical Q1 · Automate with sampling L1 · Draft only — a person edits and commits every output

[15582] One word in the mandate — send rather than draft — and an effect exists that no later correction undoes. Autonomy is forced to draft-only regardless of tier, and shadow mode becomes mandatory. This is the most common scope change requested after go-live, and the cheapest one to refuse.

[15584] Correspondence routinely contains health detail Tier moves

[15587] + Special-category data Tier 4 · Critical Q1 · Automate with sampling L1 · Draft only — a person edits and commits every output

[15592] The screening guardrail stops being a nicety and becomes the control the DPIA rests on. A leakage probe joins the evaluation set, and the grounding index has to be provably free of the material.

[15594] Internal-only queue, rule-based routing Tier moves

## − Discretionary judgement [15599]

## − Vulnerable users [15601]

## Tier 2 · Standard [15603]

## Q1 · Automate with sampling [15605]

## L3 · Act within guardrails — every action logged and sampled [15607]

[15608] Remove the discretion and the vulnerable recipient and the same agent, at the same volume, drops a tier. Most of the governance in the worked example is paid for by those two factors, not by the volume.

[15609] Back to the contents · Suggest a correction (opens GitHub)

[15621] Deploy for real · scope boundary

## What this guide does not cover [15622]

[15623] A guide that does not state its boundary strands the team at the point where the interesting problems start. This chapter exists so nobody reaches gate 3 believing the architecture, the security testing or the legal advice was somewhere in the earlier parts.

## Fully covered here [15626]

[15627] Principles, criticality and tiering, autonomy boundaries, registers and transparency records, oversight design including currency, cost and value modelling, roles and adoption, the pilot method.

## Structured, needs your content [15629]

[15630] Instruction blocks, evaluation plans, threat profiles, DPIA routes, contract clause sets, job redesign. The shape is here; the substance is yours.

## Named but not solved [15632]

[15633] Reference architecture for your estate, engineering pipeline, executed security testing, model selection, sector regulation, organisational design, safety cases.

## What a team must bring [15634]

[15635] Eight things this guide names but cannot supply. Each one has a normal home in an organisation. Find the home before the build starts, not after.

[15637] A target architecture for your estate Enterprise architecture

[15640] This guide names what an architecture must satisfy. It does not know your identity provider, your network, your data platform or your existing contracts. Someone with authority over those has to draw it.

[15642] Executed security testing Security function or an appointed third party

[15645] The threat model here tells you what to test. Running the test — penetration testing, red-teaming, adversarial evaluation — is specialist work with a report at the end of it.

[15647] Legal advice on your specific case Legal and your DPO

[15650] Everything here about lawful basis, automated decision-making and liability is structure for a conversation with a lawyer. It is not the advice.

[15652] Model selection and benchmarking Technical owner

[15655] Which model, at what cost, with what evaluation on your data. This guide is deliberately model-agnostic, which means it cannot answer the question you will be asked first.

[15657] Sector regulation Your regulator and legal

[15660] Health, policing, immigration, education and financial services each carry duties this guide does not enumerate. Where it conflicts with your regulator, your regulator wins.

[15662] Organisational design Accountable leadership

[15665] Who reports to whom, which team holds the capability, and how it is funded past the pilot. The roles here are role names; you have people, budgets and politics.

[15667] Accessibility conformance Accessibility specialist

[15670] The comprehension and inclusion tests here are necessary and not sufficient. A conformance audit against WCAG is a separate, evidenced exercise.

[15672] Safety cases Clinical or safety governance

[15675] Where an agent touches physical safety or clinical outcomes, a structured safety case is required and this guide does not contain one.

## Five things to be honest about [15677]

[15678] Read these before citing anything in this guide to a board, an auditor or a regulator.

## Every artefact here is a proposal [15679]

[15680] Nothing in this guide has statutory force. Until your organisation ratifies it, an artefact is a well-argued suggestion. Ratify it, or expect it to be ignored at the first disagreement.

## Figures marked illustrative are illustrative [15681]

[15682] Where this guide shows a threshold, a percentage or a band, it is a defensible starting point drawn from the sources, not a measured value from your service. Replace it with yours.

## Volume and criticality placements are judgements [15683]

[15684] The fifty-four services in the atlas are placed on published volume bands and an assessment of consequence. They are a starting position for an argument, not a classification you can cite.

## The generator does not approve anything [15685]

[15686] It derives a consistent governance set from the inputs you give it. Give it flattering inputs and it will produce a flattering answer. That is a property of every assessment tool, including the ones with logos on.

## The four worked examples are composites [15687]

[15688] They are built from the sources, from published service data and from patterns that recur across deployments. They are not case studies of four real agents, and no organisation in them is identifiable. Their numbers are internally consistent and illustrative — treat them as a model answer to compare your own against, not as evidence of what happened somewhere.

## Sequence is not schedule [15689]

[15690] The life cycle here is ordered. It carries no durations, because the honest answer depends on your assurance capacity, and that is the constraint nobody plans for.

[15691] Back to the contents · Suggest a correction (opens GitHub)

