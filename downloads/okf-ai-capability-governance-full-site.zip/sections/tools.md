---
type: publisher-section
title: Do the work here, not in a separate spreadsheet
status: draft
sources:
- title: Do the work here, not in a separate spreadsheet
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#tools
x-dom-section: tools
---

# Do the work here, not in a separate spreadsheet

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#tools)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Do the work here, not in a separate spreadsheet [18953]

[18954] Six tools that turn the guidance into an artefact you can paste into a ticket, a change record or a board paper. Everything runs in your browser — nothing you type is sent anywhere, stored or transmitted.

[18960] Privacy by design: these tools are client-side only. Do not enter personal data, case details or anything above OFFICIAL. Use references and descriptions instead.

[18963] 1. Human review triage — what level of oversight does this need?

[18967] About the output

[18969] What is the AI helping you produce?

[18972] Who will see or be affected by it?

[18974] Only me

[18975] My immediate team

[18976] My organisation

[18977] External partners or suppliers

[18978] Members of the public

[18980] If it were wrong, what is the worst realistic consequence?

[18982] Wasted personal time only

[18983] Internal rework

[18984] Reputational or financial harm to the organisation

[18985] Unfair or inaccessible treatment of a group

[18986] Harm to an individual’s rights, entitlements, safety or health

[18988] Highest data classification involved

[18990] None / public

[18991] Internal, non-personal

[18992] Personal data

[18993] Special category or criminal offence data

[18994] OFFICIAL-SENSITIVE or higher

[18996] How reversible is the outcome?

[18998] Instantly reversible

[18999] Reversible with effort

[19000] Hard or impossible to reverse

[19002] Does any of the following apply?

[19005] It informs or automates a decision about a person

[19008] It will be published or is disclosable under FOI

[19011] It is code, configuration or infrastructure that will reach production

[19014] It involves statistics, legal, clinical, financial or safety content

[19017] An agent will act autonomously using tools or credentials

[19020] The subject matter is outside my professional competence

[19021] Get my review level

[19023] Your result will appear here.

[19025] Copy result

[19026] Reset

[19028] 2. AI-use declaration and evidence pack generator

[19030] Produces a copy-ready record. Attach it to the artefact, the ticket or the change record.

[19033] Artefact or reference

[19036] Your role

[19039] Tool and model version used

[19042] Human review level applied

[19044] H0

[19045] H1

[19046] H2

[19047] H3

[19048] H4

[19049] H5

[19051] Extent of AI assistance

[19055] Sources consulted and verified (one per line)

[19058] Checks performed

[19061] Data definitions the output relied on (agent answers only, one per line)

[19065] Reviewer(s) and role

[19068] Residual risk or limitation

[19070] Generate declaration

[19072] Your result will appear here.

[19074] Copy result

[19075] Reset

[19077] 3. DEIA impact screen — equality, accessibility and inclusion

[19079] A screening tool, not a substitute for a full equality impact assessment. It tells you whether you need one.

[19082] What is changing?

[19085] Tick everything that could apply

[19088] The change could affect people differently by age, disability, race, sex, religion, pregnancy, gender reassignment, sexual orientation, marriage or civil partnership

[19091] Training data, prompts or sources may under-represent some groups

[19094] Outputs will be read by the public or by people with access needs

[19097] The service is used by people who are digitally excluded or need assisted digital support

[19100] It affects people in vulnerable circumstances, in crisis, or at risk of harm

[19103] Language, literacy, numeracy or reading age could be a barrier

[19106] It replaces or reduces a human contact route

[19109] There is no easy way for someone to challenge or appeal the outcome

[19112] Welsh language or other alternative formats may be required

[19115] We have not yet tested with disabled users or assistive technology

[19116] Screen this change

[19118] Your result will appear here.

[19120] Copy result

[19121] Reset

[19123] 4. Transparency record generator (ATRS-shaped)

[19125] Drafts a public-facing record of how an algorithmic or AI tool is used. Publish it, and link it from the service.

[19128] Tool name

[19131] Organisation and owner

[19134] What it does, in plain English

[19137] Role in the decision

[19139] Assists a human who decides

[19140] Recommends, human confirms

[19141] Automates a step, human can override

[19142] Fully automated decision

[19144] Scale of use

[19147] Data used

[19150] Known risks and mitigations

[19153] How someone can question or challenge the outcome

[19155] Generate transparency record

[19157] Your result will appear here.

[19159] Copy result

[19160] Reset

[19162] 5. Quantum readiness and crypto-agility assessor

[19166] How long must this data stay confidential?

[19168] Under 1 year

[19169] 1–5 years

[19170] 5–10 years

[19171] More than 10 years, or lifelong (health, identity, security)

[19173] Tick what is true today

[19176] We have no complete inventory of where cryptography is used

[19179] Algorithms are hard-coded or embedded in third-party products we cannot change quickly

[19182] Data travels over networks that a capable adversary could record

[19185] We rely on RSA or elliptic-curve key exchange with no PQC migration plan

[19188] Long-life signatures (certificates, firmware, legal records) are in scope

[19191] Suppliers have not been asked about their PQC roadmap

[19192] Assess exposure

[19194] Your result will appear here.

[19196] Copy result

[19197] Reset

[19199] 6. Plain-language and inclusive content checker

[19201] Paste AI-drafted content to check reading difficulty, sentence length, jargon and non-inclusive phrasing before publication.

[19203] Content to check

[19206] Check this content

[19208] Your result will appear here.

[19210] Copy result

[19211] Reset

