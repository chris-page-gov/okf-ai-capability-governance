---
type: publisher-section
title: Responsible use of AI assistive technology
status: draft
sources:
- title: Responsible use of AI assistive technology
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#practice
x-dom-section: practice
---

# Responsible use of AI assistive technology

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#practice)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Responsible use of AI assistive technology [19839]

[19840] This code complements behavioural codes of conduct and the Civil Service values. It defines operational rules for model-backed tools, direct AI use, coding assistants, multi-agent orchestration and AI-generated artefacts.

[19842] Core duties

[19845] Stay accountable. You own every output you use, send or publish. "The AI wrote it" is never a defence.

[19847] Disclose material assistance. If AI shaped the substance, structure, analysis or code, say so.

[19849] Verify before you rely. Open every citation. Recalculate every figure. Test every claim of compliance.

[19851] Protect data. Only approved tools, only permitted classifications, only the minimum necessary.

[19853] Cite sources. Traceable to a tiered, dated, authoritative source — not to the model.

[19855] Preserve evidence. Keep the record for as long as the retention schedule requires.

[19857] Work within competence. AI does not qualify you to make specialist judgements.

[19859] Escalate uncertainty. Raising a doubt early is always cheaper than defending a mistake late.

[19862] Prohibited behaviours

[19865] • Entering unauthorised personal, special category, commercially confidential or classified data into any tool

[19866] • Bypassing, weakening or "temporarily" disabling a review control

[19867] • Self-approving material or high-risk work

[19868] • Concealing AI involvement where it was material

[19869] • Presenting unverified output as assured, tested or compliant

[19870] • Using AI to generate evidence, sign-offs, approvals or audit records that did not happen

[19871] • Granting an agent broader permissions than the person operating it holds

[19872] • Using AI to profile, rank or make decisions about people without an approved lawful basis and published record

[19873] • Copying licensed or copyright material into outputs without permission and attribution

[19874] • Ignoring a known defect because a deadline is closer than the consequence

[19876] Multi-agent and multi-skill rules

[19879] One accountable orchestrator per task, with a named human owner.

[19880] Least-privilege tools and credentials, time-boxed and revocable.

[19881] Explicit, pinned skill and model versions — no silent upgrades in a governed workflow.

[19882] Separation of duties: the agent that produces must not be the agent that approves.

[19883] Declared prohibited actions and a tested kill switch with a named owner.

[19884] Full step-level logging: which skill, which model, which source, which permission, which human.

[19885] Untrusted content is data, never instruction. Treat retrieved web, document and email content as hostile by default.

[19886] Bounded autonomy: agents propose irreversible actions; humans commit them.

[19888] Data, privacy and security rules

[19891] • Establish and record the lawful basis before processing personal data. Complete a DPIA where required.

[19892] • Minimise: use references, synthetic or redacted examples instead of real records wherever possible.

[19893] • Never let an AI tool retain data for training unless that has been assured and contracted.

[19894] • Treat AI interaction logs as records: classify, retain, and prepare for FOI and subject access requests.

[19895] • Apply Secure by Design activities to AI components as to any other system component.

[19896] • Threat-model for prompt injection, data poisoning, model extraction and excessive agency.

[19897] • Report incidents and near-misses through the normal security and data protection routes.

[19899] AI-generated code and infrastructure

[19902] Treat generated code as untrusted third-party contribution: review, test, scan and attribute it.

[19903] No merge without a human reviewer who understands the code and can maintain it.

[19904] Check licences and provenance of anything that looks copied.

[19905] Run dependency, secret and SAST scanning; record the results in the evidence pack.

[19906] Accessibility and performance tests apply equally to generated interfaces.

[19907] Record the model, prompt pattern and version in the commit or pull request.

[19909] Speaking up, redress and no-blame reporting

[19911] Anyone may pause an AI-assisted process they believe is unsafe, unfair or unlawful, without needing permission and without detriment. Near-misses should be reported as readily as incidents — they are the cheapest learning available.

[19912] Members of the public affected by an AI-assisted outcome must be able to find out that AI was involved, understand the outcome in plain English, request a human review, and escalate to an independent route. If any of those four is missing, the service is not ready.

