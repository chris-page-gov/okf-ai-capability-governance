---
type: publisher-section
title: Product documentation
status: draft
sources:
- title: Product documentation
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-product-documentation
x-dom-section: part-product-documentation
---

# Product documentation

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-product-documentation)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[13710] Part 9 of 12 · 8 chapters

## Product documentation [13711]

[13720] Delivery documentation · PRD

## Product requirements [13721]

[13722] What this guide is for, who it serves, what it must do and what it deliberately does not do. Derived from published guidance and community discussion; a proposal, not an adopted product mandate.

## Problems worth solving [13724]

[13725] Each problem is visible in the source material rather than assumed.

## Guidance is real but scattered [13727]

[13728] The AI Playbook, Service Standard, TCoP, ATRS, NCSC secure-AI guidelines, ethics frameworks and FinOps practice exist separately. Teams reassemble them from scratch, inconsistently, each time.

## Experimentation outruns governance [13730]

[13731] Personal assistants become shared agents and then business-critical dependencies without registration, named ownership, assurance or funded support.

## Cost is discussed as licences [13733]

[13734] Token and licence spend is visible; data remediation, workflow redesign, assurance, human review, monitoring, support and exit are not costed or owned.

## Evidence is claimed, not demonstrated [13736]

[13737] The same product yields different results under different evaluation methods, so headline productivity figures travel further than the method that produced them.

## Community knowledge decays [13739]

[13740] Sessions, transcripts, repositories and personal networks hold the learning; there is no shared discovery layer, taxonomy or evidence pack, so lessons are relearned.

## Goals and how each is judged [13741]

## One route from mandate to governed operation [13744]

[13745] A reader can go from no policy position to a registered, assured, monitored agent using only this guide.

## All eight start-here stages have a chapter and a tool [13746]

## Make the invisible costs visible [13748]

[13749] Every cost class in the investment line is named, owned and modelled.

## Cost lab produces a per-run and monthly figure with review effort included [13750]

## Proportionate assurance, not blanket control [13752]

[13753] Criticality drives the gate; low-risk work stays fast.

## Five tiers with stated evidence and review frequency [13754]

## Evidence before assertion [13756]

[13757] Claims carry method, publisher and date; illustrative material is labelled.

## Every figure in the guide is attributed or marked illustrative [13758]

## Reusable artefacts, not prose [13760]

[13761] Register schema, ATRS record, instruction block and evidence card can be copied out and used.

## Four artefacts exportable or copyable [13762]

## Accessible to every role [13764]

[13765] Leaders, engineers, assurance, commercial, finance and frontline staff each have a path.

## Role pathways cover the twelve priority roles [13766]

## In scope [13769]

[13770] Guidance synthesis and chapter navigation

[13771] Assessment tools (readiness, criticality, tiers, maturity, quality gate)

[13773] Register and ATRS record schemas

[13774] Cost and unit-economics modelling

[13775] Skill instruction builder

[13776] Evidence, use-case and international comparison libraries

[13777] Illustrative portfolio dashboard

[13778] Delivery documentation set (this part)

## Out of scope [13780]

[13782] Holding the authoritative record of any live deployment

[13783] Storing personal or OFFICIAL-SENSITIVE data

[13784] Connecting to tenant telemetry, licensing or billing systems

[13785] Issuing approvals or acting as the assurance authority

[13786] Publishing ATRS records on behalf of an organisation

[13787] Replacing or overriding central or departmental guidance

## Non-functional requirements [13788]

[13793] Accessibility WCAG 2.2 AA: contrast, focus visibility, keyboard operation, reduced-motion, semantic headings and labels.

[13795] Information handling OFFICIAL working content only. No personal data, no case data, no credentials. Assessment answers stay on the reader's device.

[13797] Portability Runs as a single file in a browser with no build step, no backend and no network dependency beyond fonts and cited links.

[13800] Performance First paint before the whole document streams; interactions respond within one frame budget on a standard civil-service laptop.

[13802] Provenance Crown-copyright content reused under the Open Government Licence v3.0, with publisher and date on every figure.

[13804] Print and export Chapters print legibly; the register schema and instruction block copy to the clipboard as plain text.

## Release phases [13806]

[13809] Now

## Phase 1 — proposal [13810]

[13811] This guide, reviewed by the community, with illustrative figures clearly labelled.

[13813] Next

## Phase 2 — validated [13814]

[13815] Illustrative figures replaced with measured departmental data; international benchmarking executed.

[13817] Later

## Phase 3 — adopted [13818]

[13819] Referenced in departmental AI policy, with the register schema and assurance gates in operational use.

## Risks to the product itself [13820]

## Illustrative figures read as measured High [13823]

[13825] Label every illustrative frame; keep publisher and date on evidence; publication checkpoint before circulation.

## Guide treated as authority Medium [13828]

[13830] Proposal status on the landing chapter and in the hierarchy; explicit statement that it does not override guidance.

## Content drifts from source guidance High [13833]

[13835] Chapter-to-source map; review date per chapter; ticker tracks guidance in force.

## Assessment answers mistaken for assurance Medium [13838]

[13840] Device-only storage, no scoring authority claimed, evidence-based maturity rather than self-scored levels.

[13841] Back to the contents · Suggest a correction (opens GitHub)

[13853] Delivery documentation · FTIR specification

## Functional, technical and integration requirements [13854]

[13855] Numbered requirements with priority, traceable to the chapters that satisfy them. Must, should and could follow the usual prioritisation convention.

## Functional [13857]

## FR-01 [13860]

[13862] Navigate 69 chapters in eleven numbered parts with contents, previous, next and sibling links

[13864] Must

## FR-02 [13867]

[13869] Search every chapter, principle, gate, register field, role and source from one field

[13871] Must

[13872] FR-03 Record which chapters have been opened and show progress Should

## FR-04 [13878]

[13880] Rate readiness across eight dimensions and return a banded barometer

[13882] Must

[13883] FR-05 Determine an assurance tier from a two-question intake Must

## FR-06 [13889]

[13891] Score agent criticality across ten dimensions and derive the gate

[13893] Must

[13894] FR-07 Score barriers by impact and likelihood and band the result Should

## FR-08 [13900]

[13902] Model cost per run and per month across models, languages and volumes

[13904] Must

## FR-09 [13907]

[13909] Model unit economics: value per interaction, net value and return

[13911] Must

[13912] FR-10 Build a seven-part instruction block and copy it out Must

## FR-11 [13918]

[13920] Assess evidence strength per capability domain across seven maturity levels

[13922] Should

[13923] FR-12 Step a failure and recovery loop, marking stages complete Should

## FR-13 [13929]

[13931] Present the eighteen-field register schema and the eight-section ATRS record

[13933] Must

## FR-14 [13936]

[13938] Show an illustrative portfolio dashboard with lifecycle, assurance, risk and domain views

[13940] Could

## Technical [13941]

## TR-01 [13944]

[13946] Single-file browser document; no build step, bundler or server runtime

[13948] Must

## TR-02 [13951]

[13953] All state in memory; only the readiness barometer persists, in localStorage on the reader's device

[13955] Must

[13956] TR-03 Inline styling so content paints as it streams Must

## TR-04 [13962]

[13964] Keyboard access for every control; visible focus; reduced-motion honoured

[13966] Must

## TR-05 [13969]

[13971] Contrast at or above 4.5:1 for text and 3:1 for meaningful non-text

[13973] Must

[13974] TR-06 No third-party analytics, cookies or tracking Must

## TR-07 [13980]

[13982] External links open in a new tab with noopener and carry publisher and date

[13984] Should

## TR-08 [13987]

[13989] Deterministic calculations — same inputs, same outputs, no model calls

[13991] Must

## Integration [13992]

## IR-01 [13995]

[13997] Register schema aligns field-for-field with the ATRS record sections

[13999] Must

## IR-02 [14002]

[14004] Register, information asset register and data catalogue treated as three integrated registers, not duplicates

[14006] Must

## IR-03 [14009]

[14011] Criticality score maps to the five assurance gates and their evidence requirements

[14013] Must

## IR-04 [14016]

[14018] Cost model outputs feed the investment line and FinOps allocation layers

[14020] Should

[14021] IR-05 Instruction block output is platform-neutral plain text Must

[14025] IR-06 Chapters cite the guidance in force and carry a review date Must

## IR-07 [14031]

[14033] Links out to the AI Engineering Lab, AI Knowledge Hub and departmental policy rather than copying them

[14035] Should

## IR-08 [14038]

[14040] Sits alongside the govukOS twin front door and portals as one app in a shared shell

[14042] Should

[14043] Back to the contents · Suggest a correction (opens GitHub)

[14055] Delivery documentation · SAD

## Solution architecture [14056]

[14057] Principles, context, layers and the decisions that shaped them. The architecture is deliberately small: the guide holds interpretation, never the record of a live deployment.

## Architectural principles [14059]

## Guidance is referenced, not copied [14062]

[14063] Link to the governed source; hold interpretation and sequence here.

## No shadow record [14065]

[14066] The guide never becomes the register of record for a live deployment.

## Client-side by default [14068]

[14069] No backend means no new data controller, no new attack surface, no new service to run.

## Accessible before decorative [14071]

[14072] Contrast, focus and keyboard behaviour are acceptance criteria, not polish.

## Evidence carries method [14074]

[14075] Every figure states publisher, date and method, or is labelled illustrative.

## Open by default [14077]

[14078] Crown-copyright content under OGL v3.0; the guide itself is reusable and adaptable.

## Context — actors and their part [14079]

[14080] Reader Civil servant in one of the twelve priority roles Reads chapters, runs assessments, copies artefacts

[14084] Owning organisation Department, agency, council or health body Holds the register of record, policy and approvals

[14088] Central guidance GDS, DSIT, NCSC, CDDO successor functions Publishes the guidance this guide interprets

## Community [14094]

[14096] Cross-government Copilot forum, AI Engineering Lab, ethics and data communities

[14098] Supplies patterns, failures and supplier intelligence

[14099] Suppliers Platform, model and integration providers Subject of dependency, exit and commercial chapters

[14103] govukOS shell Twin front door and sibling portals Hosts the guide as one app among several

## Logical layers [14107]

## Experience [14110]

[14112] Masthead, ticker, drawer, chapter rail, contents, chapter body, footer navigation

[14113] Chapter registry Parts, chapters, numbering, accents, icons, read state

## Content [14118]

[14120] Source-derived data: principles, gates, domains, roles, tiers, schemas, dashboards

## Assessment logic [14123]

[14125] Barometer, criticality, tiers, maturity evidence, quality gate, barrier scoring

## Economics [14128]

[14130] Token maths, language multipliers, unit economics, allocation layers

## Local state [14133]

[14135] In-memory interaction state plus one persisted barometer record on the device

## Decisions [14136]

[14138] ADR-01

## Single-file client-side document [14139]

[14140] No hosting, no data processing agreement, no service to operate; trades server-side features for portability.

[14142] ADR-02

## No personal or case data anywhere [14143]

[14144] Removes the need for a DPIA on the guide itself; assessments stay on the device.

[14146] ADR-03

## One artefact, many chapters [14147]

[14148] Keeps navigation, search and cross-references coherent; avoids a fragmented document set.

[14150] ADR-04

## Illustrative data labelled, never silently synthetic [14151]

[14152] Protects the evidence boundary this playbook sets out.

[14154] ADR-05

## Accent colour per part [14155]

[14156] Gives readers a positional cue; all accents are contrast-tested as text.

[14157] Back to the contents · Suggest a correction (opens GitHub)

[14169] Delivery documentation · HLD

## High-level design [14170]

[14171] Components, the entities they work on, and the four flows that carry most of the value.

## Components [14173]

## Shell [14176]

[14177] Masthead, guidance ticker, launchpad, search field

## Holds identity and cross-app links [14178]

## Navigation [14180]

[14181] Drawer with parts and chapters, chapter rail, contents overlay, prev/next

## Owns chapter numbering and read state [14182]

## Chapter renderer [14184]

[14185] One section per chapter, streamed in order

## Eyebrow, accent title, lede, body blocks [14186]

## Assessment engine [14188]

[14189] Barometer, criticality radar, tier finder, maturity evidence, quality gate

## Pure functions over local state [14190]

## Economics engine [14192]

[14193] Token cost, language multiplier, unit economics, allocation layers

## Deterministic arithmetic, GBP formatting [14194]

## Artefact builders [14196]

[14197] Instruction block, register schema, ATRS record, evidence card

## Copy-to-clipboard output [14198]

## Search index [14200]

[14201] Flat index of chapters, principles, gates, fields, roles, sources

## Substring match with type and destination [14202]

## Dashboard [14204]

[14205] Illustrative portfolio control tower

## Read-only, clearly labelled illustrative [14206]

## Entities [14207]

[14208] Chapter id, part, number, title, icon, accent, read Navigation and progress

[14212] Blueprint title, source, ingest date, chapters it feeds Provenance and coverage

[14216] Assessment dimension, score, band, timestamp Barometer and maturity evidence

[14220] Register record 18 fields from identity to retirement The record an organisation holds

[14224] ATRS record 8 sections, each with its own fields Transparency record per agent

[14228] Cost scenario tokens in/out, prices, tools, infra, review effort, volume Cost and unit economics

[14232] Instruction block goal, context, sources, task, format, guardrails, output Skill injection

## Key flows [14236]

[14239] Read a chapter Drawer or contents → chapter renders → read state recorded → next chapter offered

[14242] Assess readiness Rate eight dimensions → band computed → stored on device → shown in the drawer workspace

[14245] Tier an agent Two intake questions → tier → gate, controls, evidence and review frequency shown

[14248] Price a job Enter words in and out, model, language, volume → per-run and monthly cost → unit economics

[14250] Back to the contents · Suggest a correction (opens GitHub)

[14262] Delivery documentation · LLD

## Low-level design [14263]

[14264] Module responsibilities, the arithmetic behind every score, the validation rules and the accessibility implementation. Enough for someone else to rebuild the behaviour exactly.

## Modules and their state [14266]

## Navigation module [14269]

[14271] groupDefs → flat chapter list → numbering, accents, prev/next, contents

[14273] section, groups, read, toc

[14274] Barometer module eight dimension scores → mean → band with colour and label scores (persisted)

[14278] Criticality module ten dimension scores → total → tier and gate mapping crit, gateTier

[14282] Barrier module impact × likelihood → 1–25 → four bands bar

## Economics module [14288]

[14290] tokens = words ÷ 0.75; cost = in×priceIn + out×priceOut + tools + infra + review

[14292] lab, ue

[14293] Instruction module seven fields → composed block → clipboard blk, copied

## Algorithms [14297]

## Barometer banding [14299]

[14300] mean of rated dimensions; 0–0.9 Nascent, 1.0–1.9 Emerging, 2.0–2.4 Establishing, 2.5–3.0 Leading; unrated dimensions excluded from the mean and reported as unrated.

## Criticality to gate [14302]

[14303] sum of ten dimensions scored 1–5; 10–20 personal, 21–30 team, 31–38 departmental, 39–44 operational service, 45–50 citizen impact.

## Barrier banding [14305]

[14306] impact × likelihood on 1–5 scales; 1–3 low, 4–8 medium, 9–15 high, 16–25 critical.

## Unit economics [14308]

[14309] value per interaction = (minutes saved ÷ 60 × hourly rate) × quality factor; net = value − cost; return = net ÷ cost expressed as a percentage.

## Validation rules [14312]

[14313] Numeric inputs Clamp to declared minimum and maximum; reject non-numeric silently rather than throwing.

[14315] Unrated dimensions Show an em dash, never a zero, and exclude from means.

[14317] Currency Two decimal places, pound sign, thousands separated; never rounded away in totals.

[14319] Clipboard Plain text only; confirm with a transient state, no alert.

[14321] Persistence One key, versioned; parse defensively and fall back to blank on any error.

## Accessibility implementation [14324]

[14325] Colour Every text and meaningful non-text pair contrast-tested; accents have separate text-safe variants where a fill carries text.

[14327] Keyboard All controls are buttons or inputs; aria-pressed and aria-current reflect state; focus ring never suppressed.

[14329] Motion The guidance ticker pauses on hover and respects prefers-reduced-motion.

[14331] Structure One h1 per chapter, sequential headings, aria-labels on sections, skip link to content.

[14333] Language British English, plain terms, expanded acronyms on first use in a chapter.

[14335] Back to the contents · Suggest a correction (opens GitHub)

[14347] Delivery documentation · theory of change

## Theory of change [14348]

[14349] From inputs to impact, with the assumptions each step rests on. Written so the chain can be falsified: if an assumption fails, the link it supports fails with it.

## Inputs [14352]

[14353] Central guidance in force Community evidence and patterns Evaluation studies Departmental policy and delegated authority Funded time from named roles

## Activities [14360]

[14361] Synthesise guidance into sequenced chapters Build assessment and costing tools Publish register and ATRS schemas Run role-based capability pathways Return findings to the community

## Outputs [14368]

[14369] One navigable implementation guide Completed readiness and criticality assessments Registered agents with named owners Costed business cases including hidden costs Reusable evidence cards and patterns

## Short-term outcomes [14376]

[14377] Teams find the applicable guidance quickly Proportionate assurance replaces blanket caution Agents have owners, tiers and review dates Cost conversations include people and exit

## Medium-term outcomes [14383]

[14384] Fewer orphaned and unregistered agents Duplicated procurement and assurance effort falls Evidence is reused across organisations Oversight is continuous, not one-off

## Impact [14390]

## Governed AI-enabled services that create demonstrable public value [14393]

## Sustained public trust in how government uses AI [14395]

## Each row depends on the one above it holding. Outcomes are claimed only where evidence exists; everything below outputs is currently a proposal. [14397]

## Assumptions [14400]

[14401] Guidance stays reasonably stable Chapters carry review dates so drift is visible rather than silent.

[14403] Teams have protected time Without funded time, the guide is read but not applied.

[14405] Leaders accept proportionality Blanket caution defeats the tiering model as surely as no control at all.

[14407] Community keeps sharing Reuse depends on organisations publishing failures as well as successes.

[14409] Illustrative figures get replaced Measured departmental data must supersede the labelled placeholders.

## Indicators to track [14412]

[14416] Chapters opened per role pathway

[14420] Agents registered with a named owner and review date

[14424] Proportion of agents with an ATRS record

[14428] Assurance decisions made at the tier they belong to

[14432] Business cases including the full investment line

[14436] Patterns and evidence cards reused across organisations

[14437] Back to the contents · Suggest a correction (opens GitHub)

[14449] Delivery documentation · user research bundle

## Personas, stories, journeys and service blueprints [14450]

[14451] Drawn from the roles, frictions and lifecycle material in published guidance and community discussion. These are evidence-derived working personas, not research participants — they need validating with real users before they carry design decisions.

## Six personas [14453]

## Accountable leader [14456]

## Director or SRO, accounting-officer line [14457]

[14458] Decide where AI is worth the risk and the money, and be able to answer for it.

[14459] Needs

[14461] Evidence that a claim is measured, not asserted

[14462] A defensible risk appetite

[14463] One page that survives a select-committee question

[14464] Frustrations

[14466] Productivity figures with no method attached

[14467] Being asked to approve what nobody owns

[14468] Cost framed as licences only

## Reads: Assurance tiers, evidence chapter, investment line, control tower [14469]

## Service owner [14471]

## Owns an operational service with real users [14472]

[14473] Adopt agents without destabilising a service people depend on.

[14474] Needs

[14476] Clear promotion gates

[14477] Named ownership and support model

[14478] A rollback and exit route

[14479] Frustrations

[14481] Agents appearing in the service without registration

[14482] Unclear escalation when output is wrong

[14483] Support cost landing on the service unfunded

## Reads: Agent journey, criticality and gates, failure and recovery, dependency and exit [14484]

## AI engineer [14486]

## Builds and evaluates agents [14487]

[14488] Build well-grounded agents and prove they work.

[14489] Needs

[14491] Evaluation and red-team patterns

[14492] Grounding decision tree

[14493] Instruction blocks that transfer between platforms

[14494] Frustrations

[14496] Ungoverned copies of source data made for grounding

[14497] No baseline to evaluate drift against

[14498] Prototype standards applied to production, and the reverse

## Reads: Skill studio, architecture and quality, knowledge foundation, AI Engineering Lab [14499]

## Assurance and ethics specialist [14501]

## Reviews, challenges and signs off [14502]

[14503] Apply proportionate control and see the evidence behind it.

[14504] Needs

[14506] Criticality scoring that distinguishes usage from consequence

[14507] ATRS record completeness

[14508] A residual-risk statement per agent

[14509] Frustrations

[14511] Assurance as a gate at the end rather than a thread throughout

[14512] Self-scored maturity with no evidence

[14513] Incidents surfacing without a route to redress

## Reads: Risks and mitigations, internal ATRS registry, maturity evidence, autonomy boundaries [14514]

## Commercial and FinOps lead [14516]

## Buys, allocates and forecasts [14517]

[14518] Fund adoption honestly and keep exit possible.

[14519] Needs

[14521] Unit economics per use case

[14522] Allocation model across six cost layers

[14523] Supplier requirements for telemetry, portability and exit

[14524] Frustrations

[14526] Token cost mistaken for total cost

[14527] Lock-in discovered at renewal

[14528] Shared costs with no agreed allocation

## Reads: Cost value and investment, commercial and suppliers, FinOps, dependency and exit [14529]

## Frontline practitioner [14531]

## Uses agents in daily casework [14532]

[14533] Do the work faster without carrying unowned risk.

[14534] Needs

[14536] Plain guidance on what is allowed

[14537] A way to challenge an output

[14538] Training in the flow of work

[14539] Frustrations

[14541] Guidance written for architects

[14542] No clear escalation when the agent is wrong

[14543] Being blamed for a tool decision made elsewhere

## Reads: Support around every colleague, inclusive adoption, roles and pathways [14544]

## User stories with acceptance criteria [14545]

[14547] As a Accountable leader , I need to see the method behind any productivity claim, so that I do not repeat an unevidenced figure in public.

[14549] Accepted when: Every figure shows publisher, date and method, or is labelled illustrative

[14551] As a Accountable leader , I need to know which agents are high risk and who owns them, so that I can direct attention where consequence is highest.

[14553] Accepted when: Control tower lists risk level, owner and next review per agent

[14555] As a Service owner , I need to know the gate an agent must pass before it touches my service, so that I can plan assurance rather than discover it.

[14557] Accepted when: Criticality score returns a tier with named evidence and review frequency

[14559] As a Service owner , I need to have an exit path for a platform or model, so that a supplier change does not stop my service.

[14561] Accepted when: Seven-step exit path with the dependencies it addresses

[14563] As a AI engineer , I need to decide where grounding information should live, so that I do not create ungoverned copies.

[14565] Accepted when: Decision tree returns one of four options in priority order

[14567] As a AI engineer , I need to compose an instruction block once and reuse it, so that behaviour is consistent across platforms.

[14569] Accepted when: Seven-part block copies out as plain text

[14571] As a Assurance specialist , I need to score criticality across ten dimensions, so that control is proportionate to consequence.

[14573] Accepted when: Score maps to one of five gates with its controls

[14575] As a Assurance specialist , I need to record transparency information for every internal agent, so that oversight and audit have something to inspect.

[14577] Accepted when: Eight-section ATRS record with all fields listed

[14579] As a FinOps lead , I need to model cost per run and per month, so that a business case includes consumption, not guesses.

[14581] Accepted when: Cost lab returns per-run and monthly figures with a language multiplier

[14583] As a FinOps lead , I need to see value against cost per interaction, so that I can show whether the agent earns its keep.

[14585] Accepted when: Unit economics returns value, net and return

[14587] As a Frontline practitioner , I need to know what I may use and when to escalate, so that I can work confidently within the guardrails.

[14589] Accepted when: Support chapter states allowed use, escalation and where help comes from

[14591] As a Community manager , I need to turn a session into a reusable evidence pack, so that learning survives the meeting.

[14593] Accepted when: Evidence pack structure with owner, taxonomy and review date

## Journeys [14594]

## First-time reader to first decision [14595]

[14598] Arrives with a question Lands on the overview, sees proposal status “Is this authoritative?” Proposal flag and hierarchy answer it in one screen

[14602] Finds the applicable chapter Uses search or contents “Where does my case sit?” Chapter numbering and part accents orient quickly

[14606] Runs an assessment Tier finder or criticality radar “Am I over- or under-controlling?” Tier arrives with evidence and review expectations

[14610] Takes an artefact away Copies the register schema or instruction block “What do I do on Monday?” Copyable artefacts, not prose

[14614] Returns for oversight Re-opens the control tower and maturity evidence “Has anything drifted?” Read state and review cadence bring them back

## Agent from idea to retirement [14617]

[14620] Idea Someone builds a helpful agent “This saves me an hour a day” Register at creation, not at scale

[14624] Share Colleagues start relying on it “It works, so why formalise it?” Promotion gate between personal and team scope

[14628] Assure Criticality scored, tier applied “How much control is proportionate?” Gate names the evidence needed

[14632] Operate Monitoring, cost and quality watched “Who notices if it degrades?” Named owner and continuous duties

[14636] Review Re-authorise, improve, restrict or retire “Is it still earning its authority?” Review date forces the decision

[14640] Retire Access revoked, records archived “What happens to the evidence?” Archive and audit stage in the lifecycle

## Community session to reused pattern [14643]

[14646] Session happens Weekly call, recorded from 17 August 2026 “Will I find this again?” Automatic recording closes part of the capture gap

[14650] Capture Transcript, chat, files, commitments “Who owns the follow-up?” Session evidence pack with owner and actions

[14654] Classify Taxonomy: capability, use case, sensitivity, owner, review date “Which of these applies to me?” Shared taxonomy across communities

[14658] Connect Federated index links to governed sources “Is this the current version?” Index links rather than copies

[14662] Reuse Another organisation adopts the pattern “Has anyone tried this already?” Discovery by role, sector, maturity and supplier

[14666] Learn Outcome and corrections returned “Did it actually work?” Value reported as reuse, not attendance

## Service blueprint — an agent in an operational service [14669]

[14670] Five lanes across the same five moments: what the user does, what they see, what happens behind it, what supports it, and what is recorded.

## User actions [14672]

[14673] Requests help Reviews agent output Accepts or challenges Escalates an error Feeds back on value

## Frontstage [14680]

[14681] Agent responds with citation Confidence and limits shown Human review point Escalation route offered Feedback captured in service

## Backstage [14688]

[14689] Retrieval over authoritative sources Guardrails and permission checks Logging and audit trail Incident triage and rollback Evaluation against baseline

## Supporting processes [14696]

[14697] Register and ATRS record maintained Assurance gate evidence held Cost allocated to the use case Supplier and model change managed Review or retirement decision

## Evidence and records [14704]

[14705] Source provenance Approval and sign-off Monitoring and drift reports Incident records Benefit evidence

[14711] Back to the contents · Suggest a correction (opens GitHub)

[14723] Delivery documentation · external resources

## The AI Engineering Lab and other gov.uk resources [14724]

[14725] This guide interprets and sequences; these resources supply engineering practice, worked examples and published evaluation. Link to them rather than copying them — they move faster than any document.

## AI Engineering Lab [14730]

## GDS Office of the CTO engineering-excellence project with DSIT [14732]

[14733] Programme site, an open GitHub resource repository under OGL v3.0, a Knowledge Hub community, role-specific material and cross-government hackathons. Enquiries to the GDS engineering-excellence team.

## Use it for: Engineering patterns, evaluation practice, contribution route [14734]

## Open resource [14735]

## AI Knowledge Hub [14739]

## i.AI, GDS within DSIT [14741]

[14742] A living resource on building and adopting AI in the public sector, with tool pages carrying what was built, what it cost and what the evaluation found.

## Use it for: Worked examples with evidence, before you build your own [14743]

## Open resource [14744]

## i.AI product family [14748]

## Incubator for Artificial Intelligence [14750]

[14751] Caddy, Consult, Extract, Redbox, Minute, Parlex, Scout, Connect, Lex and rAPId — several open-sourced, with published evaluations.

## Use it for: Reusable patterns and honest post-mortems, including a sunsetted product [14752]

## Open resource [14753]

## AI Growth Lab [14757]

## DSIT [14759]

[14760] Proposed cross-economy regulatory sandbox with time-limited exemptions under supervision; call for evidence closed January 2026.

## Use it for: Where regulation, not capability, is the blocker [14761]

## Open resource [14762]

## Fundamental AI Research Lab [14766]

## DSIT with UKRI [14768]

[14769] Up to £40m for long-term research into limitations such as hallucination, unreliable memory and unpredictable reasoning.

## Use it for: Why some current risks are structural, not configuration errors [14770]

## AI Playbook for the UK Government [14774]

## GDS, February 2025 [14776]

[14777] Ten principles and the life cycle this guide sequences; supersedes the Generative AI Framework.

## Use it for: The guidance in force [14778]

## Open resource [14779]

## Which resource, which chapter [14780]

[14781] Need an engineering or evaluation pattern AI Engineering Lab repository and community 3.2 Architecture & quality

[14785] Need a worked example with published evidence AI Knowledge Hub tool pages 2.2 Use cases & evidence

[14789] Need to see how a product was evaluated i.AI evaluations and blogs 2.1 Evidence before assertion

[14793] Need to know if regulation is the blocker AI Growth Lab call for evidence Resource library (home page)

[14797] Need the authoritative principles AI Playbook for the UK Government 1.3 The playbook

[14801] Need transparency-record structure ATRS and the internal registry chapter 4.5 Internal ATRS registry

[14805] Back to the contents · Suggest a correction (opens GitHub)

