---
type: publisher-section
title: Live pilot
status: draft
sources:
- title: Live pilot
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-live-pilot
x-dom-section: part-live-pilot
---

# Live pilot

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-live-pilot)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[12623] Part 8 of 12 · 9 chapters

## Live pilot [12624]

[12633] Live pilot handbook · prototype pilot pack, 25 August 2026

## Testing this guide through a real deployment [12634]

[12635] We are not reviewing a document. We are using the playbook during a live AI deployment to determine whether it improves decisions, delivery, assurance and public-service outcomes, and whether there is sufficient evidence and appetite to establish a permanent, interactive toolkit.

[12638] Evidence status. The pilot model, thresholds and templates are proposed practice. They must be agreed for the selected live deployment. No pilot outcome is claimed in advance.

## Seven stages, seven decisions [12640]

## Mobilise [12644]

[12646] Is the pilot worth initiating?

[12647] Mandate, sponsor, scope and evaluation plan. Proceed or stop.

## Select [12653]

[12655] Is the deployment suitable and safe for a pilot?

[12656] Candidate assessment and baseline. Select, condition or reject.

## Prepare [12662]

[12664] Are people, controls, evidence and fallbacks ready?

[12665] Readiness and assurance plan. Authorise controlled deployment.

## Deploy [12671]

[12673] Can the playbook be used during real delivery?

[12674] Operational evidence and decision trail. Continue, restrict, pause or stop.

## Challenge [12680]

[12682] Did governance and assurance improve decisions?

[12683] Independent findings and participant evidence. Accept, remediate or retest.

## Evaluate [12689]

[12691] Was the playbook useful, proportionate and valuable?

[12692] Evaluation and options appraisal. Stop, retain, simplify or evolve.

## Decide [12698]

[12700] Is there appetite and evidence for a permanent capability?

[12701] Investment recommendation and roadmap. Toolkit decision.

## Who this is for, and their first action [12704]

## Sponsor or SRO [12707]

[12708] Decision points, risk boundaries, evidence and investment gate.

## First action: Confirm outcome, authority and resourcing. [12709]

## Candidate team [12711]

[12712] Eligibility, readiness criteria, expected contribution and safeguards.

## First action: Complete the candidate screen. [12713]

## Pilot delivery team [12715]

[12716] Step-by-step lifecycle, artefacts, ceremonies and feedback routes.

## First action: Attend induction and baseline assessment. [12717]

## Assurance reviewer [12719]

[12720] Review lenses, evidence standards and independence rules.

## First action: Agree assurance plan and conflicts. [12721]

## Interested party [12723]

[12724] Ways to observe, challenge and contribute without disrupting delivery.

## First action: Choose an engagement route. [12725]

## Toolkit product team [12727]

[12728] Evidence needed to decide whether to stop, retain a static guide or build a living toolkit.

## First action: Establish evaluation repository. [12729]

[12730] Back to the contents · Suggest a correction (opens GitHub)

[12742] Live pilot · hypothesis and test dimensions

## What the pilot is testing [12743]

[12744] Primary hypothesis: using the playbook during a live deployment will improve the clarity, consistency, traceability and proportionality of governance and assurance without imposing unjustified delivery burden.

## Usability [12748]

[12750] People can find and apply the right guidance without the author present.

[12752] Task observation, completion, help requests and interviews.

## Proportionality [12755]

[12757] Controls reflect risk, autonomy, data, decision influence and public effect.

[12759] Exceptions, duplicated work, effort diary and reviewer judgement.

## Decision quality [12762]

[12764] Material decisions have clear owners, evidence, uncertainty and conditions.

[12766] Decision records and assurance sampling.

## Delivery value [12769]

[12771] The playbook prevents rework or reveals issues early enough to act.

[12773] Before and after comparison, avoided rework and issue chronology.

[12774] Assurance quality Claims are tested against meaningful evidence. Findings, closure evidence and independent opinion.

[12778] Learning value Participants gain usable capability and confidence. Applied assessments, job-aid use and follow-up interviews.

## Future demand [12784]

[12786] Teams and leaders prefer a maintained toolkit over no framework or a static document.

[12788] Investment survey, sponsor decision and committed use cases.

## Non-objectives [12789]

[12793] Proving that every AI deployment should use identical controls.

[12797] Treating participant satisfaction as proof of safety or value.

[12801] Using a successful pilot to claim cross-government impact.

[12805] Replacing formal legal, security, privacy, commercial or service-assessment obligations.

[12806] Back to the contents · Suggest a correction (opens GitHub)

[12818] Live pilot · candidate selection

## Choosing a deployment worth learning from [12819]

[12820] Seven criteria, the evidence each needs, and the condition that turns a candidate into a rejection or an escalation.

## Real deployment [12823]

[12826] Named service, users, owner and intended live or limited-live use.

[12828] Reject or escalate when: There is only a hypothetical demo.

## Bounded purpose [12830]

[12831] Defined tasks, prohibited uses and measurable outcomes. Reject or escalate when: Purpose is open-ended or unowned.

## Safe test route [12835]

[12838] Controlled environment, data route, fallback and stop mechanism.

[12840] Reject or escalate when: Critical safeguards are unavailable.

## Representative learning [12842]

[12845] The candidate exercises meaningful parts of the playbook.

[12847] Reject or escalate when: The use case is too trivial to generate evidence.

## Team capacity [12849]

[12852] Product, operational, technical and governance participation.

[12854] Reject or escalate when: Delivery relies on one person or unavailable specialists.

## Evidence access [12856]

[12859] Permission to examine decisions, tests, incidents and effort.

[12861] Reject or escalate when: Evaluation cannot access material evidence.

## Change tolerance [12863]

[12866] Team accepts challenge and can alter or pause deployment.

[12868] Reject or escalate when: Go-live is predetermined regardless of evidence.

## Recommended cohort [12870]

[12871] Use three contrasting deployments where feasible: a bounded low-risk assistant, a reusable internal knowledge or workflow agent, and a higher-impact agent influencing operational judgement. This is a suggested design, not a mandated sample.

[12872] Back to the contents · Suggest a correction (opens GitHub)

[12884] Live pilot · participants and responsibilities

## Seventeen roles, one accountable line [12885]

[12886] The deployment SRO stays accountable for the live service throughout. The pilot adds evaluation and independent challenge; it does not take accountability away from delivery.

## Executive sponsor [12892]

[12894] Protects the purpose, secures capacity and receives the investment recommendation.

[12896] Pilot SRO Accountable for pilot outcomes, scope and residual risk.

[12900] Deployment SRO Remains accountable for the live AI-enabled service.

## Pilot manager [12906]

[12908] Runs plan, ceremonies, dependencies, evidence and communications.

## Product manager [12912]

[12914] Applies the playbook to needs, outcomes and backlog decisions.

## Service owner [12918]

[12920] Owns operational performance, support, fallback and continuity.

## User researcher [12924]

[12926] Tests usability and captures staff and affected-user evidence.

## Service designer [12930]

[12932] Maps whole service, human controls, channels and failure demand.

## Technical owner / AI engineer [12936]

[12938] Builds bounded capability and supplies evaluation and operational evidence.

## Data and information lead [12942]

[12944] Assures sources, provenance, metadata, retention and records.

## Security and privacy leads [12948]

[12950] Assess threats, access, personal data, incidents and mitigations.

## Responsible AI and accessibility leads [12954]

[12956] Challenge fairness, human control, inclusion and public impact.

## Learning and change lead [12960]

[12962] Delivers induction, job aids, competence assessment and adoption support.

## Independent assurance lead [12966]

[12968] Plans and conducts evidence-based challenge independent of delivery.

## Evaluation lead [12972]

[12974] Owns baseline, methods, synthesis, limitations and options appraisal.

## Community reviewers [12978]

[12980] Provide targeted architecture, service, audit or policy challenge.

## Toolkit product owner [12984]

[12986] Tests appetite and prepares the permanent-toolkit option if warranted.

[12987] Back to the contents · Suggest a correction (opens GitHub)

[12999] Live pilot · formal assurance model

## Five assurance stages, five kinds of opinion [13000]

[13001] Each stage states what it is for, what evidence it reviews, and the opinions it can legitimately reach.

## Readiness [13004]

[13005] Determine whether controlled deployment can begin.

[13008] Evidence: Scope, owners, risk, authority, data, tests, fallback, training.

## Opinion: Ready; ready with conditions; not ready. [13010]

## In-flight [13012]

[13013] Test whether controls operate and the playbook supports decisions.

[13016] Evidence: Logs, samples, incidents, exceptions, user evidence, decisions.

## Opinion: Effective; partially effective; ineffective. [13018]

## Change [13020]

[13021] Assess material changes to model, tools, data, purpose or service.

[13024] Evidence: Impact assessment, regression tests, permissions and updated record.

## Opinion: Authorise; condition; retest; reject. [13026]

## Close-out [13028]

[13029] Judge whether claims and conclusions are supported.

[13032] Evidence: Outcome evidence, costs, findings, limitations and participant testimony.

## Opinion: Reasonable; qualified; insufficient assurance. [13034]

## Investment [13036]

[13037] Assess whether permanence is justified.

[13040] Evidence: Need, repeat demand, value, maintainability, ownership and funding.

## Opinion: Stop; static guide; simplify; interactive toolkit. [13042]

## Independence rule [13044]

[13045] Delivery teams own controls and evidence. Independent assurance challenges claims and reports limitations. The SRO makes the accountable decision; assurance does not transfer accountability.

[13046] Back to the contents · Suggest a correction (opens GitHub)

[13058] Live pilot · journey and rhythm

## End-to-end pilot journey [13059]

[13060] Ten steps from mobilise to share, each with its activities and the artefact it must produce.

## Mobilise [13064]

[13065] Approve charter; appoint roles; agree scope, ethics, data and communications; define hypotheses and baselines.

## Pilot charter, RACI, evaluation protocol, communication calendar. [13066]

## Select [13068]

[13069] Screen candidates; interview owners; classify risk and learning value; confirm evidence access.

## Candidate scorecard, selection decision and conditions. [13070]

## Induct [13072]

[13073] Brief all roles; assess learning needs; issue playbook routes and job aids; rehearse escalation.

## Induction record and competence baseline. [13074]

## Baseline [13076]

[13077] Capture current governance journey, effort, uncertainty, rework, readiness and expected outcomes.

## Baseline map and measure definitions. [13078]

## Apply [13080]

[13081] Use playbook lifecycle, authority model, internal ATRS record, evidence pack and decision gates.

## Completed artefacts and traceable decisions. [13082]

## Deploy [13084]

[13085] Begin bounded live or limited-live operation; monitor; sample outputs; record exceptions and effort.

## Operational evidence, incidents, feedback and change log. [13086]

## Challenge [13088]

[13089] Run architecture, service, security, privacy, responsible-AI, accessibility and audit reviews.

## Formal findings and closure plan. [13090]

## Evaluate [13092]

[13093] Compare baseline; triangulate metrics, observation and interviews; document limitations.

## Evaluation report and playbook backlog. [13094]

## Decide [13096]

[13097] Options appraisal and sponsor decision: stop, static, simplify or toolkit.

## Decision record, investment recommendation and roadmap. [13098]

## Share [13100]

[13101] Return findings to participants and communities; publish only what is approved and evidenced.

## Lessons pack and controlled reusable assets. [13102]

## Ceremonies and evidence rhythm [13103]

## Candidate interview [13107]

[13109] Pilot, deployment and assurance leads.

[13110] Test eligibility, constraints and evidence access. Selection record.

## Kick-off and induction [13116]

[13118] All core roles.

[13121] Align purpose, boundaries, responsibilities and stop routes.

## Signed charter and readiness actions. [13123]

## Weekly evidence clinic [13127]

[13129] Pilot manager, product, operations, evaluation.

[13132] Review decisions, friction, incidents, metrics and learning.

## Evidence log and backlog. [13134]

## Fortnightly assurance checkpoint [13138]

[13140] SRO, service owner, assurance specialists.

[13141] Test controls and conditions; decide remedial action. Assurance note and decision.

## Participant pulse [13147]

[13149] Users and delivery team.

[13150] Capture usability and burden close to the work. Short structured feedback.

## Mid-point challenge [13156]

[13158] Independent reviewers and community representatives.

[13159] Identify blind spots before conclusions harden. Challenge findings.

## Close-out review [13165]

[13167] All accountable and assurance roles.

[13168] Agree evidence, limitations and recommendations. Final assurance opinion.

## Investment gate [13174]

[13176] Sponsor, SRO, toolkit owner, finance and governance.

[13177] Choose future option. Investment decision.

[13180] Back to the contents · Suggest a correction (opens GitHub)

[13192] Live pilot · communications plan

## Nine moments, one honest message [13193]

[13194] Each moment names its audience, message, channel and owner. The framework is being assessed — not the teams taking part.

## Pre-launch [13199]

## Sponsors and governance [13201]

[13202] Why this is a live deployment test; decision sought; safeguards.

[13203] Executive brief and sponsor conversation. Pilot sponsor.

## Recruitment [13209]

## Candidate teams [13211]

[13212] The framework is being assessed, not the team; eligibility and contribution.

[13213] Teams post, briefing session and candidate pack. Pilot manager.

## Selection [13219]

## Applicants [13221]

[13222] Transparent criteria, result, conditions and alternative engagement.

[13223] Decision note and direct conversation. Pilot SRO.

## Induction [13229]

## Selected participants [13231]

[13232] Process, roles, boundaries, evidence, learning and escalation.

[13233] Workshop, handbook and role cards. Learning lead.

## In-flight [13239]

## Participants and sponsors [13241]

[13242] Progress, decisions, risks, changes and support.

[13243] Weekly digest and monthly dashboard. Pilot manager.

## Challenge [13249]

## Assurance and community [13251]

[13252] Focused review question, evidence boundaries and response route.

[13253] Review pack and facilitated session. Assurance lead.

## Close-out [13259]

## All participants [13261]

[13262] What evidence shows, limitations and what will change.

[13263] Playback and findings report. Evaluation lead.

## Investment [13269]

## Senior decision-makers [13271]

[13272] Options, value, demand, costs, ownership and recommendation.

[13273] Decision paper and deck. Pilot SRO.

## Wider sharing [13279]

## Interested communities [13281]

[13282] Verified lessons, reusable patterns and next decision.

[13283] Community session and controlled publication. Communications owner.

## Core messages [13286]

[13290] This is a controlled test of the framework in real delivery.

[13294] Participation is not an audit of team performance.

[13298] Safety, service obligations and accountable decisions override pilot learning.

[13302] Evidence includes what fails, adds burden or duplicates existing controls.

[13306] No decision to establish a permanent toolkit has been made in advance.

[13307] Back to the contents · Suggest a correction (opens GitHub)

[13319] Live pilot · success framework and feedback

## Twelve measures, no invented thresholds [13320]

[13321] Each measure names its evidence, owner and cadence. Thresholds are agreed after the baseline is captured: a pre-set percentage without context would create false precision.

## Independent use [13324]

[13325] Participants navigate lifecycle and required artefacts without author dependency.

[13326] Observed task completion; help requests; navigation errors. Evaluation lead. Baseline and end.

## Proportionality [13331]

[13332] Teams and reviewers agree controls match material risk and consequence.

[13335] Effort diary; duplicated controls; exceptions; reviewer judgement.

## Assurance lead. [13337]

[13339] Weekly and close-out.

## Decision traceability [13341]

[13342] Material decisions identify owner, evidence, uncertainty, conditions and review.

[13343] Decision-record sample. Pilot manager. Fortnightly.

## Early issue detection [13348]

[13349] Material gaps are discovered while action remains possible.

[13350] Issue chronology and avoided or reduced rework evidence. Service owner. Monthly.

## Assurance quality [13355]

[13356] Findings distinguish intent, design, implementation, operation and outcome.

[13357] Independent assurance quality review. Assurance lead. Mid-point and close.

## Operational readiness [13362]

[13363] Support, monitoring, fallback and incident routes work in exercises and operation.

[13364] Readiness checks, exercises and operational records. Operations lead. Pre-live and live.

## Learning efficacy [13369]

[13370] Participants demonstrate relevant competence in realistic tasks.

[13371] Applied assessment and coaching records. Learning lead. Before and after.

## User and service value [13376]

[13377] Observed service outcomes improve or credible learning justifies continuation.

[13378] Service-specific baseline and evaluation. Product manager. Agreed cadence.

## Burden and cost [13383]

[13384] Implementation effort and recurring cost are visible and acceptable relative to value.

[13385] Time, support and consumption data. Evaluation and finance. Monthly.

## Demand and appetite [13390]

[13391] Leaders and teams prefer a maintained option and commit use cases, ownership or resources.

[13392] Structured option choice and commitments. Toolkit product owner. Close-out.

## Evidence integrity [13397]

[13398] Claims separate verified results, internal evidence, assumptions and expected outcomes.

[13399] Evidence audit. Independent assurance. Close-out.

## Inclusion [13404]

[13405] Research and controls address accessibility and affected-user differences.

[13406] Accessibility and inclusion evidence. Accessibility lead. Design and close-out.

## Feedback as formal evidence [13410]

[13411] Observed use Whether participants can apply the guide in context. At key lifecycle tasks. Observe the framework, not individual performance.

[13416] Decision sampling Whether governance claims are traceable. Throughout deployment. Risk-based sample agreed in advance.

[13421] Effort diary Where burden, duplication and rework occur. Weekly. Record estimates honestly and label them.

[13426] Structured interviews What helped, hindered or remained missing. Baseline, mid-point, close. Separate experience from factual claims.

[13431] Tabletop scenarios Whether controls work under failure and uncertainty. Pre-live and mid-point. Use synthetic scenarios where appropriate.

## Assassin review [13438]

[13440] Where the model could fail, be gamed or become bureaucratic.

[13442] Mid-point.

[13444] Facilitated, blameless challenge.

[13445] Independent evidence review Whether conclusions follow from evidence. Close-out. Declare conflicts and evidence limitations.

[13450] Option-preference survey Whether appetite exists for future forms. Close-out. Require rationale and commitment, not preference alone.

[13455] Community consultation Whether patterns transfer beyond the pilot. After initial evidence. Do not generalise from advocacy alone.

## Feedback taxonomy [13460]

[13463] KEEP

[13464] Works and should remain.

## Protect and evidence. [13465]

[13467] IMPROVE

[13468] Useful but unclear or incomplete.

## Refine and retest. [13469]

[13471] REMOVE

[13472] Adds unjustified burden or duplicates controls.

## Remove or explain exception. [13473]

[13475] MISSING

[13476] A necessary need or control is absent.

## Add, assign owner, validate. [13477]

[13479] CONFLICT

[13480] Contradicts policy, service or assurance practice.

## Escalate and resolve. [13481]

[13483] LOCALISE

[13484] Valid but needs context-specific adaptation.

## Create configurable pattern. [13485]

[13486] Back to the contents · Suggest a correction (opens GitHub)

[13498] Live pilot · decision and future state

## What happens after the pilot [13499]

[13500] Four options, the conditions that select each, and what each commits the organisation to. No option is pre-selected.

## Stop [13504]

[13505] Value is weak, burden is excessive, risks are unresolved or demand is absent.

[13506] Archive evidence and retain lessons; do not operationalise.

## Retain static playbook [13508]

[13509] The guide is useful as reference but repeat operational demand is limited.

[13510] Assign light-touch ownership and scheduled review.

## Simplify and retest [13512]

[13514] Value exists but usability or proportionality is inadequate.

[13515] Prioritise critical changes and conduct focused retest.

## Build living toolkit [13517]

[13518] Evidence shows repeat need, practical value, appetite and sustainable ownership.

[13519] Fund discovery and product development for an ongoing service.

## Investment evidence required for option D [13521]

[13522] Multiple committed user groups or deployments, not general interest alone.

[13523] A named product or service owner and multidisciplinary maintenance capacity.

[13524] A sustainable source of policy, standards and pattern updates.

[13525] Clear content governance, versioning, supersession and retirement rules.

[13526] Evidence that dynamic interaction adds value beyond a downloadable guide.

[13527] Security, privacy, accessibility, information-management and operating-cost assessment.

[13528] A measurable service outcome and roadmap, not only a feature list.

## Future-state toolkit concept [13529]

## Flagship implementation guide [13531]

[13534] Understand the end-to-end route.

[13536] Adaptive journey through lifecycle, roles, gates and evidence.

[13538] Evidence: Navigation, completion and repeat-use data.

## Governance navigator [13540]

[13543] Know which controls and forums apply.

[13545] Context-led route based on purpose, risk, autonomy and public effect.

[13547] Evidence: Routing errors, exceptions and decision consistency.

## Internal ATRS workspace [13549]

[13552] Create and maintain a transparency record.

[13554] Guided record, evidence links, review and publication decision.

[13556] Evidence: Field usability, maintenance burden and scope decisions.

## Assurance workspace [13558]

[13559] Build and review an evidence-based assurance case. Claims, evidence, findings, conditions and closure. Evidence: Evidence quality and review efficiency.

## Learning academy [13564]

[13565] Build competence by responsibility. Role pathways, scenarios, assessment and job aids. Evidence: Competence outcomes and support demand.

## Pattern library [13570]

[13571] Reuse proven controls and artefacts. Versioned patterns with evidence, owner and applicability. Evidence: Verified reuse and reduced duplication.

## Portfolio control tower [13576]

[13577] Oversee value, risk, cost and lifecycle. Inventory, status, evidence freshness and decision queues. Evidence: Decision usefulness and data quality.

## Community feedback loop [13582]

[13585] Keep the toolkit relevant.

[13587] Structured proposals, challenge, supersession and release notes.

[13589] Evidence: Contribution quality and maintenance capacity.

[13591] Product principle: the implementation guide remains the flagship resource. Interactive functions should reduce cognitive load and help people act safely; they must not hide accountability, evidence or applicable authoritative guidance.

## Participant checklist [13592]

## Before deployment [13595]

[13597] Read assigned playbook route.

[13598] Complete induction and competence tasks.

[13599] Confirm purpose, authority and prohibited use.

[13600] Validate data, tools and owners.

[13601] Practise fallback and escalation.

## During deployment [13603]

[13605] Use approved process and boundaries.

[13606] Record material decisions and uncertainty.

[13607] Report incidents and friction promptly.

[13608] Maintain evidence and effort diary.

[13609] Attend evidence clinics and assurance reviews.

## At close-out [13611]

[13613] Complete interview and option survey.

[13614] Review evidence and factual accuracy.

[13615] Declare unresolved concerns.

[13616] Identify KEEP, IMPROVE, REMOVE or MISSING.

[13617] Confirm future interest and commitment.

## Pilot safety stop rules [13619]

[13621] Immediate or plausible material harm to users or the public.

[13622] Loss of control over permissions, data or state-changing actions.

[13623] Critical security, privacy, legal or accessibility condition breached.

[13624] Required human oversight or operational fallback unavailable.

[13625] Evidence integrity compromised in a way that prevents accountable decision-making.

[13626] Deployment moves outside approved purpose or environment.

## Quick templates [13627]

## Candidate screen [13630]

[13632] Service and user need

[13633] Agent purpose and prohibited use

[13634] Users and affected parties

[13635] Data, tools and authority

[13636] Expected public-service influence

[13637] Named SRO, service and technical owners

[13638] Safe test environment and fallback

[13639] Evidence access and team capacity

[13640] Why this candidate creates transferable learning

## Weekly evidence log [13642]

[13644] Date

[13645] Decision or event

[13646] Evidence

[13647] Effect on delivery

[13648] Playbook feedback

[13649] Owner and action

## Close-out option record [13651]

[13653] Option

[13654] Evidence for

[13655] Evidence against

[13656] Conditions

[13657] Decision owner

## Source and status map [13658]

## AI Playbook for the UK Government [13661]

[13663] Human control, lifecycle management, governance, skills, quality assurance and risk.

## Authoritative external grounding. [13665]

## Service Standard and Service Manual [13668]

[13670] User needs, multidisciplinary delivery, security, measures, reliability and improvement.

## Applied proportionately as a proposed service lens. [13672]

## Technology Code of Practice [13675]

[13677] Criteria for government technology, including user needs, accessibility, security, privacy, data and Service Standard alignment.

## Authoritative external grounding. [13679]

[13680] ATRS guidance and scope policy Transparency purpose, scope tests and publication route. Official process; internal registry extension is proposed.

## Responsible AI Toolkit and AI Knowledge Hub [13686]

[13688] Responsible deployment, assurance, governance and practical resources.

## Authoritative and current resource grounding. [13690]

## AI Agents as Digital Workers Playbook [13693]

[13695] Policy, lifecycle, roles, internal registry, learning and roadmap prototype.

## Primary prototype under live test. [13697]

[13699] Final discipline. Pilot conclusions must distinguish observed and verified results, internally evidenced results, participant views, assumptions, expected outcomes and unresolved unknowns.

[13701] Back to the contents · Suggest a correction (opens GitHub)

