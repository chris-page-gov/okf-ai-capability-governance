---
type: publisher-section
title: Guidance, standards, toolkits and solutions — indexed and tiered
status: draft
sources:
- title: Guidance, standards, toolkits and solutions — indexed and tiered
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#resources
x-dom-section: resources
---

# Guidance, standards, toolkits and solutions — indexed and tiered

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#resources)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Guidance, standards, toolkits and solutions — indexed and tiered [19994]

[19995] 69 curated sources, each with its authority tier and a note on what it is actually useful for. Search, filter, then follow the link to the source of truth.

[20002] Search resources

[20006] Filter by type

[20008] All types

[20009] Law

[20010] Standard

[20011] Policy & framework

[20012] Guidance

[20013] Toolkit

[20014] Tool

[20015] Research

[20017] All topics

[20018] Accessibility

[20019] DEIA

[20020] UCD & research

[20021] Governance

[20022] Security

[20023] Privacy

[20024] Quantum

[20025] Metadata

[20026] Engineering

[20027] Ethics

[20028] Sustainability

[20029] Showing 69 of 69 resources.

[20032] Indexed guidance, standards and tools. Tier 0 is law; tier 3 is community or vendor material.

[20035] Resource

[20036] Publisher

[20037] Type

[20038] Tier

[20039] Use it for

[20042] AI Playbook for the UK Government (opens an external website) governance delivery uk

[20049] DSIT

[20050] Policy

[20051] Tier 1

[20053] Ten principles plus per-technology guidance for safe, effective public sector AI adoption. Replaced the Generative AI Framework for HMG, withdrawn on 10 February 2025.

[20055] Algorithmic Transparency Recording Standard (ATRS) (opens an external website) transparency governance uk

[20062] DSIT / CDDO

[20063] Standard

[20064] Tier 1

[20066] Mandatory-style template for publishing how an algorithmic tool is used in decision-making.

[20068] Data Ethics Framework (opens an external website) ethics data uk

[20075] DSIT

[20076] Policy

[20077] Tier 1

[20079] Structured ethical appraisal for public sector data and AI projects.

[20081] Service Standard (14 points) (opens an external website) ucd delivery uk

[20088] GDS

[20089] Standard

[20090] Tier 1

[20092] The assessment backbone for any public service — align AI features to each point.

[20094] Government Service Manual (opens an external website) ucd delivery uk

[20101] GDS

[20102] Guidance

[20103] Tier 1

[20105] End-to-end practice guidance for user research, design, technology and operations.

[20107] Government Design Principles (opens an external website) ucd uk

[20113] GDS

[20114] Guidance

[20115] Tier 1

[20117] Ten principles — start with user needs, do less, design with data, do the hard work to make it simple.

[20119] Technology Code of Practice (opens an external website) delivery governance uk

[20126] CDDO

[20127] Standard

[20128] Tier 1

[20130] Criteria for technology spend approval — interoperability, open standards, security, sustainability.

[20132] Digital, Data and Technology Capability Framework (opens an external website) skills people uk

[20139] GDS

[20140] Toolkit

[20141] Tier 1

[20143] Map AI-related skills to recognised roles and progression levels.

[20145] Open source guidance (coding in the open) (opens an external website) engineering openness uk

[20152] GDS

[20153] Guidance

[20154] Tier 1

[20156] When code should be open or closed, and how to publish safely.

[20158] GDS API technical and data standards (opens an external website) engineering interoperability uk

[20165] GDS

[20166] Standard

[20167] Tier 1

[20169] How to design, document and version APIs that agents and skills can call.

[20171] WCAG 2.2 (opens an external website) accessibility deia

[20177] W3C

[20178] Standard

[20179] Tier 1

[20181] The normative success criteria — target AA as a minimum, AAA where feasible.

[20183] ARIA Authoring Practices Guide (APG) (opens an external website) accessibility engineering

[20189] W3C WAI

[20190] Guidance

[20191] Tier 1

[20193] Accessible patterns for tabs, accordions, comboboxes, dialogs and more.

[20195] EN 301 549 accessibility requirements (opens an external website) accessibility procurement

[20201] ETSI/CEN/CENELEC

[20202] Standard

[20203] Tier 1

[20205] The procurement-facing accessibility standard referenced by UK/EU regulations.

[20207] Accessibility requirements for public sector websites and apps (opens an external website) accessibility legal uk

[20214] GOV.UK

[20215] Guidance

[20216] Tier 1

[20218] What the 2018 regulations require, including the accessibility statement duty.

[20220] Public Sector Bodies (Websites and Mobile Applications) Accessibility Regulations 2018 (opens an external website) accessibility legal uk

[20227] legislation.gov.uk

[20228] Law

[20229] Tier 0

[20231] The underlying legal duty.

[20233] Equality Act 2010 (opens an external website) deia legal uk

[20240] legislation.gov.uk

[20241] Law

[20242] Tier 0

[20244] Protected characteristics, reasonable adjustments and discrimination duties.

[20246] Public Sector Equality Duty guidance (opens an external website) deia legal uk

[20253] EHRC

[20254] Guidance

[20255] Tier 1

[20257] Due regard duty — evidence it in every AI-assisted decision or service change.

[20259] Make your service accessible: an introduction (opens an external website) accessibility ucd uk

[20266] GDS

[20267] Guidance

[20268] Tier 1

[20270] Practical starting point for teams new to accessibility duties.

[20272] Publish an accessibility statement (opens an external website) accessibility transparency uk

[20279] GOV.UK

[20280] Toolkit

[20281] Tier 1

[20283] Model wording and required disclosures for non-accessible content.

[20285] Research with people with disabilities and access needs (opens an external website) research deia uk

[20292] GDS

[20293] Guidance

[20294] Tier 1

[20296] How to recruit and run inclusive sessions, including with assistive technology users.

[20298] Helping people to use your service (assisted digital) (opens an external website) deia inclusion uk

[20305] GDS

[20306] Guidance

[20307] Tier 1

[20309] Assisted digital support and digital inclusion planning.

[20311] Inclusive Design Principles (opens an external website) ucd deia

[20317] Paciello/TPGi et al.

[20318] Guidance

[20319] Tier 2

[20321] Seven principles: provide comparable experience, be consistent, give control, offer choice.

[20323] Inclusive Design Toolkit (opens an external website) ucd deia

[20329] Microsoft

[20330] Toolkit

[20331] Tier 3

[20333] Persona spectrum and exclusion-mapping activities for workshops.

[20335] Home Office accessibility "dos and don’ts" posters (opens an external website) accessibility deia uk

[20342] UK Home Office

[20343] Toolkit

[20344] Tier 1

[20346] Print-ready posters for autistic users, screen readers, dyslexia, low vision, D/deaf users.

[20348] GOV.UK Design System (opens an external website) ucd engineering uk

[20355] GDS

[20356] Toolkit

[20357] Tier 1

[20359] Tested, accessible components and patterns — reuse before you invent.

[20361] GOV.UK Prototype Kit (opens an external website) ucd research uk

[20368] GDS

[20369] Toolkit

[20370] Tier 1

[20372] Rapid, realistic prototypes for usability testing without production risk.

[20374] GOV.UK style guide (content design) (opens an external website) content deia uk

[20381] GDS

[20382] Guidance

[20383] Tier 1

[20385] Plain English, reading age, formatting and inclusive terminology.

[20387] WebAIM contrast checker (opens an external website) accessibility tool

[20393] WebAIM

[20394] Tool

[20395] Tier 3

[20397] Verify 4.5:1 text and 3:1 non-text contrast before shipping.

[20399] Pa11y automated accessibility testing (opens an external website) accessibility ci tool

[20406] Pa11y

[20407] Tool

[20408] Tier 3

[20410] Add automated WCAG checks to your pipeline — never as a substitute for manual testing.

[20412] axe DevTools (opens an external website) accessibility tool

[20418] Deque

[20419] Tool

[20420] Tier 3

[20422] Browser-based rule engine used widely for triage.

[20424] Guidelines for secure AI system development (opens an external website) security ai uk

[20431] NCSC + international partners

[20432] Guidance

[20433] Tier 1

[20435] Secure design, development, deployment and operation across the AI lifecycle.

[20437] Secure by Design (UK government) (opens an external website) security delivery uk

[20444] Cabinet Office / GSG

[20445] Standard

[20446] Tier 1

[20448] Mandated activities and artefacts for digital service security in HMG.

[20450] Cyber Assessment Framework (CAF) (opens an external website) security assurance uk

[20457] NCSC

[20458] Standard

[20459] Tier 1

[20461] Outcome-based objectives A–D for essential services and government systems.

[20463] Post-quantum cryptography guidance and migration timeline (opens an external website) pqc security uk

[20470] NCSC

[20471] Guidance

[20472] Tier 1

[20474] Discovery by 2028, high-priority migration by 2031, complete by 2035.

[20476] Post-Quantum Cryptography standards (FIPS 203/204/205) (opens an external website) pqc security

[20482] NIST

[20483] Standard

[20484] Tier 1

[20486] ML-KEM, ML-DSA and SLH-DSA — the algorithms your crypto inventory should target.

[20488] OWASP Top 10 for LLM Applications (opens an external website) security ai engineering

[20495] OWASP

[20496] Standard

[20497] Tier 2

[20499] Prompt injection, insecure output handling, supply chain and agency risks.

[20501] MITRE ATLAS adversarial ML knowledge base (opens an external website) security ai threat

[20508] MITRE

[20509] Toolkit

[20510] Tier 2

[20512] Tactics and techniques for threat modelling AI systems.

[20514] Secure Software Development Framework (SP 800-218) (opens an external website) engineering security

[20520] NIST

[20521] Standard

[20522] Tier 2

[20524] Baseline secure SDLC practices to bind AI-generated code to.

[20526] SLSA supply chain integrity framework (opens an external website) engineering supplychain

[20532] OpenSSF

[20533] Standard

[20534] Tier 2

[20536] Provenance levels for build artefacts — extend to model and skill artefacts.

[20538] CycloneDX ML-BOM / AI-BOM (opens an external website) metadata supplychain

[20544] OWASP CycloneDX

[20545] Standard

[20546] Tier 2

[20548] Machine-readable bill of materials for models, datasets and AI components.

[20550] Guidance on AI and data protection (opens an external website) privacy legal uk

[20557] ICO

[20558] Guidance

[20559] Tier 1

[20561] Lawful basis, fairness, transparency and accountability for AI processing. Under review by the ICO after the Data (Use and Access) Act 2025.

[20563] AI and data protection risk toolkit (opens an external website) privacy assurance uk

[20570] ICO

[20571] Toolkit

[20572] Tier 1

[20574] Risk statements and controls mapped to the AI lifecycle. Under review by the ICO after the Data (Use and Access) Act 2025.

[20576] Data protection impact assessments (DPIA) (opens an external website) privacy legal uk

[20583] ICO

[20584] Toolkit

[20585] Tier 1

[20587] When a DPIA is mandatory and what a defensible one contains. Under review by the ICO after the Data (Use and Access) Act 2025.

[20589] Data Protection Act 2018 (opens an external website) privacy legal uk

[20596] legislation.gov.uk

[20597] Law

[20598] Tier 0

[20600] UK GDPR implementation. Its automated decision-making rules were rewritten by the Data (Use and Access) Act 2025.

[20602] Data (Use and Access) Act 2025 (opens an external website) privacy legal uk

[20609] legislation.gov.uk

[20610] Law

[20611] Tier 0

[20613] Replaced UK GDPR Article 22 with Articles 22A to 22D from 5 February 2026: a significant decision taken with no meaningful human involvement needs specific safeguards, including the right to contest it.

[20615] Automated decision-making, including profiling (opens an external website) privacy assurance uk

[20622] ICO

[20623] Guidance

[20624] Tier 1

[20626] What counts as meaningful human involvement, and the safeguards significant automated decisions need. Draft updated for the 2025 Act; the consultation closed on 29 May 2026.

[20628] ISO/IEC 42001 AI management systems (opens an external website) governance certification

[20634] ISO/IEC

[20635] Standard

[20636] Tier 1

[20638] Certifiable management system for responsible AI — useful for supplier assurance.

[20640] ISO/IEC 23894 AI risk management (opens an external website) risk governance

[20646] ISO/IEC

[20647] Standard

[20648] Tier 1

[20650] AI-specific application of ISO 31000 risk management.

[20652] ISO/IEC 27001 information security management (opens an external website) security certification

[20658] ISO/IEC

[20659] Standard

[20660] Tier 1

[20662] Control baseline most suppliers will already hold.

[20664] AI Risk Management Framework (AI RMF 1.0) + GenAI Profile (opens an external website) risk governance

[20670] NIST

[20671] Standard

[20672] Tier 1

[20674] Govern, Map, Measure, Manage — pairs cleanly with UK assurance practice.

[20676] EU AI Act (Regulation 2024/1689) (opens an external website) legal risk eu

[20683] EUR-Lex

[20684] Law

[20685] Tier 0

[20687] Risk tiers and obligations that may bind UK bodies operating in the EU market.

[20689] OECD AI Principles (opens an external website) ethics international

[20695] OECD

[20696] Policy

[20697] Tier 2

[20699] Internationally agreed values-based principles for trustworthy AI.

[20701] Recommendation on the Ethics of AI (opens an external website) ethics international

[20707] UNESCO

[20708] Policy

[20709] Tier 2

[20711] Global normative instrument covering human rights and inclusion.

[20713] Understanding AI ethics and safety (opens an external website) ethics uk research

[20720] The Alan Turing Institute

[20721] Guidance

[20722] Tier 2

[20724] The SUM values and FAST Track principles used across UK public sector.

[20726] AI Standards Hub (opens an external website) standards uk

[20732] BSI / NPL / Turing

[20733] Toolkit

[20734] Tier 2

[20736] Searchable database of AI standards in development and published.

[20738] Ada Lovelace Institute research (opens an external website) ethics public research

[20745] Ada Lovelace Institute

[20746] Research

[20747] Tier 3

[20749] Public attitudes, algorithmic impact assessment and deliberative methods.

[20751] Open Data Institute (opens an external website) data openness

[20757] ODI

[20758] Research

[20759] Tier 3

[20761] Data ethics canvas and data institution patterns.

[20763] Model Cards for Model Reporting (opens an external website) metadata transparency

[20769] Mitchell et al.

[20770] Research

[20771] Tier 2

[20773] The reference format for documenting intended use and performance by group.

[20775] Datasheets for Datasets (opens an external website) metadata data

[20781] Gebru et al.

[20782] Research

[20783] Tier 2

[20785] Provenance, composition and collection questions for training/eval data.

[20787] PROV-O provenance ontology (opens an external website) metadata provenance

[20793] W3C

[20794] Standard

[20795] Tier 1

[20797] Entity–activity–agent model for machine-readable evidence chains.

[20799] DCAT 3 data catalogue vocabulary (opens an external website) metadata interoperability

[20805] W3C

[20806] Standard

[20807] Tier 1

[20809] Describe datasets and services so registries can federate.

[20811] C2PA content provenance and authenticity (opens an external website) provenance genai

[20817] C2PA

[20818] Standard

[20819] Tier 2

[20821] Cryptographic manifests for AI-generated or edited media.

[20823] Model Context Protocol (opens an external website) agents engineering interoperability

[20830] MCP

[20831] Standard

[20832] Tier 3

[20834] Open protocol for connecting assistants to tools and data with explicit scopes.

[20836] Model cards on Hugging Face Hub (opens an external website) metadata engineering

[20842] Hugging Face

[20843] Toolkit

[20844] Tier 3

[20846] Practical templates and YAML front-matter conventions.

[20848] alphagov on GitHub (opens an external website) engineering openness uk

[20855] GDS

[20856] Toolkit

[20857] Tier 1

[20859] Reference implementations, frontend, and publishing platform source.

[20861] x-govuk community tools (opens an external website) engineering community uk

[20868] Cross-government community

[20869] Toolkit

[20870] Tier 2

[20872] Community-built plugins, design tooling and prototypes.

[20874] Open Government Licence v3.0 (opens an external website) openness legal uk

[20881] The National Archives

[20882] Law

[20883] Tier 0

[20885] Default licence for publishing public sector content and guidance.

[20887] Greening Government ICT and Digital Services Strategy (opens an external website) sustainability uk

[20893] Defra / GGC

[20894] Policy

[20895] Tier 1

[20897] Carbon, circular-economy and reporting expectations for digital estates. The 2020 to 2025 period has ended; the 2024 to 2025 annual report (July 2026) says a new government digital sustainability strategy is coming.

[20899] Web Sustainability Guidelines (WSG) (opens an external website) sustainability engineering

[20905] W3C Community Group

[20906] Guidance

[20907] Tier 3

[20909] Practical efficiency criteria for pages, media, hosting and AI workloads.

[20910] Content reviewed on 2026-11-13: every link checked, automatically or by hand in a browser where a site refuses automated checks, and each page read for withdrawal, replacement or review notices. Next review due 2027-02-13. Guidance changes without notice: always confirm you are reading the current version at the source.

