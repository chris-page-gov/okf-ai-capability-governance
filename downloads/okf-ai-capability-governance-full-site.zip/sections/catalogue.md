---
type: publisher-section
title: Treat skills, agents and code as assets in their own right
status: draft
sources:
- title: Treat skills, agents and code as assets in their own right
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#catalogue
x-dom-section: catalogue
---

# Treat skills, agents and code as assets in their own right

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#catalogue)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Treat skills, agents and code as assets in their own right [19673]

[19674] Every reusable AI capability should be discoverable, accountable, interoperable and governed like any other public asset — with an owner, a version, a risk rating and a retirement plan.

## Catalogue fields [19677]

[19680] Minimum viable metadata for any AI asset

[19683] Field

[19684] Why it matters

[19687] asset_id

[19689] Stable identifier so evidence, incidents and dependencies can point at it.

[19691] owner

[19693] A named person, not a team inbox. Accountability needs a face.

[19695] status

[19697] draft / approved / restricted / deprecated / withdrawn.

[19699] version

[19701] Semantic versioning; breaking changes force re-review.

[19703] authority_tier

[19705] 0–3 tier of the sources the asset relies on.

[19707] risk_level / human_review

[19710] H0–H5 floor that consumers must apply.

[19712] source_provenance

[19714] Which guidance, data and code it derives from, with dates.

[19716] permissions

[19718] Least-privilege scopes, tools and credentials the asset may use.

[19720] prohibited_actions

[19722] Explicit red lines an agent must never cross.

[19724] deia_screen

[19726] Date and outcome of equality and accessibility screening.

[19728] evaluation

[19730] Test suite, pass thresholds and last run.

[19732] compatibility

[19734] Models, runtimes and versions it is validated against.

[19736] lifecycle

[19738] Review cadence, next review, deprecation and retirement date.

[19740] contact / redress

[19743] How to report a problem or challenge an outcome.

## Example skill asset metadata [19745]

[19747] Copy

[19748] asset_type: ai_skill asset_id: review-accessibility-govuk title: GOV.UK accessibility review assistant status: approved version: 2.1.0 owner: AI assurance lead (role, not a named person) authority_tier: 1 human_review: H3 specialist_review: [accessibility, content_design] self_approval: false source_provenance:   - id: wcag22     url: https://www.w3.org/TR/WCAG22/     checked: 2026-07-14     next_check: 2026-10-14   - id: govuk-design-system     url: https://design-system.service.gov.uk/     checked: 2026-07-14 permissions:   tools: [read_page, run_axe]   data_classification_max: OFFICIAL prohibited_actions:   - claiming_conformance_without_test_evidence   - processing_personal_data   - autonomous_publication deia_screen:   completed: 2026-06-02   outcome: mitigations_applied evaluation:   suite: a11y-regression-v4   threshold: 0.95   last_run: 2026-08-01 compatibility:   models: [">=v3.1"]   runtimes: [node20, python3.12] evidence_rules:   require_citations: true   require_reviewer_signoff: true   retain_for: P7Y lifecycle:   review_cadence: P3M   next_review: 2026-11-01   deprecation: null contact: https://github.com/cyberdudeuk/ai-capability-governance/issues/new

[19750] Interoperability note: map these fields to DCAT 3 (opens an external website) for cataloguing, PROV-O (opens an external website) for evidence chains and CycloneDX ML-BOM (opens an external website) for supply chain, so registries in different organisations can federate rather than fork.

