---
type: publisher-section
title: How to check, challenge and contribute
status: draft
sources:
- title: How to check, challenge and contribute
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#transparency
x-dom-section: transparency
---

# How to check, challenge and contribute

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#transparency)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## How to check, challenge and contribute [22001]

[22002] A guidance utility that cannot be questioned is not trustworthy. Here is how this one is governed, and how you hold it to account.

## Provenance of this content [22005]

[22006] Every substantive claim links to a tiered source. Where this portal expresses an opinion or a house rule rather than a legal requirement, it says so.

## Ownership and review [22008]

[22009] Owner: AI Capability Governance working group Version: 3.4.0 Last reviewed: 2026-11-22 Next review due: 2027-02-13

## Licence and reuse [22018]

[22019] CC BY 4.0 (content) / MIT (code); Crown copyright material quoted here stays under the Open Government Licence v3.0. Fork it, adapt it for your organisation, and tell us what you changed so others benefit.

## Data and privacy [22021]

[22022] This site is static and client-side. It sets no tracking cookies, runs no analytics that identify you, and sends nothing you type in the tools to any server. Preferences are stored locally in your browser and you can clear them at any time.

## Known limitations [22024]

[22025] This is a concept portal, not a statutory instrument. It does not replace your organisation's policies, your DPO, your security team or your legal advice. Some linked standards sit behind paywalls.

## Report a problem [22027]

[22028] Tell us about a broken link, an out-of-date claim, an accessibility barrier or a gap. Accessibility issues get a response within five working days.

## Changelog [22029]

[22032] Recent changes to this portal

[22035] Version

[22036] Date

[22037] Change

[22040] 3.4.0

[22041] 2026-11-22

[22042] Merged the public parts of the Responsible AI and Data Use (RAIDU) work into the playbook: nine new chapters on human oversight principles, oversight controls, measuring oversight, human-side risks and priorities, verifying AI-assisted work, an oversight runbook with governance templates, neuroinclusive AI at work, a standards crosswalk and a 164-entry obligations register, plus 112 glossary terms. Internal working material stays out; see the classification record. Also fixed: tables no longer shrink to one word a line on phones, and the contents drawer flags only what is new.

[22044] 3.3.0

[22045] 2026-11-18

[22046] One portal. The playbook moved into this page: one masthead with grouped menus, one contents drawer for the whole portal with read marks, one glossary (39 playbook terms merged in, now 62) and one footer. Redesigned after the original AI Capability Governance portal: Figtree typeface (self-hosted), navy front page with the orbit, the guidance-in-force ticker, tinted part cards and the chapter view with part chips and progress bars. playbook.html now redirects here. New check S25.

[22048] 3.2.0

[22049] 2026-11-18

[22050] Added the agent governance playbook: 77 chapters in 12 parts ported from an internal AI agent governance toolkit, with a working “Can I use AI for this?” route tool, a knowledge map and a SKOS taxonomy. Ten chapters are withheld, each with its reason. New checks S21 to S24. Fixed the masthead line that repeated the old name.

[22052] 3.1.0

[22053] 2026-11-13

[22054] Content review: replaced the withdrawn Generative AI Framework for HMG with the AI Playbook, added the Data (Use and Access) Act 2025 and the ICO's automated decision-making guidance, flagged ICO guidance now under review, and fixed four moved links. Added a field to the evidence pack for the data definitions an agent's answer relied on, and signals S22 to S28.

[22056] 3.0.1

[22057] 2026-11-08

[22058] Replaced one broken and four moved resource links after an automated check of all 68; 11 sites refuse automated checks and are still to be checked by hand. The Monday health run now checks every link.

[22060] 3.0.0

[22061] 2026-11-08

[22062] Renamed to AI Capability Governance and Implementation and moved to its own address. Added the Signals section (a weekly horizon scan of AI and data governance with attribution, evidence labels and an open JSON register). Added Beginner, Intermediate and Advanced levels to every persona, journey and common task, and a new data and AI governance lead persona. Contact is now by the GitHub contact form only: the email-client route and reply-address field are removed, and the two email addresses in the worked metadata example are replaced with a role and the form. Added the issue forms the contact links already pointed to, and automated checks, including browser checks, that run before anything is published. Fixed the page scrolling sideways on small phones.

[22064] 2.0.0

[22065] 2026-08-08

[22066] Added task-first entry points, six interactive tools, a tiered resource library, H0–H5 review table, RACI, transparency and redress commitments, MoSCoW roadmap, glossary and FAQ. Added dark, high-contrast and large-text modes, site search, on-page navigation and a print stylesheet.

[22068] 1.0.0

[22069] Initial

[22070] Concept portal: mission, knowledge corpus, toolkit, assurance workflow, catalogue, UCD and code of practice.

