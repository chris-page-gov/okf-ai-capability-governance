---
type: publisher-section
title: Start here
status: draft
sources:
- title: Start here
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-start-here
x-dom-section: part-start-here
---

# Start here

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-start-here)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[1539] Part 1 of 12 · 5 chapters

## Start here [1540]

## AI Capability Governance and Implementation [1549]

[1550] The guidance for deploying AI agents in the public sector, sequenced into one route — and the operating capability that turns experimentation into governed services. Crown-copyright sources are the government's own; every illustrative figure is labelled.

## Start here [1556]

[1557] Eight stages from mandate to governed operation. The last stage feeds the third: every review either re-authorises the agent, changes it, or ends it.

## Stage 8 returns to stage 3 — the loop does not close [1561]

[1564] Usage and cost Who uses it, how often, what it spends

[1567] Accuracy and drift Evaluation results against the baseline

[1570] Risk and incidents New risks, near misses, escalations

[1573] Value realised Benefits claimed against benefits evidenced

[1576] Review or retire Re-authorise, improve, restrict or decommission

## Monitoring and human oversight are continuous duties held by the named owner, not a phase that ends at go-live. [1578]

## Where this guide sits [1579]

[1580] The hierarchy of AI-related guidance a public-sector team works inside. This guide is a proposal: it interprets and sequences the guidance above it, and it does not replace or override any of it.

## International frameworks [1582]

[1583] OECD AI Principles, EU AI Act risk tiers, ISO/IEC 42001 management standards.

## UK statute and cross-government policy [1585]

[1586] Data Protection Act 2018 and UK GDPR, Equality Act 2010, Procurement Act 2023, the AI Opportunities Action Plan.

## Central guidance in force [1588]

[1589] AI Playbook for the UK Government, Service Standard, Technology Code of Practice, ATRS, Data Ethics Framework, NCSC secure-AI guidelines.

## Departmental policy and standards [1591]

[1592] Organisational AI policy, data classification, security standards, delegated authority and spend controls.

## This implementation guide [1595]

[1596] AI Capability Governance and Implementation — 69 chapters, assessment tools and register schemas that turn the guidance above into delivery.

[1598] Proposal

## Team-level artefacts [1600]

[1601] Agent register entries, ATRS records, assurance evidence, instruction blocks and cost models.

## Multidisciplinary from the outset [1607]

[1608] Every source in this app lands on the same point. The AI Playbook makes skills and expertise a principle in its own right. The Service Manual builds the multidisciplinary team into the Service Standard. NCSC wrote its secure-AI guidelines for data scientists, developers, managers, decision-makers and risk owners together. The roster is in Teams ; the readiness barometer is in the Observatory .

[1611] Back to the contents · Suggest a correction (opens GitHub)

[1623] Responsible AI · start here

## What do you want to do? [1624]

[1625] Start from your task. This part of the playbook routes you to the proportionate tool, template, assessment or support. Governance follows what the AI can see, create and do, not which company made it.

[1629] Quick route selector · five questions

## Can I use AI for this? [1630]

## 1. Would the output decide, or directly change, someone’s rights, entitlements, safety or access to a service? [1632]

## 2. Will you use personal data or information marked OFFICIAL-SENSITIVE or above? [1634]

## 3. Can the AI take actions, run on a schedule or work through several steps without you? [1636]

## 4. Is there an approved tool in your organisation's catalogue that already does this? [1638]

## 5. Could a conventional rule, form or automation do the job reliably? [1640]

[1642] Your route

## Answer the five questions [1643]

[1644] The route appears when every question has an answer. “Not sure” is a valid answer.

[1645] A first sort, not an approval. Any route other than an approved tool leads to a registered use case.

## Six things to know first [1646]

## AI concepts and limitations [1649]

[1650] Generative AI predicts plausible output. It can be fluent and wrong at once, so outputs need checking in proportion to what depends on them.

## Models and providers [1652]

[1653] A product can use several models from several providers, sometimes chosen automatically. The model can change without the product name changing.

## Enterprise grounding [1655]

[1656] Grounding feeds organisational content to the model. Whatever the index can reach, the AI can surface, including titles, filenames and metadata.

## Agents, tools and actions [1658]

[1659] An agent plans steps and uses tools to act: send, update, create or call other agents. Acting changes the risk boundary.

## Human oversight [1661]

[1662] Oversight works only if the reviewer has the competence, the evidence and the authority to challenge, override or stop.

## Deployment route [1664]

[1665] The same model reached directly, through a cloud platform or inside another supplier’s product is a different governance object each time.

## For everyone in the organisation [1666]

[1671] All colleagues Find guidance, approved tools and practical help

[1676] Leaders and managers Make informed decisions, manage risk and value

[1681] Risk, security and compliance Assure, monitor and advise

[1686] IT and digital Enable, integrate and manage

[1691] Data and information Ensure data is ready and well managed

[1696] Commercial and procurement Manage suppliers, licences and costs

[1701] Accessibility and inclusion Support all users and workplace adjustments

[1706] Policy, strategy and transformation Drive adoption, value and continuous improvement

## Enabled by common services [1708]

[1710] Real-world outcomes · turning responsible AI into a stronger public sector

## Safer services for citizens [1715]

## Greater value for taxpayers [1719]

## More efficient working [1723]

## More inclusive for all [1727]

## A more innovative public sector [1731]

## Ideas → responsible implementation → trusted operation → lasting public value [1732]

## Govern the capability and behaviour first [1734]

[1735] Microsoft Copilot, Anthropic Claude, GitHub Copilot, Gemini and future tools sit as product overlays beneath one common control model. Role routes for every audience are in How to use this guide.

## Get help [1738]

## Using an approved tool [1739]

[1740] Your IT service desk, then the product’s support route.

## Assessing a use case [1741]

[1742] The AI assurance team owns screening and the decision register.

## An incident or concern [1743]

[1744] Report through the incident route on the Operate page. Treat data exposure as a security incident.

## Accessibility or adjustments [1745]

[1746] Your line manager and workplace adjustments service.

[1747] Named contacts are set by each organisation when the guidance is deployed.

## Standards and policy [1749]

## AI policy [1750]

[1751] Your organisation’s AI policy and acceptable use.

## Government guidance [1752]

[1753] The AI Playbook for the UK Government.

## AI Playbook on GOV.UK ↗ [1754]

## Data protection [1755]

[1756] UK GDPR, DPIAs and international transfers.

## ICO guidance on AI ↗ [1757]

## Security [1758]

[1759] Threat modelling, secure configuration and incident response.

## Records [1760]

[1761] Retention and disposal of prompts, outputs, transcripts and logs.

## Accessibility [1762]

[1763] WCAG 2.2 AA for AI interfaces and outputs.

## WCAG 2.2 ↗ [1764]

## Procurement [1765]

[1766] Supplier assurance, subprocessors, exit and service commitments.

## Transparency [1767]

[1768] Algorithmic Transparency Recording Standard for public-facing tools.

## ATRS hub on GOV.UK ↗ [1769]

## Templates [1770]

[1771] Twelve core artefacts and seven implementation artefacts.

## Product guidance [1772]

[1773] Overlays for each supplier and deployment route.

[1774] Back to the contents · Suggest a correction (opens GitHub)

[1786] Start here · orientation

## How to use this guide [1787]

[1788] 87 chapters in 12 parts. Nobody needs all of it. Pick a reading mode, then a route.

## Front to back [1794]

[1795] 12 parts in delivery order: decide, build, assure, operate, fund, the people and pilot material, then the deployment part and the reference. Roughly a day's read.

## By role route [1799]

[1800] 10 routes below, each an ordered set of chapters for one job. Twenty to forty minutes.

## By task [1804]

[1805] Use the launchpad or search: rate readiness, tier an agent, price a job, build an instruction block, check exit readiness.

## Routes by role [1806]

[1807] Each route is an ordered set of chapters. Click any step to jump there.

## Data and information [1809]

[1810] Get data ready, keep metadata and indexing honest, govern connectors and treat AI outputs as records.

## All colleagues [1812]

[1813] Find an approved tool, get a route for your task, and know where to get help.

## Accountable leader or SRO [1815]

[1816] Decide where AI is worth the risk and the spend, and be able to answer for it.

## Service owner [1818]

[1819] Adopt agents without destabilising a service people depend on.

## Product or delivery manager [1821]

[1822] Frame the problem, prove the value, keep the team moving.

## AI engineer or technical owner [1824]

[1825] Build well-grounded agents and prove they work.

## Assurance, ethics or audit [1827]

[1828] Apply proportionate control and see the evidence behind it.

## Commercial, finance or FinOps [1830]

[1831] Fund adoption honestly and keep exit possible.

## People, learning and adoption [1833]

[1834] Build capability that outlasts the pilot.

## Pilot participant [1836]

[1837] Use the guide during a real deployment and record what happens.

## What each part is for [1838]

## 1 · Start here [1841]

[1843] What the guidance says, what this guide adds, and the ten capability domains it all rests on.

## 2 · Decide and prioritise [1846]

[1848] Whether to do it at all: evidence quality, use-case selection, criticality and the assurance tier that follows.

## 3 · Design and build [1851]

[1853] Capability class — generative, agentic or declarative — then instructions, architecture, grounding and the autonomy boundary.

## 4 · Assure and govern [1856]

[1858] The trust cycle, the operating model, risks and mitigations, registers, transparency records and recovery.

## 5 · Operate and oversee [1861]

[1863] Life after approval: the portfolio view, the agent lifecycle, public-service impact and readiness tracking.

## 6 · Fund and buy [1866]

[1868] The full investment line, unit economics, supplier requirements and exit.

## 7 · People and adoption [1871]

[1873] Teams, roles, pathways, inclusion and the organisational adoption programme.

## 8 · Live pilot [1876]

[1878] How this guide is being tested in a real deployment, and what would justify a permanent toolkit.

## 9 · Product documentation [1881]

[1883] Requirements, architecture, design, theory of change and the research base for the guide itself.

## 10 · Knowledge and navigation [1886]

[1888] Glossary, thesaurus, generated knowledge graph, taxonomies, ontology, site map, guided tours and platform links.

## 11 · Deploy for real [1891]

[1893] The part that turns the guide into a deployment: fifty-four real services placed on volume and criticality, a generator that derives the whole governance set for any case, four agents carried end to end — one in each quadrant — and an explicit list of what this guide still does not cover.

## 12 · Reference [1896]

[1898] Devolved and international comparators, and every source behind the content.

## How to read the labels [1901]

[1902] Verified Present in a surfaced source.

[1905] Interpretation A conclusion drawn across sources.

[1908] Proposal Recommended future state, not adopted policy.

[1911] Illustrative Looks like data, carries no measured source.

## What this guide is not [1915]

[1919] It does not override departmental policy, professional advice or formal approvals.

[1923] It is not the register of record for any live deployment.

[1927] It holds no personal, case or OFFICIAL-SENSITIVE data; assessments stay on your device.

[1931] It cannot issue an approval — the accountable owner does that.

[1932] Back to the contents · Suggest a correction (opens GitHub)

[1944] The playbook

## Ten principles, one life cycle [1945]

[1946] The AI Playbook for the UK Government (opens an external website) (GDS, 10 February 2025) supersedes the Generative AI Framework and covers all AI: machine learning, NLP, computer vision, generative and agentic systems. The ten principles are paraphrased below; open each for its first moves.

## The deployment life cycle [1950]

[1951] Playbook principle 5: manage the whole life cycle, including the unglamorous parts. Each stage has a gate; nothing moves right without passing it.

[1954] Stage 1

## Discover [1955]

[1957] Frame the problem and the user need: is AI the right tool at all?

[1958] Triage risk: personal data, decisions about people, public-facing?

[1959] Assemble the multidisciplinary team; screen for DPIA and equality impacts

[1961] Gate · A named SRO and a written problem statement

[1964] Stage 2

## Design [1965]

[1967] Decide buy vs build; source and assess the data

[1968] Threat-model with security; place the human-oversight points

[1969] Legal, ethics and commercial shape the approach, not the finished thing

[1971] Gate · DPIA drafted; risks owned; oversight designed in

[1974] Stage 3

## Build & evaluate [1975]

[1977] Develop securely; verify the model and data supply chain

[1978] Evaluate accuracy, bias and robustness against agreed baselines

[1979] Red-team it: prompt injection, misuse, edge cases

[1981] Gate · Evaluation results reviewed by the whole team

[1984] Stage 4

## Deploy [1985]

[1987] Pass assurance gates; publish the ATRS record

[1988] Switch on human review and incident response

[1989] Tell users they are interacting with AI

[1991] Gate · Assurance sign-off; transparency record live

[1994] Stage 5

## Operate & retire [1995]

[1997] Monitor drift, bias and hallucination in production

[1998] Re-evaluate on every model or data update

[1999] Plan decommissioning and knowledge handover

[2001] Gate · Monitoring dashboards live; exit plan on file

[2003] Back to the contents · Suggest a correction (opens GitHub)

[2015] The domains

## Five lenses on every deployment [2016]

[2017] Cyber, data, digital, technology, and the legal-ethical frame around them. Each domain has its own authoritative guidance; a deployment is ready only when all five say so. That is why the team is multidisciplinary.

[2021] Cyber

## Cyber security [2022]

## NCSC secure AI guidelines [2023]

## NCSC machine learning principles [2026]

## Secure by Design (UK Government) [2029]

[2033] NCSC Guidelines for secure AI system development cover secure design, development, deployment and operation. Agreed with CISA and 21 international agencies; aimed at any system that uses AI, built or bought.

[2034] Secure by Design and the Government Cyber Security Standard apply to AI services like any other, plus AI-specific threat modelling: prompt injection, data poisoning, model extraction, over-permissioned agents.

[2035] NCSC's principles for the security of machine learning translate the threats into controls. Walk before you run with agentic AI.

[2038] Data

## Data & information [2039]

## Data Ethics Framework [2040]

## ICO: AI and data protection [2043]

## ATRS hub [2046]

[2050] The Data Ethics Framework guides appropriate, responsible data use across the public sector: transparency, accountability, fairness.

[2051] UK GDPR and the DPA 2018 require a DPIA before high-risk processing. The ICO's AI guidance, with a statutory AI code of practice in development, is the regulator's view of what good looks like. Cross-border processing (for example a US-processed model behind a UK product) needs a Transfer Risk Assessment as well as SCCs.

[2052] The Algorithmic Transparency Recording Standard is mandatory for central departments and arms-length bodies: a published record for every in-scope algorithmic tool.

[2053] Model quality is data quality: govern provenance, representativeness and retention for training and grounding data alike — retrieval systems inherit the permissions, quality and currency of the estate.

[2056] Digital

## Digital & service [2057]

## Service Standard [2058]

## AI Playbook for the UK Government [2061]

## AI Knowledge Hub [2064]

[2068] The Service Standard and Service Manual set the operating model: start with user needs, work in multidisciplinary teams, iterate in the open. AI services are still services.

[2069] The AI Playbook and the AI Knowledge Hub supply the patterns, case studies and communities; the PM's AI Exemplars programme is the test-and-learn engine for scaling what works.

[2070] Accessibility is law, not polish: WCAG 2.2 AA under the Public Sector Bodies Accessibility Regulations 2018. AI interfaces (chat, voice, summaries) need their own accessibility evidence.

[2073] Technology

## Technology & architecture [2074]

## Technology Code of Practice [2075]

## AI Opportunities Action Plan [2078]

## Action Plan delivery progress [2081]

[2085] The Technology Code of Practice governs the technology choices: cloud first, interoperability, open standards, sustainability, exit.

[2086] Compute and infrastructure are national policy: AI Growth Zones and a compute roadmap from 21 ExaFLOPs (2025) towards 420 by 2030 under the AI Opportunities Action Plan.

[2087] Buy well: use Crown Commercial Service AI routes, insist on evaluation access and model-change notice in contracts, and design the exit before signing the entry.

[2090] Legal & ethics

## Legal, ethics & society [2091]

## Explaining decisions made with AI [2092]

## Data Ethics Framework [2095]

## Equality Act 2010 guidance [2098]

[2102] The Equality Act 2010 and the Public Sector Equality Duty apply to automated and AI-assisted decisions. Public-law duties (fairness, rationality, giving reasons) still bind when a model is in the loop.

[2103] Explainability has a manual: 'Explaining decisions made with AI', by the ICO and The Alan Turing Institute — and explanations shown to people should reference functional needs, never a diagnosis or label.

[2104] Public trust is earned in the open: engage affected people early, say clearly where AI is used, and give a route to challenge and redress.

[2105] Back to the contents · Suggest a correction (opens GitHub)

