---
type: publisher-section
title: Reference
status: draft
sources:
- title: Reference
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-reference
x-dom-section: part-reference
---

# Reference

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-reference)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[15700] Part 12 of 12 · 5 chapters

## Reference [15701]

[15710] Pan-UK

## All four nations have strategy. One has published evaluation. [15711]

[15712] Counting strategies overstates maturity: a benchmark that measures published strategy ranks all four nations comparable. Only one has a published body of controlled evaluation of deployment. What each nation can borrow from the others is the point of comparing.

## UK Government [15716]

[15717] England and reserved functions

[15718] Strategy

## AI Playbook (Feb 2025) · AI Opportunities Action Plan (Jan 2025) · departmental AI plans mandated by Cabinet Secretary objectives 2026-27 [15719]

[15720] Who leads

[15721] DSIT · Government Digital Service (incl. i.AI and the AI Engineering Lab) · AI Security Institute

[15722] Signals

[15723] Four published Copilot evaluations plus NAO and PAC scrutiny — the UK's distinctive asset is evaluation, not strategy

[15724] ATRS transparency records mandatory for departments and ALBs

[15725] Cabinet Secretary's AI Innovation Award (quarterly, from Jun 2026); AI & Data Challenge at 252 ideas

## AI Playbook on GOV.UK [15726]

## Scotland [15730]

[15731] Devolved strategy, refreshed 2026

[15732] Strategy

## Scotland's AI Strategy 2026–2031 (March 2026) — five-year plan, OECD-aligned, with the AI Scotland programme [15733]

[15734] Who leads

[15735] Scottish Government · Scottish AI Alliance · The Data Lab

[15736] Signals

[15738] Scottish AI Register gives public-sector use cases a public face

[15739] Roughly 1 in 3 councils piloting or using AI — leading the UK

[15740] Independent advisory board plus sector and regional AI Champions

## Scotland's AI Strategy [15741]

## Wales [15745]

[15746] National AI plan, 2025

[15747] Strategy

## AI Cymru — the AI Plan for Wales (November 2025); Office for AI established June 2025 [15748]

[15749] Who leads

[15750] Welsh Government · Centre for Digital Public Services (CDPS)

[15751] Signals

[15753] Workforce, ethics and service guidance brought together early

[15754] Welsh-language parity a design requirement for public AI services

[15755] Council adoption early-stage (AI Readiness of UK Local Authorities, 2025)

## Centre for Digital Public Services [15756]

## Northern Ireland [15760]

[15761] Draft strategy, consultation closed 7 October 2026

[15762] Strategy

## Draft public-sector AI strategy (August 2026) — a draft, not adopted policy; Office of AI and Digital announced 2025 [15763]

[15764] Who leads

[15765] The Executive Office · Department of Finance · Office of AI and Digital

[15766] Signals

[15767] Proposes human-oversight teams, redress mechanisms and AI risk-management standards

[15768] Procurement expectations on suppliers: oversight, fairness, transparency, accountability

[15769] Stated aim: close the adoption gap with Scotland and Wales

## NI Department of Finance [15770]

[15773] Local-government comparison: AI Readiness of UK Local Authorities 2025 (Heriot-Watt University & GoLLM), 208 councils across all four nations — Scotland leads, with roughly one council in three piloting or using AI.

[15774] Back to the contents · Suggest a correction (opens GitHub)

[15786] International

## Benchmarking the UK's position [15787]

[15788] Five reference jurisdictions, five different bets: from the EU's binding risk tiers to Singapore's testing-led pragmatism. Genuinely transferable: Canada's public assessment and inventory approach, Australia's named AI ownership and workforce model, Singapore's central adoption flywheel, US inventory discipline, and the EU's joint procurement direction.

[15791] Where Key instrument Model For public bodies

## UK [15798]

[15800] AI Playbook + sector regulators; ATRS; AI Security Institute evaluations

[15802] Principles-led, pro-innovation; non-statutory for now

[15804] Playbook principles and ATRS records; four published evaluations; frontier legislation under consideration

## EU [15807]

[15809] AI Act (in force 1 Aug 2024; Digital Omnibus 2026 defers high-risk duties to Dec 2027, public authorities to Aug 2030); EuropAI joint procurement

[15811] Binding, risk-based regulation

[15813] High-risk public deployments: conformity assessment, logging, human oversight, fundamental-rights impact assessment

## US [15816]

[15818] NIST AI Risk Management Framework; OMB memoranda; GAO oversight

[15820] Voluntary framework + agency rules; state laws vary

[15822] Federal AI use-case inventories and Chief AI Officers; rapid growth with persistent policy and budget challenges

## Canada [15825]

[15827] Directive on Automated Decision-Making + Algorithmic Impact Assessment; agentic-AI guidance (May 2026)

[15829] Binding on federal automated decisions

[15831] Mandatory AIA before deployment; names skill atrophy as an oversight risk; bounded autonomy and recoverability

## Singapore [15834]

[15836] Model AI Governance Framework · AI Verify toolkit

[15838] Voluntary, testing-led

[15840] Central funding, shared platforms, problem intake, applied learning — an adoption flywheel

## The EU AI Act's four risk tiers [15842]

[15843] In force 1 August 2024. The Digital Omnibus on AI (Regulation (EU) 2026/1744, in force 27 July 2026) moved stand-alone high-risk obligations to 2 December 2027, embedded high-risk systems to 2 August 2028 and high-risk systems for public authorities to 2 August 2030. Article 50 transparency duties have applied since 2 August 2026. Obligations follow the use case, not the technology. The benchmark other regimes are measured against.

[15846] Unacceptable

[15847] Banned outright: social scoring, subliminal manipulation, real-time remote biometric ID in public spaces (narrow exceptions).

[15849] High risk

[15850] Essential public services, law enforcement, employment, critical infrastructure: conformity assessment, documentation, human oversight, EU database registration.

[15852] Limited risk

[15853] Transparency duties: chatbots must say they are AI; synthetic media must be labelled.

[15855] Minimal risk

[15856] Most systems: spam filters, recommenders. No mandatory obligations; voluntary codes encouraged.

## The supranational layer [15857]

## OECD AI Principles + OECD.AI Observatory [15860]

[15861] The shared definition of AI used by the UK Playbook and the EU AI Act. The OECD.AI Policy Observatory tracks national AI policies worldwide; it is the model for this app's observatory.

## Council of Europe Framework Convention on AI (2024) [15863]

[15864] The first binding international AI treaty: human rights, democracy and the rule of law. The UK is a signatory.

## G7 Hiroshima AI Process (2023) [15866]

[15867] International guiding principles and a code of conduct for organisations developing advanced AI systems.

## AI Safety Summit series: Bletchley, Seoul, Paris [15869]

[15870] Frontier-safety declarations and the network of national AI safety and security institutes. Started at Bletchley Park, November 2023.

## UN General Assembly resolution (2024) [15872]

[15873] First UN consensus resolution on safe, secure and trustworthy AI for sustainable development.

[15874] Back to the contents · Suggest a correction (opens GitHub)

[15886] Reference · pace and parity

## Named once. Controlled nowhere. [15887]

[15888] Skill atrophy appears in this guide as a single sentence in the evidence chapter, credited to Canada. Nothing sits behind it: no control, no metric, no register field, no gate criterion, no owner. That is the honest answer to the question, and it is now backlog item PACE-01 . This chapter closes it, then applies the same test to everything else the world has built that we have not.

[15893] Named

## Yes [15894]

[15895] One sentence, evidence chapter, attributed to Canada

[15897] Controlled

## No [15898]

[15899] No control, no owner, no frequency

[15901] Measured

## No [15902]

[15903] No metric in the barometer or control tower

[15905] Gated

## No [15906]

[15907] No criterion in the quality gate

## What Canada actually did [15908]

[15909] Six moves, and the last is the operable one. The instrument is the Guide on the Use of Agentic Artificial Intelligence, published by the Treasury Board of Canada Secretariat on 22 May 2026, sitting on top of a directive that already made assessment mandatory.

## Named the risk inside an instrument [15912]

[15913] Continued offloading of decisions to AI agents can lead to knowledge and skill atrophy and weakened human judgment. Employees become less practiced at core tasks and slower to notice when something is wrong.

[15914] Guide on the Use of Agentic AI, TBS, 22 May 2026

## Tied it to the validity of oversight [15916]

[15917] Maintenance of relevant skill sets among agentic AI users and deployers is treated as a prerequisite for meaningful human oversight. Not a wellbeing concern — a validity condition on the control itself.

[15918] Same instrument, mitigations

## Added two agent-specific principles [15920]

[15921] Bounded autonomy and recoverability, introduced alongside the existing generative-AI principles rather than replacing them.

[15922] Same instrument

## Named the consequence chain [15924]

[15925] Service quality, privacy and security, legal defensibility and public trust. The risk is framed as legal and operational exposure, not a training preference.

[15926] Same instrument

## Made assessment mandatory and public [15928]

[15929] Algorithmic Impact Assessment before deployment, four impact levels, external peer review at levels III and IV, questionnaire published openly including on GitHub.

[15930] Directive on Automated Decision-Making

## Pointed at a concrete drill [15932]

[15933] Periodic human-only execution of agent-handled tasks for comparison; staff trained to interrogate agent outputs rather than accept them.

[15934] Commentary on the guide, May 2026

[15936] PACE-01 · proposed instrument

## Oversight currency [15937]

[15938] Canada names skill maintenance as a prerequisite for meaningful human oversight. A prerequisite that nobody measures is a sentiment. Aviation, nuclear operations and clinical practice all solved this the same way: recency requirements, evidenced, with authority attached. If you supervise the work, you stay current in the work. Six components, all of them auditable.

[15940] Component What it does Who holds it Evidence

## Manual-mode drill [15947]

[15949] A reviewer executes an agent-handled task unaided, then compares. Tier 1 monthly, tier 2 quarterly, tier 3 twice yearly.

[15951] Reviewer

[15953] Drill record holding both outputs

## Currency window [15956]

[15958] A reviewer whose last unaided execution predates the tier window loses approval authority on that queue until re-current. Enforced, not advised.

[15960] Service owner

[15962] Authority state in the register

## Divergence log [15965]

[15967] Every drill records agreement or disagreement and why. Sustained perfect agreement is itself a signal — it is what rubber-stamping looks like from outside.

[15969] Reviewer

[15971] Divergence entries with reasons

## Challenge rate [15974]

[15976] Proportion of agent outputs materially amended before acceptance. A falling challenge rate against a flat error rate is drift, not improvement.

[15978] Control tower

[15980] Monthly trend per queue

## Rotation [15983]

[15985] No reviewer supervises the same agent-handled queue continuously. Rotation preserves unaided practice somewhere in the role.

[15987] Line manager

[15989] Rota showing unaided work

## Displaced-skill field [15992]

[15994] The register records which skills the agent displaces, who must retain them and to what standard. If nobody is named, the deployment is not approvable.

[15996] Deployment owner

[15998] Register field, tested at each gate

[15999] The uncomfortable component is the divergence log. A reviewer who agrees with the agent every time is either supervising a perfect agent or not supervising at all, and the record cannot tell the difference. Convergence has to be read as a warning rather than a result.

## Eight instruments elsewhere, measured against ours [16000]

[16001] Three are outright gaps: something binding or published elsewhere with no UK counterpart. Four are partial. One is context we should track rather than copy.

[16003] EU AI Act Article 4 — the AI literacy duty Gap

[16009] Binding since 2 February 2025 and unaffected by the proposed high-risk delay. Applies to deployers of every AI system, not only high-risk ones, and covers staff and contractors regardless of seniority. The compliance test is a dated, role-mapped programme that plausibly matches actual use.

[16011] Where we stand

[16012] Training is encouraged throughout UK guidance but is nowhere a duty, and course completion is not evidence of competence.

[16014] Singapore Model AI Governance Framework for Agentic AI Gap

[16020] World-first agentic framework, Davos 22 January 2026; version 1.5 on 20 May 2026 after feedback from over sixty organisations, with more than ten deployment case studies. Four pillars, unique agent identities tied to a supervising agent or user, threat modelling for memory poisoning, tool misuse and privilege compromise.

[16022] Where we stand

[16023] We hold secure-AI guidance and our own patterns, but no single agentic instrument and no agent identity requirement.

[16027] Canada

## Directive on Automated Decision-Making, plus the agentic guide [16029]

[16031] Gap

[16034] Assessment is mandatory before deployment, scored across four impact levels, with external peer review at the top two. The questionnaire is published openly, including on GitHub, and has become the instrument others copy.

[16036] Where we stand

[16037] ATRS is transparency after the fact, not assessment before it, and it is not a gate.

[16039] Australia AI Safety Institute inaugural report, 9 August 2026 Open to all

[16045] Found that NIST's risk framework, OWASP's Agentic Top 10, Singapore's agentic framework and ASD's agentic guidance all rest on the same hidden assumption: that one organisation owns every agent in a system. Cross-organisational agent risk is a structural gap none of them covers.

[16047] Where we stand

[16048] Our register assumes single-owner agents too. The gap is identified and unimplemented everywhere, including here — which makes it available.

[16050] Global Singapore Consensus companion report on agentic risk Partial

[16056] Ten foundational principles for managing agentic risk: least privilege, traceable identity, auditability, validated deployment, adversarial resilience, multi-agent stability, runtime assurance, interruptibility, legibility and human oversight.

[16058] Where we stand

[16059] We hold most of these as scattered controls. None is consolidated into a named principle set an approver can test a deployment against.

[16061] OECD Digital Government Outlook 2026 Partial

[16067] Thirty-two of thirty-six countries run AI training programmes; only thirteen of thirty-six train on using AI in public services or in policymaking. Broad capability is improving faster than role-specific readiness. Thirty of thirty-six have an institution governing public-sector AI; twenty-one of thirty-six offer central procurement support.

[16069] Where we stand

[16070] Our academy is role-based on paper. Depth of oversight-specific training has never been tested against this benchmark.

[16072] G7 GAIN network and the GovAI Grand Challenge Partial

[16078] A G7 AI network convened and chaired by Canada, tasked with a roadmap to scale successful public-sector AI projects and a catalogue of open-source, shareable AI solutions for members.

[16080] Where we stand

[16081] We participate. We have contributed no reusable instrument to the catalogue.

[16083] Asia-Pacific Korea AI Basic Act (2026), Taiwan AI Basic Act (2025) Tracking

[16089] Regional convergence on human oversight, data safeguards and prohibitions on harmful or deceptive use, arriving through basic law rather than sectoral guidance.

[16091] Where we stand

[16092] Context rather than gap: the UK route is guidance-led by choice. Worth tracking for interoperability, not imitation.

## The backlog, MoSCoW'd [16093]

[16094] Thirteen items and three deliberate refusals. Every item has an owner and a first deliverable, because an unowned backlog item is a wish.

## Must [16098]

[16100] This quarter. Each one closes a gap that leaves an existing control unsound.

## PACE-01 [16103]

## Oversight currency [16105]

[16106] Manual-mode drills, currency windows, divergence log, rotation and the displaced-skill register field. Turns the Canada finding into something an auditor can test.

[16107] Owner: Learning lead with service owners First: Control spec and tier windows

## PACE-02 [16112]

## Evidenced literacy duty [16114]

[16115] A dated, role-mapped competence requirement for anyone who operates or approves an agent, contractors in scope. The Article 4 test, applied voluntarily and ahead of any obligation.

[16116] Owner: Learning lead First: Role-to-competence map

## PACE-03 [16121]

## Agent identity [16123]

[16124] Every agent carries a unique identity bound to a named human owner and, where orchestrated, to a supervising agent. Prerequisite for audit, for handover and for retirement.

[16125] Owner: Architecture First: Identity schema in the register

## PACE-04 [16130]

## Bounded autonomy and recoverability [16132]

[16133] Adopt both as named approval principles. Every agent has a tested interrupt and a tested rollback before it goes live, with the test evidenced.

[16134] Owner: Assurance lead First: Two gate criteria and a test script

## PACE-05 [16139]

## Drift telemetry [16141]

[16142] Challenge rate and divergence surfaced in the control tower beside assurance status, per queue, monthly.

[16143] Owner: Control tower First: Two new tiles

## Should [16149]

[16151] Next two quarters. These extend reach rather than repair a fault.

## PACE-06 [16154]

## Cross-boundary agents [16156]

[16157] Register fields for agents we interact with but do not own: supplier, other department, arm's-length body. The first implementation of the gap Australia named.

[16158] Owner: Architecture with commercial First: Field set and one worked case

## PACE-07 [16163]

## Multi-agent systemic risk [16165]

[16166] An assessment step for orchestrated patterns, covering interaction effects that no single-agent assessment can see.

[16167] Owner: Assurance lead First: Assessment addendum

## PACE-08 [16172]

## Oversight-specific training [16174]

[16175] Not general AI awareness. Training in interrogating outputs, recognising plausible-but-wrong, and running a manual-mode drill.

[16176] Owner: Academy First: Curriculum for three roles

## PACE-09 [16181]

## Assessment before deployment [16183]

[16184] A scored pre-deployment assessment distinct from the transparency record, with independent peer review at the top tiers.

[16185] Owner: Governance office First: Scoring instrument

## PACE-10 [16190]

## Extended threat model [16192]

[16193] Memory poisoning, tool misuse and privilege compromise added to the agent threat model and to the security review.

[16194] Owner: Security lead First: Threat model revision

## Could [16200]

[16202] Worth doing, sequenced behind the above. This is where the leadership case is actually made.

## PACE-11 [16205]

## Publish the instruments [16207]

[16208] Register schema, gate criteria and the currency control released openly under the Open Government Licence, versioned, as Canada did with its assessment.

[16209] Owner: Governance office First: Public repository

## PACE-12 [16214]

## Reciprocal assurance pilot [16216]

[16217] One partner nation, one deployment class, mutual recognition of assurance evidence. Tests whether our evidence travels before we offer it widely.

[16218] Owner: Governance office First: Pilot terms with one partner

## PACE-13 [16223]

## Atrophy measurement study [16225]

[16226] Longitudinal measurement of unaided performance in agent-supported roles, with an academic partner. Nobody holds this data, which is why everyone is asserting rather than measuring.

[16227] Owner: Evaluation lead First: Study protocol

## Won't — for now [16233]

[16235] Named, so the omission reads as a decision rather than an oversight.

## PACE-W1 [16238]

## Statutory literacy penalties [16240]

[16241] Not ours to set. We build the evidence base a policy decision would need.

[16242] Owner: — First: Revisit when policy opens

## PACE-W2 [16247]

## A UK agentic act [16249]

[16250] The guidance route moves faster, and we do not yet hold the evidence to legislate well.

[16251] Owner: — First: Revisit after PACE-13

## PACE-W3 [16256]

## Certifying supplier agents [16258]

[16259] Capacity we do not have. Contract terms and evidence requirements instead.

[16260] Owner: — First: Revisit at scale

## Four things nobody has published yet [16263]

[16264] Parity is a floor, and reaching it puts us level with instruments already a year old. Each of these is a control we could be first to publish, and three of the four came out of our own case work rather than the international scan.

## Oversight currency as a revocable authority [16269]

[16270] Canada names skill maintenance as a prerequisite for oversight. Nobody has made it measurable and revocable — an approval right you can lose by going stale. Publishing the control with tier windows and drill records would be first.

## The orphaned-agent control [16274]

[16275] Machinery-of-government change moves an owner; active agent work continues unattended and is later inherited by a team that never approved it. No framework surveyed handles ownership transfer on reorganisation.

## Attention budgets for review [16279]

[16280] Approval capacity treated as a finite, costed resource and rationed by risk tier, so review is real where it matters instead of uniform and hollow everywhere.

## Cross-boundary agent handshake [16284]

[16285] Australia's institute named cross-organisational agent risk as a gap no framework covers. A register field plus a handshake at departmental and supplier boundaries would be the first implementation of it.

## Keeping pace is a rhythm, not a document [16288]

[16289] Four of the eight instruments above were published or revised in the last eight months. A guide refreshed annually is a guide that is wrong for eleven of them.

[16292] Weekly

[16294] Horizon scan into the guidance ticker: new instrument, new version, new enforcement action.

## Scan rota [16295]

[16298] Fortnightly

[16300] Instrument diff across the eight tracked jurisdictions. What changed, what it obliges, whether it touches a control we hold.

## Governance office [16301]

[16304] Monthly

[16306] Re-MoSCoW the backlog. Anything sitting in Should for two cycles is promoted or killed, never carried.

## Governance office [16307]

[16310] Quarterly

[16312] Publish the delta pack and contribute one reusable instrument to a shared catalogue.

## Governance office [16313]

[16316] Annually

[16318] Reciprocal review with a partner nation: they read our instruments, we read theirs, both publish the findings.

## SRO [16319]

## Where the work goes once it exists [16321]

[16322] Five routes already open to us. None of them takes a position paper; all of them take a working instrument.

## G7 GAIN [16323]

[16324] The network's remit includes a catalogue of open-source, shareable AI solutions for members. A register schema and a currency control are exactly that shape.

## OECD.AI and the Digital Government Outlook [16325]

[16326] The comparative baseline every country is measured against. Contributing method, rather than only returning survey answers, changes what the baseline measures.

## Council of Europe Framework Convention [16327]

[16328] The first binding international AI treaty, on human rights, democracy and the rule of law. The UK is a signatory, and the validity of human oversight sits squarely inside its scope.

## The AI safety institute network [16329]

[16330] The UK allocated roughly A$460m at the 2025 spending review, against about A$50m over five years in Canada and about A$11m a year in Singapore. Capacity to convene is not the constraint.

## Open publication [16331]

[16332] Open Government Licence v3.0, public repository, versioned. Canada published its assessment questionnaire openly and it became the reference others adopted.

[16333] Sources: Guide on the Use of Agentic Artificial Intelligence and Directive on Automated Decision-Making, Treasury Board of Canada Secretariat; EU AI Act Article 4 and the AI Office Q&A on AI literacy; IMDA Model AI Governance Framework for Agentic AI v1.5 (20 May 2026); Australian AI Safety Institute inaugural report (9 August 2026); Singapore Consensus companion report on agentic risk; OECD Digital Government Outlook 2026 and Building an AI-ready public workforce (2026); G7 GovAI Grand Challenge and GAIN, Treasury Board of Canada Secretariat and Impact Canada. Figures are as published by each source and are not converted or combined.

[16334] Back to the contents · Suggest a correction (opens GitHub)

[16346] Reference · crosswalk

## Where human oversight meets the standards you already follow [16347]

[16348] Each line maps an oversight measure to a UK or international standard, and states what that standard assumes. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

[16355] Standard or source

[16356] Family

[16357] Oversight measure it supports

[16358] What it assumes

[16361] Service Standard point 10 (define success, measure) and point 14 (operate reliably)

[16362] UK

[16363] Oversight performance as a measurable service property

[16364] That the service is measured and works

[16366] UK AI Playbook principle 4 — meaningful human control

[16367] UK

[16368] Evidence of whether it is

[16369] That the human control is meaningful

[16371] ATRS

[16372] UK

[16373] Nothing directly; ATRS records tools, not oversight arrangements. An ATRS extension is a Should, not a prerequisite

[16374] Transparency about the tool

[16376] DUA Act 2025 ADM provisions

[16377] UK

[16378] Structured reason capture is the evidential basis for contestability

[16379] Contestability, right to human review

[16381] Public Sector Equality Duty

[16382] UK

[16383] Reason code equality_concern; differential impact monitoring in the EqIA

[16384] Due regard, no disparate impact

[16386] ISO/IEC 42001 clauses on operational control and monitoring

[16387] International

[16388] The event schema and metric set map directly onto A.6 operational planning and 9.1 monitoring

[16389] Documented operation and performance evaluation

[16391] NIST AI RMF — MEASURE 2.8, 3.1, 3.2

[16392] International

[16393] This is a direct implementation of MEASURE 3.2

[16394] Human-AI configuration is assessed

[16396] EU AI Act Art. 14 (relevant to ALBs operating in the EU)

[16397] International

[16398] The only binding automation-bias provision anywhere; this measures compliance with it

[16399] Oversight persons can remain aware of automation bias

[16401] NCSC Cyber Assessment Framework — B and C outcomes

[16402] UK

[16403] The degraded-mode standard is a continuity control

[16404] Resilience, capability to detect

[16406] AI Playbook Principle 4

[16407] UK

[16408] M2 cross-reference (delegation competence precondition)

[16409] Meaningful human control

[16411] EU AI Act Art. 14 / Art. 4

[16412] International

[16413] Source for M2 (with Canada)

[16414] Oversight persons aware of over-reliance; AI literacy

[16416] TBS Canada Guide §h 'Watch for automation drift'

[16417] Canada

[16419] Occasional manual performance for comparison

[16421] TBS Canada §c / Singapore sandbox

[16422] Canada

[16424] Resourced oversight, HITL fatigue

[16426] TBS Canada §f

[16427] Canada

[16429] Agent offboarding tied to owner

[16431] NHS DCB0129 / DCB0160

[16432] UK

[16433] Domestic precedent for currency (S1)

[16434] Named suitably qualified Clinical Safety Officer; operator competence in safety case

[16436] Blueprint for Modern Digital Government (build once, reuse)

[16437] UK

[16438] Mandate for single oversight instrument / shared platform primitives

[16439] Reuse across public sector

[16441] ISO/IEC 42119-8 (testing of generative AI)

[16442] International

[16443] Emerging adjacent hook in SC 42

[16444] —

[16445] Back to the contents · Suggest a correction (opens GitHub)

[16457] Reference · obligations

## 164 obligations that bind AI use in UK public bodies [16458]

[16459] Law, policy and guidance that apply when public servants use AI, across the four nations: data protection and transfers, records and FOI, security, equality, transparency, procurement, financial control, sustainability and more. Researched from primary sources in October 2026 and link-checked on 22 November 2026; check the source before you rely on any entry, because guidance changes. Not legal advice.

## Cloud and hosting (3) [16461]

[16466] Obligation

[16467] Where, kind and status

[16468] What it means for AI use

[16469] Owner

[16470] Basis

[16473] Government Cloud First policy

[16474] UK-wide . Policy, Current

[16476] Central government must default to public cloud (mandatory); it is strongly recommended for the wider public sector. The policy does not require UK data location: it allows services provided overseas or globally, subject to due diligence using ICO and NCSC guidance. SECRET and above is unlikely to suit public cloud. Caveat: Last updated 19 June 2023 on page history. 'UK-wide' here means UK central government; devolved administrations set their own policies.

[16478] GDS (DCMS) and Central Digital and Data Office

[16479] Government Cloud First policy (opens an external website)

[16483] Scottish public sector cloud computing guidance (Scotland's Digital Future)

[16484] Scotland . Policy, Unconfirmed

[16486] Positions cloud as a priority option and the intended dominant model for Scottish digital public services, covering central government, police and fire, local authorities, health and further/higher education. Scottish bodies choosing an AI service should check this alongside current Scottish Government digital guidance. Caveat: Dated 2015; whether it remains current Scottish Government policy is unconfirmed. Its data location content was not read. A gov.scot 'Cloud first' collection exists but returned no content.

[16488] Scottish Government (Digital Directorate)

[16489] Scotland's Digital Future: Scottish public sector cloud computing guidance (opens an external website)

[16493] G-Cloud 15 framework (Crown Commercial Service)

[16494] UK-wide . Framework, Unconfirmed

[16496] The main route for buying cloud and SaaS (including AI services) in the public sector. G-Cloud 15 adds Cyber Essentials (Plus for IaaS/PaaS lots), a lot for IaaS/PaaS above OFFICIAL, and terms closer to the Public Sector Contract. Buyers must still check data location and sub-processors in each service description and contract. Caveat: Anticipated award date was 17 Sep 2026; whether G15 is live and its data location clauses are unconfirmed. CCS primary documents not read.

[16498] Crown Commercial Service

[16499] G-Cloud 15 (G15) framework: key changes for UK public sector cloud suppliers (Burges Salmon) (opens an external website)

## Conduct and accountability (13) [16502]

[16507] Obligation

[16508] Where, kind and status

[16509] What it means for AI use

[16510] Owner

[16511] Basis

[16514] Civil Service Code (Home Civil Service)

[16515] Great Britain . Standard, In force

[16517] The four values (integrity, honesty, objectivity, impartiality) apply to everything you produce with AI help. You must set out facts truthfully, correct errors promptly, keep accurate official records and not disclose official information without authority, so AI output must be checked before it informs advice, and official information must not be put into tools not authorised to hold it. Special advisers are covered except for objectivity and impartiality. Caveat: The code does not mention AI; applying it to AI use is an interpretation. Scottish and Welsh Government have their own versions (see separate items).

[16519] Cabinet Office (Civil Service Commission hears complaints)

[16520] The Civil Service Code (opens an external website)

[16524] Civil Service Code (Welsh Government version)

[16525] Wales . Standard, In force

[16527] Welsh Government civil servants are part of the Home Civil Service and follow a Welsh Government version of the Code with the same four values. The same duties on truthful advice, accurate records and protecting official information govern AI-assisted work. Caveat: Page dated 2017 (document labelled January 2017); no AI-specific content.

[16529] Welsh Government

[16530] Civil Service code (GOV.WALES) (opens an external website)

[16534] Civil Service Code (Scottish Government version)

[16535] Scotland . Standard, Unconfirmed

[16537] Scottish Government civil servants are part of the Home Civil Service; the GB Code states the Scottish Government and its agencies have their own version of the Code with the same core values. Treat AI-assisted work as subject to the same duties of honesty, objectivity and confidentiality. Caveat: Current gov.scot URL for the Scottish version was not retrieved; only an archived copy surfaced. Existence confirmed via the GB Code's own text; current text unverified.

[16539] Scottish Government

[16540] The Civil Service Code (gov.uk) - note on Scottish and Welsh versions (opens an external website)

[16544] NICS Code of Ethics

[16545] Northern Ireland . Standard, In force

[16547] Northern Ireland civil servants follow the NICS Code of Ethics: integrity, honesty, objectivity and impartiality. It requires accurate official records, prompt correction of factual errors, openness within the law and no unauthorised disclosure, so AI outputs must be verified and official information kept out of unapproved tools. Caveat: First published February 2022, revised May 2024, reviewed annually each February; a later revision may exist. No AI-specific text.

[16549] Department of Finance (NI)

[16550] NICS Code of Ethics (HTML version) (opens an external website)

[16554] Artificial Intelligence Playbook for the UK Government

[16555] UK-wide . Guidance, Current

[16557] The main cross-government guidance for civil servants using or building AI, built on 10 principles: know what AI is and its limits; use it lawfully, ethically and responsibly; use it securely; keep meaningful human control; manage the full lifecycle; use the right tool; be open and collaborative; involve commercial colleagues early; have the right skills; and use the principles alongside your organisation's policies and assurance. End users are responsible for checking outputs for accuracy, fairness and legal compliance, and accountability rests with the organisation. Caveat: No visible 2026 revision or successor found as of 19 Oct 2026, despite the July 2026 machinery change. Written for central government but offered to the wider public sector; devolved governments use it alongside their own guidance.

[16559] Published by Government Digital Service; AI adoption policy now led by Cabinet Office (from 21 July 2026); GDS now in DCMS

[16560] Artificial Intelligence Playbook for the UK Government (opens an external website)

[16564] Generative AI Framework for HMG (withdrawn)

[16565] UK-wide . Framework, Withdrawn

[16567] Withdrawn on 10 February 2025 and replaced by the AI Playbook. Do not cite it as current guidance; update local policies that still refer to it.

[16568] Cabinet Office / CDDO (historical publisher)

[16569] Generative AI framework for HMG (opens an external website)

[16573] Guidance to civil servants on use of generative AI (2023, superseded)

[16574] UK-wide . Guidance, Withdrawn

[16576] The 2023 guidance told staff never to put classified, sensitive or policy-revealing information or personal data into public generative AI tools, and to cite AI output. It has been superseded (first by the Generative AI Framework, now by the AI Playbook), but its basic rule still reflects current practice in departmental policies. Caveat: The page is marked superseded rather than formally withdrawn; 'Withdrawn' status here means 'no longer current'.

[16578] Cabinet Office (historical publisher)

[16579] Guidance to civil servants on use of generative AI (opens an external website)

[16583] AI Insights series

[16584] UK-wide . Guidance, Current

[16586] A series of short technical explainers that sit alongside the AI Playbook, covering LLM bias, prompt engineering and prompt risks, agentic AI, RAG, AI coding assistants, synthetic data and model distillation. Use them for practical, topic-specific guidance; they do not replace departmental policy. Caveat: Last updated 3 August 2026 (15 titles at that date). Publisher listed as DCMS and GDS after the July 2026 machinery change.

[16588] Department for Digital, Culture, Media and Sport and Government Digital Service

[16589] AI Insights (opens an external website)

[16593] The People Factor and the Mitigating Hidden AI Risks Toolkit

[16594] UK-wide . Guidance, Current

[16596] Cabinet Office guidance drawn from scaling the in-house Assist tool. It sets out six 'hidden' risk areas: quality assurance, task-tool mismatch, perceptions and signalling, workflow challenges, ethics, and over-reliance. It recommends giving teams secure access to approved tools and knowing how general tools are being used, which is the closest central guidance to managing unsanctioned ('shadow') AI. Caveat: Does not address personal or consumer AI accounts as a distinct issue.

[16598] Cabinet Office

[16599] A human-centred approach to scaling and de-risking AI tools (opens an external website)

[16603] Staff use of personal or consumer AI tools ('shadow AI') - central position

[16604] UK-wide . Policy, Unconfirmed

[16606] No current, published cross-government rule specifically on staff using personal or consumer AI accounts for work was found. In practice the position comes from departmental security and acceptable-use policies, the Civil Service Code and data protection law: do not enter official, sensitive or personal information into tools your organisation has not approved, and follow your organisation's policies (AI Playbook principle 10). Caveat: This item records a gap, not a published instrument. Devolved administrations have their own internal rules (see the Welsh Government SIRO notice, Scottish Government and NICS items).

[16608] Cabinet Office (AI adoption) with departmental SIROs

[16609] AI Playbook principle 10; Guidance to civil servants on use of generative AI (2023) (opens an external website)

[16613] Scottish Government generative AI guidance for staff

[16614] Scotland . Guidance, Current

[16616] Scottish Government staff guidance (made public through FOI) tells officials not to put sensitive material into AI tools, including unreleased announcements, and to apply the test 'do not share anything you would not be happy to share with a member of the public'. Staff must fact-check outputs, avoid prompts that hint at future policy, and assess whether a paid tool protects submitted information. Caveat: Secondary source reporting an FOI release; the guidance itself is internal and its date and title are not published. A Scottish Government FOI response (April 2025) confirms general generative AI guidance is 'available to all staff'.

[16618] Scottish Government

[16619] Gen AI guidance tells Scottish officials do not share anything you would not share with a member of the public (PublicTechnology, reporting FOI release) (opens an external website)

[16623] Welsh Government SIRO Notice 2024/002: ChatGPT and generative AI tools

[16624] Wales . Policy, Current

[16626] Welsh Government staff may use only Microsoft 365 Copilot and Copilot for Bing with OFFICIAL-SENSITIVE information. They must not enter OFFICIAL-SENSITIVE or personal information into other tools such as ChatGPT, must take care discussing Welsh Government business in any AI tool (including on personal accounts), and must check all output. Buying AI licences or adding AI features needs Solution Design Authority approval. Caveat: Internal notice released through FOI in November 2025; it may since have been updated.

[16628] Welsh Government (Senior Information Risk Owner)

[16629] SIRO Notice 2024/002 (released under FOI, ATISN 26288) (opens an external website)

[16633] NICS Policy on the Use of (Generative) AI

[16634] Northern Ireland . Policy, Current

[16636] The Northern Ireland Civil Service has a policy on the use of generative AI, adopted in June 2024, that governs responsible and ethical AI use across departments. Microsoft Copilot was rolled out to staff in at least one department (Infrastructure) in December 2025. Departmental SIROs approve AI use (for example in The Executive Office). Caveat: Policy text not publicly retrieved; existence and date come from Assembly written answers (June 2026), reproduced on an MLA's website. An earlier NICS generative AI guidance dates from mid-2023.

[16638] Northern Ireland Civil Service (departmental SIROs)

[16639] Assembly written answers AQW 48759/22-27 and AQW 49372/22-27 (opens an external website)

## Copyright and IP (3) [16642]

[16647] Obligation

[16648] Where, kind and status

[16649] What it means for AI use

[16650] Owner

[16651] Basis

[16654] Generative AI and Crown copyright: a brief guide for government departments

[16655] UK-wide . Guidance, Current

[16657] Work that civil servants create with generative AI in the course of their duties, and then review, modify and assure, may be Crown copyright. Where a provider's terms give the user ownership of outputs, those outputs belong to the Crown. If the terms assign outputs to the provider, seek legal advice. Departments must still publish attribution and licensing statements and attribute third-party material. Caveat: No exact publication date; the copyright notice is 2025.

[16659] The National Archives

[16660] Generative AI and Crown copyright: A brief guide for government departments (opens an external website)

[16664] Open Government Licence and AI training on government content

[16665] UK-wide . Guidance, Current

[16667] Most Crown copyright material is published under the OGL, which allows it to be used to train AI models provided the licence terms, including attribution, are followed. Departments holding a delegation of authority to license on other terms must check whether AI providers' terms affect that licensing. Caveat: The OGL itself predates generative AI. TNA's view on training is guidance, not a court ruling.

[16669] The National Archives

[16670] Generative AI and Crown copyright: A brief guide for government departments (opens an external website)

[16674] Report on Copyright and Artificial Intelligence (DUAA ss.135-136)

[16675] UK-wide . Policy, Current

[16677] The government no longer prefers a broad text and data mining exception with a rightsholder opt-out, and has not chosen an alternative. It will gather more evidence, explore output labelling and digital replica rights, and keep protection for computer-generated works under review. There is no change to copyright law yet, so public bodies using AI must respect third-party copyright under existing law. Caveat: No legislative timetable. A digital replicas consultation was expected in summer 2026 and its publication is unconfirmed. The post-July 2026 owner department for copyright policy is unconfirmed.

[16679] Published by DSIT, DCMS and the Intellectual Property Office; IP policy now with BIST/IPO (post-July 2026, unconfirmed) (DSIT, abolished 21 July 2026; check the successor owner)

[16680] Report and impact assessment on copyright and artificial intelligence (opens an external website)

## Data protection (10) [16683]

[16688] Obligation

[16689] Where, kind and status

[16690] What it means for AI use

[16691] Owner

[16692] Basis

[16695] UK GDPR and Data Protection Act 2018

[16696] UK-wide . Law, In force

[16698] Any AI tool that processes personal data (in prompts, uploaded files, grounding data or outputs) is subject to UK GDPR and the DPA 2018. Data protection is reserved in Scotland and Northern Ireland and is a specific reservation for Wales, so the same law applies across the UK; devolved bodies follow it but have their own records and FOI regimes. Caveat: Explanatory notes say Scotland Act Sch 5 Pt II B2 and NI Act Sch 3 para 40 make it reserved; Wales Act 2017 adds a specific reservation (para 170). Amended by DUAA 2025 from 2025-2026.

[16700] Information Commission (successor to the ICO from 30 Sept 2026)

[16701] Data Protection Act 2018 Explanatory Notes (territorial extent) (opens an external website)

[16705] Data (Use and Access) Act 2025 — commencement status

[16706] UK-wide . Law, Partly commenced

[16708] Most data protection reforms commenced on 5 February 2026 (Commencement No. 6, SI 2026/82), including the new transfer regime, recognised legitimate interests and the new automated decision-making Articles 22A-D. The complaints duty started on 19 June 2026 and the Information Commission replaced the ICO on 30 September 2026. Check commencement before relying on any individual provision. Caveat: Earlier commencement orders: No.1 20 Aug 2025, No.3 5 Sep/17 Nov 2025, No.4 1 Dec 2025 (per Kennedys, grade B). Whether every remaining section has now commenced is unconfirmed; the departmental owner of data protection policy after July 2026 is inferred from the DCMS-published Information Commission release.

[16710] DCMS (UK data policy since the July 2026 machinery of government change); regulator: Information Commission

[16711] The Data (Use and Access) Act 2025 (Commencement No. 6 and Transitional and Saving Provisions) Regulations 2026 (SI 2026/82) (opens an external website)

[16715] Information Commission succeeds the ICO

[16716] UK-wide . Regulation, In force

[16718] From 30 September 2026 the Information Commission (a body corporate) replaced the Information Commissioner's Office as regulator for data protection, FOIA and EIR. The government says powers and responsibilities are unchanged and existing guidance continues, so ICO-branded guidance remains the reference. Update policy documents, privacy notices and DPIA templates that name the ICO. Caveat: Published by DCMS. Whether ico.org.uk URLs will move is not stated; URLs in this dataset still point to ico.org.uk.

[16720] Information Commission (successor to the ICO from 30 Sept 2026)

[16721] Information Commission succeeds the ICO as UK's data protection regulator (GOV.UK news) (opens an external website)

[16725] Recognised legitimate interests (Article 6(1)(ea))

[16726] UK-wide . Law, In force

[16728] A new lawful basis with five pre-approved public-interest purposes (responding to another body's public-task request, national security/defence, emergencies, crime, safeguarding) where no balancing test is needed. The ICO says public authorities performing their tasks should generally still rely on public task, not this basis, so it rarely justifies a department's own AI processing. Caveat: Commenced 5 Feb 2026 via DUAA s.70 and Sch 4.

[16730] Information Commission (successor to the ICO from 30 Sept 2026)

[16731] Recognised legitimate interest (ICO guidance) (opens an external website)

[16735] Automated decision-making — UK GDPR Articles 22A-22D

[16736] UK-wide . Law, In force

[16738] Since 5 February 2026 the old near-ban on solely automated decisions is replaced by Articles 22A-D: significant decisions based solely on automated processing are allowed with safeguards (information, a way to make representations, human intervention and the right to contest), with tighter limits where special category data is used. If an AI tool makes or effectively makes a significant decision without meaningful human involvement, these rules apply. The ICO's updated ADM guidance is still a draft. Caveat: Commenced by DUAA s.80 and Sch 6; does not apply to decisions taken before 5 Feb 2026 (SI 2026/82 reg 5). ICO consultation ran 31 Mar to 29 May 2026; final guidance not confirmed published as of 2026-10-19.

[16740] Information Commission (successor to the ICO from 30 Sept 2026)

[16741] Automated decision-making, including profiling (ICO, draft guidance under consultation) (opens an external website)

[16745] Statutory code of practice on AI and automated decision-making

[16746] UK-wide . Regulation, In force

[16748] Regulations in force from 12 May 2026 require the Information Commissioner to prepare a statutory code on processing personal data when developing and using AI and ADM, including children's data. The regulations do not themselves add obligations; once issued, courts and the regulator must take the code into account. Plan for it but do not assume its content yet. Caveat: The code itself is not published; secondary reporting (Arnold & Porter, Aug 2026, grade B) says it is not expected to take effect until 2027.

[16750] Information Commission (successor to the ICO from 30 Sept 2026)

[16751] Data Protection Act 2018 (Code of Practice on Artificial Intelligence and Automated Decision-Making) Regulations 2026 (SI 2026/425) (opens an external website)

[16755] ICO Guidance on AI and data protection (including DPIAs)

[16756] UK-wide . Guidance, Current

[16758] The main regulator guidance on fairness, lawfulness, transparency, accountability and DPIAs for AI. Deploying an AI tool that processes personal data at scale or in novel ways will normally need a DPIA before go-live. The ICO marks this guidance as under review following the DUAA, so check for updates before relying on detail. Caveat: Page states 'under review and may be subject to change'. The 'DPIA normally needed' wording is a summary of UK GDPR Art 35 practice, not a quotation from this page. The ICO also told government (27 May 2026 letter, reported by Local Government Lawyer, grade B) it will publish a procurement due-diligence resource for off-the-shelf cloud AI tools and agentic AI guidance; neither confirmed published.

[16760] Information Commission (successor to the ICO from 30 Sept 2026)

[16761] Guidance on AI and data protection (opens an external website)

[16765] Using AI in public services — Digital Scotland Service Manual

[16766] Scotland . Guidance, Current

[16768] Scottish Government guidance for the Scottish public sector on responsible use, transparency, human oversight and accountability: people remain responsible for decisions and AI should not be used where decisions cannot be explained or reviewed. It is a first iteration and will be revised. Caveat: The guidance URL shown in the blog carried a preview token; the guidance text was not read, so its coverage of data, records and FOI is unconfirmed.

[16770] Scottish Government (Public Sector AI Team, Digital Directorate)

[16771] New Artificial Intelligence (AI) guidance available for Scottish public sector (Digital Scotland blog) (opens an external website)

[16775] Workforce Partnership Council guidance on AI and algorithmic management (Wales)

[16776] Wales . Guidance, Current

[16778] Social partnership guidance agreed by Welsh Government, public sector employers and trade unions on algorithmic management and AI at work, built around checks and balances, responsible implementation and post-adoption evaluation. Welsh public bodies introducing AI that affects staff should involve unions early. Caveat: No Welsh Government equivalent of a staff generative AI data-handling policy was confirmed.

[16780] Welsh Government / Workforce Partnership Council

[16781] Wales' public sector leading the way in responsible AI use (opens an external website)

[16785] NHS Digital Technology Assessment Criteria (DTAC) — England

[16786] England . Framework, Current

[16788] NHS England's baseline assessment for digital health technologies (clinical safety, data protection, technical security, interoperability). The 2026 version cuts questions by about a quarter and aligns scope with NICE; the new form was required from 6 April 2026. AI software used in English NHS settings goes through it. Caveat: Health only, England only. The source does not mention AI explicitly. Scotland/Wales/NI health equivalents not covered here.

[16790] NHS England / DHSC

[16791] Updated NHS England Digital Technology Assessment Criteria (DTAC) form and guidance (opens an external website)

## Data residency and transfers (10) [16794]

[16799] Obligation

[16800] Where, kind and status

[16801] What it means for AI use

[16802] Owner

[16803] Basis

[16806] International transfers — the 'data protection test' (UK GDPR Art 46(6))

[16807] UK-wide . Law, In force

[16809] Since 5 February 2026 transfers relying on safeguards (IDTA, Addendum, BCRs) must meet a 'data protection test': protection after transfer must not be materially lower than in the UK. In practice this is what the ICO still calls a transfer risk assessment. If an AI supplier processes prompts or files outside the UK, someone must have done this assessment or the destination must be covered by UK adequacy regulations.

[16810] Information Commission (successor to the ICO from 30 Sept 2026)

[16811] UK GDPR Article 46 (as amended by DUAA 2025 Sch 7) (opens an external website)

[16815] UK adequacy regulations (including the UK Extension to the EU-US Data Privacy Framework)

[16816] UK-wide . Regulation, Current

[16818] Transfers to countries covered by UK adequacy regulations need no extra safeguards. For US-hosted AI services, transfers can rely on the UK Extension only if the US recipient is certified for it; otherwise the IDTA or Addendum plus a transfer risk assessment are needed. The ICO keeps the list of current adequacy regulations. Caveat: Date is the page metadata date; the hub does not state when the adequacy list was last changed. Which department now makes adequacy regulations after July 2026 is not confirmed.

[16820] DCMS (makes UK adequacy regulations; inferred post-July 2026) and Information Commission (guidance)

[16821] International transfers (ICO guidance hub) (opens an external website)

[16825] International Data Transfer Agreement (IDTA) and UK Addendum to EU SCCs

[16826] UK-wide . Regulation, Current

[16828] Standard clauses for restricted transfers not covered by adequacy. The ICO says to keep using the current versions until updated versions are issued in 2026, and to pair them with a transfer risk assessment. Check AI supplier data processing terms include one of these where processing or support access happens outside the UK. Caveat: Updated IDTA/Addendum versions were promised for 2026; not confirmed issued as of 2026-10-19. The ICO's January 2026 streamlined transfers guidance uses a three-step test to decide whether a restricted transfer occurs (BCLP, grade B).

[16830] Information Commission (successor to the ICO from 30 Sept 2026)

[16831] What are standard data protection clauses (the UK IDTA and the Addendum)? (opens an external website)

[16835] EU adequacy decisions for the UK (GDPR and LED) renewed

[16836] UK-wide . Regulation, In force

[16838] The European Commission renewed both UK adequacy decisions on 19 December 2025, so personal data can keep flowing from the EU/EEA to UK public bodies and suppliers without extra safeguards. The decisions run to 27 December 2031 with ongoing monitoring and a review at least four years after adoption; further divergence in UK law could put them at risk. Caveat: Primary EC decision text not fetched; dates corroborated by Hunton (B). Expiry 27 Dec 2031 confirmed for the LED decision by eucrim and for 'the renewed decisions' by Hunton.

[16840] European Commission (EU decision); UK counterpart DCMS (inferred)

[16841] Commission renewed adequacy decisions for data transfers to the UK (eucrim) (opens an external website)

[16845] Microsoft 365 Copilot — UK data at rest and in-country processing

[16846] UK-wide . Supplier fact, Current

[16848] Supplier evidence: Copilot prompts, responses and the semantic index are stored at rest in the tenant's local geography; UK tenants are covered by Product Terms and Advanced Data Residency commitments. In-country processing (inference) for the UK was announced for end-2025 but Microsoft's April 2026 note moved it to expected end-2026, and Microsoft says non-EU customers' queries may be processed in the US, EU or elsewhere. Anthropic models inside Microsoft Copilot are excluded from the EU Data Boundary. Caveat: Supplier evidence, checked 2026-10-19. UK in-country processing availability by end-2026 is a supplier expectation, not confirmed live.

[16850] Microsoft (supplier); buyer due diligence: departmental SIRO/DPO

[16851] Microsoft 365 blog: in-country data processing for Microsoft 365 Copilot (with 3 Apr 2026 editor's note); Microsoft Learn: Data Residency for Microsoft 365 Copilot (opens an external website)

[16855] Azure OpenAI / Foundry deployment types and processing location

[16856] UK-wide . Supplier fact, Current

[16858] Supplier evidence: 'Global' deployments may process prompts in any region; 'Data Zone' deployments process within a Microsoft-defined zone (documented as US or EU); 'Standard/Regional' deployments process in the deployment's region. Data at rest stays in the resource's geography. For UK-only processing choose a regional deployment in UK South (where the model is offered), not Global or Data Zone. Caveat: Supplier evidence, checked 2026-10-19. Microsoft Learn does not document a UK data zone; which models are offered regionally in UK South changes often and was not enumerated here. Claude models in Foundry are processed by Anthropic as independent processor (InfoQ, July 2026, grade B).

[16860] Microsoft (supplier)

[16861] Deployment types for Azure AI Foundry Models; Region availability for Foundry Models sold by Azure (Microsoft Learn) (opens an external website)

[16865] Amazon Bedrock — Claude availability in London (eu-west-2)

[16866] UK-wide . Supplier fact, Current

[16868] Supplier evidence: for Claude Opus 4.8, AWS lists no in-region invocation in London; London can call the EU cross-region profile, which may route requests to EU regions (Frankfurt, Stockholm, Milan, Spain, Ireland, London, Paris), or the global profile. There is no UK-only geographic profile. AWS warns not to rely on the profile prefix alone and to list the destination regions from the API. Caveat: Supplier evidence, checked 2026-10-19, for one model only; other Claude models may differ. An EU profile means processing in the EU, which is covered by UK adequacy regulations for EU/EEA but is not UK in-country processing.

[16870] Amazon Web Services (supplier)

[16871] Claude Opus 4.8 model card — Amazon Bedrock user guide; Supported Regions and models for inference profiles (opens an external website)

[16875] Anthropic Claude API — inference geography and retention

[16876] UK-wide . Supplier fact, Current

[16878] Supplier evidence: the first-party Claude API offers inference_geo values 'global' (default) or 'us' only, and workspace data-at-rest geography 'us' only; no UK or EU option is documented. API inputs and outputs are deleted within 30 days by default unless zero data retention or other terms apply; content flagged under the usage policy may be kept up to 2 years. UK residency, where needed, has to come through a cloud platform or a negotiated agreement. Caveat: Supplier evidence, checked 2026-10-19. 2026-07-01 is the Privacy Center page date.

[16880] Anthropic (supplier)

[16881] Data residency (Claude Platform docs); How long do you store my organization's data? (Anthropic Privacy Center) (opens an external website)

[16885] OpenAI — UK data residency and enterprise/API retention

[16886] UK-wide . Supplier fact, Current

[16888] Supplier evidence: OpenAI says business data is not used for training by default, API inputs/outputs may be kept up to 30 days for abuse monitoring (zero data retention available for eligible use), and ChatGPT Enterprise admins control retention. UK data residency for the API, ChatGPT Enterprise and Edu was reported from 24 October 2025, with exclusions such as connectors, MCP use and workspace metadata. Caveat: Supplier evidence, checked 2026-10-19. The UK residency detail comes from secondary reporting (SDxCentral, 23 Oct 2025, grade B); OpenAI's own residency page was not read. MoJ was named as first government customer.

[16890] OpenAI (supplier)

[16891] Enterprise privacy at OpenAI (updated 8 Jan 2026); SDxCentral: OpenAI signs UK data residency deal (opens an external website)

[16895] Google Gemini on Vertex AI — data residency and ML processing

[16896] UK-wide . Supplier fact, Current

[16898] Supplier evidence: data stored in a chosen location stays at rest there; regional and multi-region endpoints keep ML processing within that jurisdiction, but global endpoints give no residency guarantee. The EU multi-region excludes the UK. A 'United Kingdom (europe-west2)' option exists, but which models process in-UK must be checked per model. Caveat: Supplier evidence, checked 2026-10-19. Per-model UK processing marks were not readable in the fetch; Gemini in Google Workspace residency not checked.

[16900] Google Cloud (supplier)

[16901] Data residency (Google Cloud documentation, updated 15 Oct 2026) (opens an external website)

## Equality and rights (12) [16904]

[16909] Obligation

[16910] Where, kind and status

[16911] What it means for AI use

[16912] Owner

[16913] Basis

[16916] Public Sector Equality Duty (Equality Act 2010, s.149)

[16917] Great Britain . Law, In force

[16919] Public authorities in England, Scotland and Wales must have due regard to eliminating discrimination, advancing equality of opportunity and fostering good relations. The EHRC says this applies from the start when deciding whether to use AI, to AI already in use, and to systems run by suppliers on your behalf. Monitor outcomes for indirect discrimination. Caveat: EHRC AI guidance has not been updated since September 2022.

[16921] Government Equalities functions (Office for Equality and Opportunity moved to MHCLG, July 2026); enforced by EHRC

[16922] Artificial intelligence: meeting the Public Sector Equality Duty (PSED) (opens an external website)

[16926] EHRC: Assessing the equality impact of AI-based technology - six discussion points (Scotland)

[16927] Scotland . Guidance, Current

[16929] Aimed at Scottish listed authorities buying AI. It sets out six points to work through: relevance and impact, evidence on training data, equality duty needs, changes and mitigations, supplier information and the decision (including not adopting), and monitoring. Keep records, and publish the assessment if you adopt the technology.

[16930] Equality and Human Rights Commission

[16931] Assessing the equality impact of AI-based technology: six discussion points (opens an external website)

[16935] Scottish specific equality duties (Equality Act 2010 (Specific Duties) (Scotland) Regulations 2012)

[16936] Scotland . Regulation, In force

[16938] Listed Scottish authorities must assess the equality impact of new or revised policies and practices and consider equality in procurement. This includes introducing AI tools and systems. Publish the results of assessments and mainstreaming reports. Caveat: The 2025 amendment only adds a listed authority and adjusts reporting dates. A wider review of the Scottish specific duties is under way (Regulation 12 report 2025-29, Holyrood committee inquiry); further change is possible.

[16940] Scottish Government; enforced by EHRC

[16941] The Equality Act 2010 (Specific Duties) (Scotland) Amendment Regulations 2025 (SSI 2025/369) (opens an external website)

[16945] Welsh specific equality duties (Equality Act 2010 (Statutory Duties) (Wales) Regulations 2011)

[16946] Wales . Regulation, In force

[16948] Listed Welsh authorities must assess how new or proposed policies and practices affect protected groups, publish the assessment where the impact is substantial, and consider equality in procurement award criteria and contract conditions. These duties apply to AI deployment and AI procurement. Caveat: EHRC page last updated 30 January 2026.

[16950] Welsh Government; enforced by EHRC

[16951] Public Sector Equality Duty: specific duties in Wales (EHRC) (opens an external website)

[16955] Fairer Scotland Duty (Equality Act 2010, Part 1, Scotland)

[16956] Scotland . Law, In force

[16958] Scottish Ministers and listed Scottish public bodies must actively consider how to reduce inequalities of outcome caused by socio-economic disadvantage when making strategic decisions. Strategic decisions about adopting AI in services, such as automating eligibility or triage, should be assessed for their effect on people on low incomes and in deprived areas. Caveat: Application to AI decisions is interpretive. The gov.scot guidance page could not be fetched in this check.

[16960] Scottish Government

[16961] Equality Act 2010, section 1 (commencement for Scotland 1 April 2018) (opens an external website)

[16965] Socio-economic Duty (Wales)

[16966] Wales . Law, In force

[16968] Welsh Ministers, councils, health boards, NHS trusts, fire and national park authorities and the Welsh Revenue Authority must have due regard to reducing inequalities of outcome from socio-economic disadvantage when making strategic decisions. Strategic decisions to introduce AI into public services fall within scope. Caveat: Application to AI decisions is interpretive.

[16970] Welsh Government

[16971] The Socio-economic Duty: statutory guidance (opens an external website)

[16975] Northern Ireland Act 1998, section 75 - equality and good relations duties

[16976] Northern Ireland . Law, In force

[16978] Designated NI public authorities must have due regard to promoting equality of opportunity across nine categories, including religious belief, political opinion, age, disability and people with dependants. They must also have regard to promoting good relations. AI policies and deployments should be equality-screened under the body's equality scheme, as The Executive Office did for the draft AI Strategy. Caveat: No ECNI AI-specific guidance was found; the screening example comes from The Executive Office. The NI Act 1998 is UK legislation; equality policy is transferred to the NI Assembly.

[16980] Equality Commission for Northern Ireland (oversight); each designated public authority

[16981] Northern Ireland Act 1998, section 75 (opens an external website)

[16985] Section 75 screening of NI draft AI Strategy (example of AI equality screening)

[16986] Northern Ireland . Practice, Current

[16988] The Executive Office screened its AI strategy out of a full equality impact assessment, with mitigation. It identified digital exclusion, algorithmic bias, accessibility, public trust across community groups, privacy and dependants as risks. It commits to project-level screening or EQIAs as AI initiatives develop, which is a template for NI bodies screening AI projects.

[16989] The Executive Office (NI)

[16990] S75 screening - AI Strategy consultation (opens an external website)

[16994] Human Rights Act 1998

[16995] UK-wide . Law, In force

[16997] It is unlawful for public authorities to act incompatibly with Convention rights. This includes rights to privacy (Article 8), non-discrimination (Article 14) and a fair hearing (Article 6), so AI used in surveillance, profiling or decisions about people must be necessary, proportionate and non-discriminatory. Organisations carrying out public functions under contract may also be covered. Caveat: No AI-specific guidance from the human rights commissions was found in this check. A Scottish Human Rights Bill was paused in the 2021-26 session.

[16999] Ministry of Justice; Scottish Human Rights Commission, NI Human Rights Commission and EHRC promote compliance

[17000] Human Rights Act 1998 (opens an external website)

[17004] UNCRC (Incorporation) (Scotland) Act 2024 - section 6 duty

[17005] Scotland . Law, In force

[17007] It is unlawful for Scottish public authorities, including contractors carrying out functions of a public nature, to act incompatibly with the UNCRC requirements when exercising relevant devolved functions. AI tools that affect children, such as triage, risk scoring and education tools, must be assessed for compatibility with children's rights. Statutory guidance supports the duty. Caveat: Section 6 has been in force since 16 July 2024. legislation.gov.uk flags unapplied amendments to s.6 by a 2026 asp; check the current wording. Statutory guidance (Part 2) was published 13 September 2024.

[17009] Scottish Government; Children and Young People's Commissioner Scotland

[17010] UNCRC (Incorporation) (Scotland) Act 2024, section 6 (opens an external website)

[17014] Rights of Children and Young Persons (Wales) Measure 2011

[17015] Wales . Law, In force

[17017] Welsh Ministers must have due regard to the UNCRC when exercising their functions. Welsh Government policy that uses or promotes AI affecting children should therefore consider children's rights, usually through a Children's Rights Impact Assessment. Caveat: The duty applies to Welsh Ministers, not all Welsh public bodies. The CRIA mechanism and the date of Royal Approval were not re-verified in this check.

[17019] Welsh Government

[17020] Rights of Children and Young Persons (Wales) Measure 2011 (opens an external website)

[17024] Well-being of Future Generations (Wales) Act 2015

[17025] Wales . Law, In force

[17027] Listed Welsh public bodies must apply the sustainable development principle: long term, prevention, integration, collaboration and involvement. AI adoption decisions should therefore weigh long-term effects on people, jobs and the environment, and involve the people affected. Senedd Research describes it as the most direct lever Wales has over AI, because data protection and IP are reserved. Caveat: Senedd Research's characterisation is reported through a secondary source (Resultsense, Sept 2026). No Commissioner guidance specific to AI was found.

[17029] Welsh Government; Future Generations Commissioner for Wales

[17030] Well-being of Future Generations (Wales) Act 2015 (opens an external website)

## FinOps and cost control (8) [17033]

[17038] Obligation

[17039] Where, kind and status

[17040] What it means for AI use

[17041] Owner

[17042] Basis

[17045] FinOps Framework (2026 edition)

[17046] UK-wide . Framework, Current

[17048] The industry-standard model for running technology spend as a shared business discipline: Inform, Optimize and Operate phases across four domains (understand usage and cost; quantify business value; optimise usage and cost; manage the practice). The 2026 edition treats AI as its own technology category ('Scope') alongside public cloud, SaaS, licences and data centres. Use it to structure who owns allocation, budgeting, forecasting, unit economics, anomaly management and chargeback for AI tools. Caveat: Industry body guidance, not UK government policy. Page shows no single 'last updated' date; 2026 updates dated 20 March and 3 April 2026.

[17050] FinOps Foundation (Linux Foundation)

[17051] FinOps Framework (opens an external website)

[17055] FinOps for AI: overview guidance

[17056] UK-wide . Guidance, Current

[17058] Tells you which AI cost measures to track (cost per inference, per token, per API call, time to value), to tag AI resources by project, team and cost centre and to separate training from inference costs. It recommends bottom-up budgets revised more often than for ordinary cloud, alerts when token or GPU use jumps, and matching the model to the task instead of defaulting to the most capable (and most expensive) model. Provisioned or reserved AI capacity (for example Azure PTUs) suits only predictable workloads; unused blocks are wasted money. Caveat: Original publication date not shown; 17 Feb 2026 is the 'last updated' date. Vendor-neutral but written for commercial cloud buyers, not government budgeting rules. Further 2026 papers (tokenomics, correlating AI spend with outcomes, agentic budget risk) are on https://www.finops.org/topic/ai-value/ but were not read in full.

[17060] FinOps Foundation (Linux Foundation)

[17061] FinOps for AI Overview (opens an external website)

[17065] FOCUS 1.4 – FinOps Open Cost and Usage Specification

[17066] UK-wide . Standard, Current

[17068] FOCUS is an open specification that normalises bills from cloud, SaaS and other providers into one schema so spend can be compared, allocated and charged back. Version 1.4 is the latest; the 1.x line supports prices in non-monetary units such as credits or tokens, commitment and capacity-reservation columns, split-cost allocation (1.3) and contract-commitment linking (1.3). Ask AI and cloud suppliers for FOCUS-conformant billing exports so AI credits can be reconciled with the rest of the estate. Caveat: Release date (GA at FinOps X, 11 June 2026) comes from a trade press report, not the spec itself. Native AI-token columns are reported as planned for FOCUS 1.5 (likely 2027) – unconfirmed.

[17070] FinOps Foundation (Linux Foundation) FOCUS project

[17071] FOCUS Specification v1.4 (opens an external website)

[17075] Managing your spending in the cloud

[17076] UK-wide . Guidance, Current

[17078] Government's own cloud cost guidance: a central cloud operations team should set and enforce a tagging policy so spend can be charged back to teams and cost centres; set spend alerts to avoid 'bill shock'; budget flexibly with finance early; and use reserved or committed capacity only for stable, continuously running workloads. The same rules apply directly to AI model hosting and token consumption. Caveat: Last updated 15 July 2021; predates generative AI and does not mention tokens, credits or AI gateways.

[17080] Government Digital Service (now in DCMS)

[17081] Managing your spending in the cloud (opens an external website)

[17085] Cloud guide for the public sector

[17086] UK-wide . Guidance, Current

[17088] Sets the baseline for buying and running cloud, which is how most AI is consumed: budget flexibly, monitor spend, design for the cloud cost model, keep ownership of IP and access to data held by suppliers, and use pan-government MoUs with cloud providers for better prices. It defines lock-in and asks you to balance its benefits and risks, pointing to separate guidance on managing technical lock-in. Caveat: Last visible update 29 November 2023. Does not cover committed-spend arrangements or AI. Links to Crown Commercial Service, now Government Commercial Agency.

[17090] Government Digital Service (now in DCMS)

[17091] Cloud guide for the public sector (opens an external website)

[17095] Microsoft Copilot Credits: monthly expiry and 125% enforcement

[17096] UK-wide . Supplier fact, Current

[17098] Copilot Studio prepaid capacity is enforced monthly and unused Copilot Credits do not carry over – they reset on the first of the month. If tenant consumption reaches 125% of prepaid capacity, custom agents are disabled until capacity is added; linking a pay-as-you-go Azure billing plan avoids the block but bills overage automatically. Admins can allocate credits per environment and set monthly per-agent consumption limits in the Power Platform admin center – do this before go-live. Caveat: Supplier documentation changes often; date is the check date, not a publication date. Usage by Microsoft 365 Copilot licensed users of many agent features is not billed in credits.

[17100] Microsoft (supplier)

[17101] Copilot Studio billing and licensing; Billing rates and management (opens an external website)

[17105] Copilot Studio UK list prices and credit rates

[17106] UK-wide . Supplier fact, Current

[17108] UK list price for a Copilot Studio capacity pack is £153.80 per pack per month for 25,000 Copilot Credits (ex VAT, paid up front); Microsoft 365 Copilot is listed from £23.10 per user per month (annual). Credits are consumed at different rates per feature – e.g. 1 credit for a classic answer, 2 for a generative answer, 5 for an agent action, 10 for tenant-graph grounding, and 10 credits per 1,000 tokens for premium AI tools – so one conversation can cost many credits. Model your agent's credit burn (Microsoft provides an estimator) before choosing packs, pay-as-you-go or a pre-purchase plan. Caveat: List prices only; government prices under the Microsoft SPA24 MoU may differ and were not published. Microsoft's own example assumes a $0.01 pay-as-you-go credit rate; UK PAYG rate not confirmed on the UK page.

[17110] Microsoft (supplier)

[17111] Copilot Studio pricing (UK) (opens an external website)

[17115] AI gateways for token quotas, metering and chargeback

[17116] UK-wide . Practice, Current

[17118] Putting an AI gateway in front of model endpoints lets you enforce tokens-per-minute limits and daily or monthly token quotas per team or application, emit token-usage metrics with custom dimensions for showback and chargeback, cache semantically similar answers to cut repeat calls, and route traffic to prepaid capacity first with pay-as-you-go as overflow. Azure API Management is one documented example; equivalent controls exist in other gateways. Caveat: Supplier-specific example; capability availability varies by service tier. Not a government mandate – presented as good practice.

[17120] Microsoft (supplier documentation, used as an example)

[17121] AI gateway in Azure API Management (opens an external website)

## Financial controls and business cases (9) [17124]

[17129] Obligation

[17130] Where, kind and status

[17131] What it means for AI use

[17132] Owner

[17133] Basis

[17136] Managing Public Money (HM Treasury)

[17137] UK-wide . Guidance, In force

[17139] The rules accounting officers must follow for regularity, propriety, value for money and feasibility. A revised edition (DAO 02/25, June 2025) applies to all central government bodies, with new material on accounting officer duties and use of models; in April 2026 guidance on interpreting 'Novel, Contentious and Repercussive' (NCR) and delegated-authority guidance were added. AI spend that is novel for your organisation may need HM Treasury approval even below your delegated limit. Caveat: Applies to UK government departments and their ALBs; devolved administrations have their own equivalents. Latest page entry (13 August 2026) added an ALB template and updated delegated-authority letter template.

[17141] HM Treasury

[17142] Managing public money (opens an external website)

[17146] Digital Assurance Playbook (replaces GDS digital and technology spend controls)

[17147] UK-wide . Policy, Current

[17149] From 1 April 2026 GDS digital and technology spend controls (v6: £100k public-facing, £1m other) were withdrawn. Departments now own their own assurance, must record digital and technology initiatives over £5m whole-life cost (any spend for cryptographic products) on a pipeline monitored by HM Treasury, and need central approval only above their Treasury-set Delegated Authority Limit or for Novel, Contentious or Repercussive work. AI initiatives should follow the AI Playbook and the Algorithmic Transparency Recording Standard, and AI new to an organisation may be treated as Novel. Caveat: Most other Cabinet Office spend controls also ceased on 1 April 2026 (advertising, marketing and communications control retained), following HM Treasury's Office for Value for Money controls review (Budget, 26 Nov 2025). Departmental Delegated Authority Limits were not published at the time of checking. Publisher shown as DCMS and DSIT; DSIT has since been abolished (21 July 2026).

[17151] Government Digital Service (DCMS) with HM Treasury

[17152] Digital Assurance Playbook (opens an external website)

[17156] The Green Book (2026 edition)

[17157] UK-wide . Guidance, Current

[17159] HM Treasury's appraisal guidance for any spending proposal, including AI. The 2026 edition is much shorter and says a single benefit-cost ratio is not enough: decision makers must weigh monetised and unmonetised costs, benefits and risks, and a BCR below one does not automatically mean poor value. AI business cases should show the full range of costs (licences, credits, compute, assurance, skills) against realistic, evidenced benefits. Caveat: No AI-specific content. Proportionality guidance on business case detail was still an outstanding commitment at 30 June 2026.

[17161] HM Treasury

[17162] The Green Book: appraisal and evaluation in central government (opens an external website)

[17166] Guidance on developing business cases (Five Case Model, consolidated 2026)

[17167] UK-wide . Guidance, Current

[17169] The single HM Treasury guide to the Five Case Model (strategic, economic, commercial, financial, management) for projects and programmes, consolidated in June 2026. Use it for any AI investment that needs a business case; the AI Playbook notes investments approaching £10m typically need a five-case business case. Caveat: The £10m rule of thumb is from the AI Playbook (Feb 2025), which also quotes the now-withdrawn £100k spend control threshold.

[17171] HM Treasury

[17172] Guidance on developing business cases (opens an external website)

[17176] Accounting for SaaS/cloud configuration costs (capital vs resource)

[17177] UK-wide . Guidance, Current

[17179] Whether money spent setting up an AI or cloud service can be capitalised depends on whether you control an intangible asset under IAS 38. The IFRS Interpretations Committee's March 2021 agenda decision on configuration and customisation costs in SaaS arrangements applies; HM Treasury's Financial Reporting Advisory Board proposed no public-sector adaptation in the FReM. Most subscription AI (licences, credits, tokens) is therefore likely to score as resource spending – agree treatment with your finance team before the business case. Caveat: The 'likely resource' conclusion is an inference, not a Treasury statement. No 2025-26 HM Treasury guidance specific to AI capitalisation was found.

[17181] HM Treasury (Financial Reporting Advisory Board)

[17182] FRAB 144(13): IFRS Interpretations Committee summary of announcements (opens an external website)

[17186] Scottish Public Finance Manual: Digital Portfolio in major investments

[17187] Scotland . Guidance, Current

[17189] The Scottish Public Finance Manual is the Scottish equivalent of Managing Public Money. Finance Guidance Note 2025/04 added a Digital Portfolio section to major investment projects, setting a mandated portfolio approach for relevant public bodies' digital investment, linked to the Digital Scotland Service Manual and a Digital Portfolio Board. Scottish bodies planning significant AI investment should check whether it falls into the Digital Portfolio. Caveat: Inclusion thresholds were not stated on the guidance note page. No AI-specific provisions.

[17191] Scottish Government

[17192] FGN 2025/04: SPFM amendment – Digital Portfolio added to major investments (opens an external website)

[17196] Managing Welsh Public Money

[17197] Wales . Guidance, Current

[17199] The Welsh Government's framework for handling public funds, applying to the Welsh Government, its sponsored bodies, NHS Wales and others. Welsh bodies buying or budgeting for AI follow this rather than HM Treasury's Managing Public Money. Caveat: Dated 2018 with no visible later update; no AI-specific content.

[17201] Welsh Government

[17202] Managing Welsh public money (opens an external website)

[17206] Managing Public Money Northern Ireland (MPMNI)

[17207] Northern Ireland . Guidance, Current

[17209] Department of Finance guidance on the proper handling of public money across the NI public sector – the NI equivalent of Managing Public Money. Anyone committing NI public funds to AI tools must follow it. Caveat: Page metadata shows last update 12 August 2024. No AI-specific content.

[17211] Department of Finance (Northern Ireland)

[17212] Managing Public Money NI (MPMNI) (opens an external website)

[17216] Better Business Cases NI

[17217] Northern Ireland . Guidance, Current

[17219] The primary NI guidance on developing and reviewing business cases, based on the Five Case Model and HM Treasury business case guidance with NI supplements. It superseded the NI Guide to Expenditure Appraisal and Evaluation (NIGEAE) from 2 November 2020 and applies, proportionately, to every proposal that spends or saves public money – including AI. Caveat: Has not yet been checked against the June 2026 consolidated HM Treasury business case guide.

[17221] Department of Finance (Northern Ireland)

[17222] Better Business Cases NI (opens an external website)

## Language and accessibility (5) [17225]

[17230] Obligation

[17231] Where, kind and status

[17232] What it means for AI use

[17233] Owner

[17234] Basis

[17237] Welsh Language (Wales) Measure 2011 and Welsh Language Standards

[17238] Wales . Law, In force

[17240] Bodies subject to Welsh Language Standards must provide services in Welsh, cover policy-making, operations and record-keeping, and treat Welsh no less favourably than English. This applies whether a service is delivered by people or by AI, including chatbots, voice systems, automated replies and staff-facing tools such as training and HR systems. Caveat: Which standards apply depends on each body's compliance notice. UK Government departments generally operate Welsh Language Schemes under the Welsh Language Act 1993 instead; check which regime applies to your body.

[17242] Welsh Government; regulated by the Welsh Language Commissioner

[17243] Welsh Language (Wales) Measure 2011 (opens an external website)

[17247] Welsh Language Commissioner: AI and the Welsh language - regulatory policy statement

[17248] Wales . Guidance, Current

[17250] The Commissioner says using AI does not excuse failing to meet Welsh language duties. Test AI systems in Welsh before deployment, and do not publish machine-translated documents or official communications without review by a competent Welsh speaker. Chatbots and voice systems must give an equivalent Welsh service, and AI-delivered training, recruitment and performance tools must not disadvantage Welsh speakers. The Commissioner will run periodic audits. Caveat: Publication date inferred from the PDF filename (20250722); the page shows no date.

[17252] Welsh Language Commissioner

[17253] Artificial Intelligence and the Welsh language: the Welsh Language Commissioner's Regulatory Policy Statement (opens an external website)

[17257] Gaelic Language (Scotland) Act 2005 as amended by the Scottish Languages Act 2025

[17258] Scotland . Law, Partly commenced

[17260] Scottish public authorities with Gaelic language plans must deliver the measures in their plans, which can include digital and automated services. The 2025 Act lets Ministers set Gaelic standards by regulation, adds areas of linguistic significance and requires annual reporting. Bodies with plans should consider Gaelic provision when introducing AI-delivered services such as chatbots and translation. Caveat: The Act is being commenced in stages: areas of linguistic significance from 21 March 2026 (Eilean Siar), 1 September 2026 (Highland, Argyll and Bute) and 1 January 2027 (all other areas). Gaelic standards regulations had not been confirmed as made by 19 Oct 2026. No Bòrd guidance specific to AI was found.

[17262] Scottish Government; Bòrd na Gàidhlig

[17263] Scottish Languages Act 2025, Part 1; Commencement No. 2 Regulations 2026 (SSI 2026/128) (opens an external website)

[17267] Identity and Language (Northern Ireland) Act 2022 - Irish language and Ulster Scots commissioners

[17268] Northern Ireland . Law, Partly commenced

[17270] The Act created an Irish Language Commissioner, who can set best-practice standards for public authorities and investigate complaints, and a Commissioner for Ulster Scots and the Ulster British tradition. The first commissioners took up post on 13 November 2025. NI public authorities should expect standards that may cover digital and AI-delivered services, but none were confirmed as of October 2026. Caveat: No standards or AI-specific guidance from either commissioner found as of 19 Oct 2026. TEO page last updated 19 August 2026.

[17272] The Executive Office (NI); Office of Identity and Cultural Expression

[17273] Identity and language (TEO) (opens an external website)

[17277] Public Sector Bodies (Websites and Mobile Applications) Accessibility Regulations 2018 - WCAG 2.2 AA

[17278] UK-wide . Regulation, In force

[17280] Public sector websites and apps, including AI chatbots and AI-generated content published on them, must meet WCAG 2.2 level AA and publish an accessibility statement. GDS monitors compliance. Enforcement is by the EHRC in Great Britain and the Equality Commission for Northern Ireland. Caveat: The Regulations are a UK SI; the monitoring page names enforcers for all four nations but does not state the extent explicitly. Applying them to AI chatbots is inferred from the scope of websites and apps.

[17282] Government Digital Service (monitoring, now in DCMS); EHRC and ECNI (enforcement)

[17283] Public sector website and mobile application accessibility monitoring (opens an external website)

## Local government and wider public sector (8) [17286]

[17291] Obligation

[17292] Where, kind and status

[17293] What it means for AI use

[17294] Owner

[17295] Basis

[17298] LGA Artificial Intelligence Hub

[17299] England . Guidance, Current

[17301] Resources for English councils: a playbook for agentic AI in local government (October 2026), 'AI in Local Government: What Councillors Need to Know' (September 2026), a Responsibly buying AI procurement guide, a case study bank and a 1,000+ member AI Community of Practice. A Local Government AI Playbook and AI governance templates are planned for 2026/27. Caveat: Hub page; individual resource dates as listed on it.

[17303] Local Government Association

[17304] Artificial Intelligence Hub (opens an external website)

[17308] MHCLG Local AI team and responsible AI adoption programme for councils

[17309] England . Practice, Current

[17311] MHCLG's Local AI team builds reusable AI tools for councils, such as a transcription tool based on i.AI's Minute. It funds the LGA to co-deliver an AI maturity playbook, standard assessment templates that combine data protection and equality checks, a minimum standard for responsible AI and an AI policy template. Caveat: Products (playbook, templates, minimum standard) were in development at July 2026. Scope is English councils (MHCLG remit) but not stated explicitly.

[17313] Ministry of Housing, Communities and Local Government

[17314] From engagement to delivery: supporting responsible AI adoption in councils (opens an external website)

[17318] Interim Guidance on the use of AI in Health and Social Care (Scotland) - with COSLA and Digital Office

[17319] Scotland . Guidance, Current

[17321] Joint Scottish Government, COSLA and Digital Office guidance to NHS boards, councils and Health and Social Care Partnerships. It asks for an AI oversight group, Data Ethics Boards in local authorities, early trade union engagement, human oversight of decisions affecting people, and lifecycle risk management. Staff remain accountable for AI-assisted work, and organisations remain accountable for AI scribes. Caveat: Interim, ahead of a full AI Policy Framework. Copy retrieved from an NHS Highland-hosted site, not gov.scot. No standalone COSLA AI guidance for all council services was found.

[17323] Scottish Government (DG Health and Social Care), COSLA, Digital Office for Scottish Local Government

[17324] Interim Guidance on the use of AI in Health and Social Care (letter, 17 Aug 2026) (opens an external website)

[17328] WLGA and Welsh local government AI

[17329] Wales . Practice, Unconfirmed

[17331] WLGA sits on the Welsh Government's Strategic AI Advisory Group, and the Welsh Government has funded guidance for local authorities on deploying AI. Welsh councils also follow the Workforce Partnership Council AI guidance, Welsh Language Standards and the Socio-economic Duty when adopting AI. Caveat: No WLGA-published AI guidance was found. Publication of the funded local authority guidance is unconfirmed.

[17333] Welsh Local Government Association; Welsh Government

[17334] Strategic AI Advisory Group meeting: 24 November 2025 (opens an external website)

[17338] NILGA AI resources for councillors (Northern Ireland)

[17339] Northern Ireland . Guidance, Current

[17341] NILGA provides Copilot for Councillors training (briefing and webinar) on responsible use of Microsoft Copilot and points councillors to the LGA AI Unpacked videos. No NI-wide AI policy framework for councils was found. Caveat: Date inferred from file names (late January 2026), not stated on the page.

[17343] Northern Ireland Local Government Association

[17344] Digital Councillor (NILGA) (opens an external website)

[17348] NHS England guidance on AI-enabled ambient scribing products

[17349] England . Guidance, Current

[17351] NHS organisations in England adopting AI scribes should follow this guidance, which has separate summaries for boards, CIOs and CCIOs and technical teams, and the companion information governance guidance (March 2026). It covers medical device status, clinical safety and data protection. Caveat: Latest component (CIO/CCIO summary v3) dated 29 July 2026. NHS England is being merged into DHSC; ownership may change.

[17353] NHS England

[17354] Guidance on the use of AI-enabled ambient scribing products in health and care settings (opens an external website)

[17358] NHS Wales: safe and responsible adoption of ambient voice technologies (WHC/2025/026)

[17359] Wales . Guidance, Current

[17361] A Welsh Health Circular telling NHS Wales bodies how to adopt AI scribes safely and responsibly in clinical settings. NHS Wales staff and digital teams should follow it before piloting or buying ambient voice tools. Caveat: Detailed requirements were not read in this check.

[17363] Welsh Government (Health and Social Care)

[17364] The safe and responsible adoption of ambient voice technologies (AI scribes) in clinical settings (WHC/2025/026) (opens an external website)

[17368] HSC Artificial Intelligence Framework (Northern Ireland)

[17369] Northern Ireland . Framework, Current

[17371] A shared, practical starting point for HSC organisations in Northern Ireland to use AI safely, ethically and responsibly. It promotes safety, transparency, fairness and human oversight. It is described as a living document, not a policy or strategy. Caveat: Issue date taken from the PDF filename (FINAL 280126); page last updated 2 April 2026.

[17373] Digital Health and Care Northern Ireland (DHCNI)

[17374] HSC AI Framework (opens an external website)

## National AI strategy and governance (10) [17377]

[17382] Obligation

[17383] Where, kind and status

[17384] What it means for AI use

[17385] Owner

[17386] Basis

[17389] Machinery of government change: DSIT abolished, AI policy moved to Cabinet Office

[17390] UK-wide . Policy, Current

[17392] From 21 July 2026, AI strategy, public sector AI adoption and the AI Security Institute moved to the Cabinet Office. A new AI Taskforce sits in the Office for the Prime Minister and the Cabinet. GDS moved to an expanded DCMS, and science and innovation went to the renamed Department for Business, Innovation, Science and Trade (BIST). Check that documents citing DSIT ownership still have a current owner. Caveat: The fact sheet does not say where i.AI, data policy, ATRS or the Responsible Technology Adoption Unit now sit. The acronym was changed from DBIST to BIST on 27 July 2026.

[17394] Cabinet Office / Office for the Prime Minister and the Cabinet

[17395] Machinery of government changes: fact sheet (opens an external website)

[17399] AI Opportunities Action Plan (and One Year On report)

[17400] UK-wide . Strategy, Current

[17402] The UK's 50-recommendation plan (January 2025) to grow AI capability and drive adoption, including across the public sector. The January 2026 progress report says 38 of the 50 commitments have been met. Public sector AI adoption under the plan is now led by the Cabinet Office. Caveat: Original plan published 13 Jan 2025; the One Year On report 29 Jan 2026. Public-sector-specific recommendations were not re-read in this check.

[17404] Published by DSIT (abolished); now Cabinet Office for AI strategy

[17405] AI Opportunities Action Plan: One Year On (opens an external website)

[17409] AI Security Institute

[17410] UK-wide . Practice, Current

[17412] The government body that researches the risks of advanced AI and develops and tests mitigations. Since 21 July 2026 it sits with the Cabinet Office. Its work informs security expectations for frontier models that departments may use; it does not regulate departmental AI use. Caveat: The gov.uk organisation page did not yet name a parent department when checked. The 2025 rename date (from AI Safety Institute) was not re-verified.

[17414] Cabinet Office

[17415] AI Security Institute - About (gov.uk); Machinery of government changes: fact sheet (opens an external website)

[17419] Incubator for Artificial Intelligence (i.AI) - part of GDS

[17420] UK-wide . Practice, Unconfirmed

[17422] i.AI builds shared AI tools for government, such as the Humphrey suite and Minute, which MHCLG is adapting for councils. It became part of GDS in January 2025. Use i.AI tools through your organisation's approved routes. Caveat: Whether i.AI stayed with GDS in DCMS or moved to the Cabinet Office AI function after July 2026 is not confirmed by any source found.

[17424] Government Digital Service (now in DCMS) - post-July 2026 home unconfirmed

[17425] Incubator for Artificial Intelligence (gov.uk organisation page) (opens an external website)

[17429] Scotland's AI Strategy 2026-2031

[17430] Scotland . Strategy, Current

[17432] Scotland's five-year AI strategy is principles-based, follows the OECD AI Principles and rests on Fair Work. It is delivered through the AI Scotland programme, with ten actions due by March 2027, including embedding ethical AI frameworks in health and social care. It replaces the 2021 strategy delivered through the Scottish AI Alliance. Caveat: Published before the May 2026 Scottish Parliament election; how the new government is delivering it after the election has not been confirmed.

[17434] Scottish Government (Economic Development Directorate)

[17435] Scotland's Artificial Intelligence strategy 2026-2031 (opens an external website)

[17439] Scotland Digital Strategy delivery plan 2025-2028: ethical AI framework and public sector AI actions

[17440] Scotland . Strategy, Current

[17442] Commits the Scottish Government to an ethical AI framework in 2026, offering a library of approved frameworks plus a policy statement on ethical public sector AI use. It also commits to AI pilots in operations, a public sector working group on AI adoption and ethics, and, for local government, a national AI governance framework, Technical Assurance Group and national AI registry by 2028. Caveat: Publication of the ethical AI framework (due 2026) not confirmed by 19 Oct 2026.

[17444] Scottish Government and Digital Office for Scottish Local Government

[17445] Digital strategy for Scotland: sustainable digital public services - delivery plan 2025-2028 (opens an external website)

[17449] Scottish AI Playbook (Scottish AI Alliance)

[17450] Scotland . Guidance, Current

[17452] An open, plain-language guide from the Scottish AI Alliance for organisations starting with AI. It covers strategy, procurement and governance, and is supported by a practitioner community, workshops and case studies. Use it alongside Scottish Government and UK guidance. Caveat: Described via a Data Lab case study; the playbook site was not fetched. Its upkeep after the 2021 strategy ended in 2026 is unconfirmed.

[17454] Scottish AI Alliance / The Data Lab

[17455] Scottish AI Alliance: leading Scotland's AI strategy (case study) (opens an external website)

[17459] AI Cymru: AI Plan for Wales

[17460] Wales . Strategy, Current

[17462] The Welsh Government's AI plan includes quick wins to roll out AI training across the Welsh public sector, improve Welsh-language speech and language technology, and deliver services in English and Welsh. It is supported by a new Office for AI and a Strategic AI Advisory Group whose members include WLGA and Wales TUC. Caveat: Detailed commitments are taken from UKAuthority's report (20 Nov 2025), as the gov.wales landing page does not list them.

[17464] Welsh Government (Office for AI)

[17465] AI plan for Wales (opens an external website)

[17469] Written Statement: AI and digital transformation in Welsh public services

[17470] Wales . Policy, Current

[17472] The Welsh Government set up an Office for AI and a Strategic AI Advisory Group, funded guidance for local authorities and others on deploying AI, funded AI training for public sector workers and an evaluation of AI scribes, and is building a platform for testing AI tools. It also confirmed that CDPS functions are being brought into the Welsh Government. Caveat: Whether the CDPS integration was completed by April 2026 is unconfirmed.

[17474] Welsh Government

[17475] Written Statement: Artificial Intelligence and digital transformation in Welsh public services (opens an external website)

[17479] Northern Ireland draft Artificial Intelligence Strategy

[17480] Northern Ireland . Strategy, Consultation

[17482] The Executive Office's draft strategy for responsible AI adoption across the NI public sector proposes eight principles: human oversight, accountability and redress, data governance, technical safety and security, fairness and transparency, sustainability, societal benefit, and training and literacy. Consultation runs from 12 August to 4 November 2026. Caveat: Draft only; the final strategy may change.

[17484] The Executive Office (NI) - Office of AI & Digital

[17485] Northern Ireland's Draft Artificial Intelligence Strategy - consultation (opens an external website)

## Procurement and commercial (16) [17488]

[17493] Obligation

[17494] Where, kind and status

[17495] What it means for AI use

[17496] Owner

[17497] Basis

[17500] Procurement Act 2023

[17501] England, Wales, Northern Ireland . Law, In force

[17503] The public procurement regime for procurements started on or after 24 February 2025 by contracting authorities in England, Wales and Northern Ireland, with the Procurement Regulations 2024. It changes notices, transparency, exclusions and contract management for every AI purchase above threshold. It applies to devolved Welsh and transferred NI authorities with some differences, but generally not to devolved Scottish authorities, which stay under Scottish law. Caveat: Procurement is devolved; this UK Act applies to reserved, Welsh and NI authorities by agreement, so reserved_or_devolved is n/a. Royal Assent date from general knowledge, not re-checked today. The NI Department of Finance PPN page lists no Act-specific PPNs (checked 19 Oct 2026).

[17505] Cabinet Office (Government Commercial Function)

[17506] Procurement Act 2023 (opens an external website)

[17510] Procurement Act guidance: devolved contracting authorities

[17511] Wales, Northern Ireland, Scotland . Guidance, Current

[17513] Explains which parts of the Procurement Act apply in each nation. Devolved Welsh authorities follow the Wales Procurement Policy Statement instead of the National Procurement Policy Statement (in force 24 February 2025, which other covered authorities must 'have regard to'). Transferred NI authorities are exempt from the NPPS except under reserved arrangements. Devolved Scottish authorities generally follow Scottish law unless buying jointly with, or through a framework of, a UK, Welsh or NI authority. Caveat: Last updated 15 April 2026.

[17515] Cabinet Office (Government Commercial Function)

[17516] Guidance: Devolved Contracting Authorities (opens an external website)

[17520] Procurement Reform (Scotland) Act 2014 and cross-border regulations

[17521] Scotland . Law, In force

[17523] Devolved Scottish authorities buy AI under the Procurement Reform (Scotland) Act 2014 and Scottish procurement regulations, not the Procurement Act 2023. From 20 December 2025 the Cross-Border Public Procurement (Miscellaneous Amendment) (Scotland) Regulations 2025 largely disapply Scottish rules when a Scottish authority buys through a UK framework (for example a Government Commercial Agency agreement), so most of the Procurement Act's relevant provisions apply instead. Caveat: Commencement date and regulation title come from a law-firm summary (DWF, January 2026); the SPPN 5/2026 page text could not be read. SSI number not confirmed.

[17525] Scottish Government (Scottish Procurement)

[17526] Guidance: Devolved Contracting Authorities; Public procurement – cross-border co-operation within the UK: SPPN 5/2026 (opens an external website)

[17530] Wales: Procurement (Wales) Regulations 2024 and Social Partnership and Public Procurement (Wales) Act 2023

[17531] Wales . Law, In force

[17533] Welsh contracting authorities use the Procurement Act 2023 with the Procurement (Wales) Regulations 2024 (e.g. contract details notices above £30,000 including VAT) and must have regard to the Wales Procurement Policy Statement. Socially responsible procurement duties under the Social Partnership and Public Procurement (Wales) Act 2023 commenced in stages, including provisions from 21 March 2025. When Welsh bodies call off UK frameworks (e.g. Government Commercial Agency), UK rules apply to that call-off. Caveat: There is no 'Procurement (Wales) Act 2024'. The 2024 Welsh Act is the Health Service Procurement (Wales) Act 2024, which lets Welsh Ministers disapply the Procurement Act for NHS Wales health services.

[17535] Welsh Government

[17536] WPPN 018: Publication of contract details notices for call-offs under legacy arrangements (opens an external website)

[17540] PPN 017: Improving transparency of AI use in procurement

[17541] UK-wide . Policy, Current

[17543] For procurements started on or after 24 February 2025, central government departments, agencies and NDPBs should consider asking suppliers to disclose AI use in bids (non-scored questions), carry out proportionate due diligence on AI-written tenders, stop suppliers using confidential or non-public authority data to train AI, and plan for longer timelines. Where AI might be used to deliver a 'non-AI' service, consider requiring suppliers to declare it and set contract terms on use of data such as meeting transcripts. PPN 02/24 still applies to procurements started before that date. Caveat: Other public bodies 'may' apply it. Does not address devolved application. PPN 02/24 page (25 March 2024) has a 9 Sept 2026 metadata update with no visible change.

[17545] Cabinet Office (Government Commercial Function)

[17546] PPN 017: Improving transparency of AI use in procurement (opens an external website)

[17550] PPN 002: Social Value Model

[17551] UK-wide . Policy, In force

[17553] From 1 October 2025, central government departments, agencies and NDPBs must give social value at least 10% of the total score in procurements under the Procurement Act (with listed exclusions). Outcomes are organised around government missions, including Outcome 4 'sustainable procurement' – a natural home for AI energy and carbon commitments in AI contracts. Caveat: Does not apply below threshold, to MOD defence and security contracts or to private utilities. Wales uses its own social value / community benefits notes (e.g. WPPN 003).

[17555] Cabinet Office (Government Commercial Function)

[17556] PPN 002: Taking account of social value in the award of central government contracts (opens an external website)

[17560] G-Cloud 15 (RM1557.15)

[17561] UK-wide . Framework, Current

[17563] G-Cloud 15 replaced G-Cloud 14 from 6 August 2026 and is an open framework under the Procurement Act 2023. Lots cover IaaS/PaaS (at and above OFFICIAL), infrastructure SaaS, other SaaS and cloud support – the main route for buying AI services sold as cloud software. Call-off contracts can run up to 60 months; new suppliers can join at reopening windows. Caveat: Agreement page lists end date 5 February 2028 but describes a 4-year term – inconsistent; confirm before relying. No AI-specific lot.

[17565] Government Commercial Agency

[17566] G-Cloud 15 agreement page; 'G-Cloud relaunches with biggest upgrade in its history' (opens an external website)

[17570] Artificial Intelligence DPS (RM6200)

[17571] UK-wide . Framework, Current

[17573] The Government Commercial Agency's dynamic purchasing system for AI services – discovery, consultancy, licensing, implementation, support and end-to-end partnerships, including medical AI for health bodies. It was extended in November 2025 to 23 February 2029 while a replacement is designed; contracts can last up to 4 years. Caveat: Extension notice published 21 November 2025 (Find a Tender 2025/S 000-076043). No successor agreement named.

[17575] Government Commercial Agency

[17576] Artificial Intelligence (RM6200) (opens an external website)

[17580] Microsoft SPA24 memorandum of understanding (incl. Copilot)

[17581] UK-wide . Supplier fact, Current

[17583] A five-year MoU from 1 November 2024 replacing DTA21, giving eligible public sector bodies better pricing across Microsoft products, including Microsoft 365, Azure and Copilot. Crown Commercial Service became the Government Commercial Agency on 1 April 2026; existing agreements continue under gca.gov.uk. It is pricing, not a contract: you still need a compliant procurement route, and CCS/GCA recommends Technology Products & Associated Services 2 (RM6098, runs to 9 October 2027). Caveat: Discount levels and Copilot-specific terms are not public. Copilot inclusion confirmed by UKAuthority report (21 Oct 2024), not the GCA page.

[17585] Government Commercial Agency (formerly CCS)

[17586] Crown Commercial Service signs memorandum of understanding with Microsoft UK – SPA24 (opens an external website)

[17590] AWS One Government Value Agreement (OGVA 2.0)

[17591] UK-wide . Supplier fact, Unconfirmed

[17593] OGVA is a pan-public-sector discount MoU with Amazon Web Services; OGVA 1 (from October 2020) offered baseline discounts of up to 18%. OGVA 2.0 was renewed quietly in late 2023 as a three-year MoU, with departmental agreements starting 1 December 2023; its discounts were not published. Departments using it typically sign minimum-commit contracts, which create the same use-it-or-lose-it risk as prepaid AI capacity. Caveat: No primary government source found. Status after the three-year term (around late 2026) is unconfirmed; check with GCA.

[17595] Government Commercial Agency (formerly CCS)

[17596] UK government quietly renews public sector preferential pricing agreement with AWS (Computer Weekly) (opens an external website)

[17600] Google Cloud strategic partnership with UK government

[17601] UK-wide . Supplier fact, Unconfirmed

[17603] Announced July 2025: Google Cloud support to modernise legacy public services and help departments exit 'ball and chain' contracts, training for up to 100,000 civil servants in tech and AI by 2030, and DeepMind collaboration. Commercial terms (discounts, duration, MoU status) were not published and the announcement says arrangements 'may be subject to future commercial agreements'. Caveat: Terms unconfirmed. No Oracle pan-government agreement status was verified in this research.

[17605] Cabinet Office (AI policy; announced by DSIT, now abolished)

[17606] New Google partnership will help rid taxpayer of 'ball and chain' legacy tech (opens an external website)

[17610] Guidelines for AI procurement (Office for AI, 2020)

[17611] UK-wide . Guidance, Current

[17613] The original UK guidance on buying AI: start from the problem, run data assessments, plan for explainability, ethics and lifecycle governance, and avoid lock-in. It has not been withdrawn, but predates generative AI, the Procurement Act 2023 and PPN 017, so read it alongside the AI Playbook. Caveat: Content summary partly from general knowledge of the 2020 document; only status and dates were re-checked today.

[17615] Cabinet Office (AI policy; originally Office for AI, published by DSIT) (DSIT, abolished 21 July 2026; check the successor owner)

[17616] Guidelines for AI procurement (opens an external website)

[17620] AI Playbook for the UK Government – commercial and cost principles

[17621] UK-wide . Guidance, Current

[17623] Principle 8 says to work with commercial colleagues from the start and hold suppliers to the same responsible-AI standards, using contract terms to require transparency. The buying section asks you to budget for hidden costs and plan strategies to avoid vendor lock-in; the cost section warns AI needs ongoing investment and can carry considerable compute costs. It also tells teams to understand and manage the environmental impact of AI and choose the most sustainable option that meets the need. Caveat: Its spend-control references (mandatory assurance above £100k public-facing) are out of date since 1 April 2026.

[17625] Government Digital Service (DCMS) / Cabinet Office AI policy

[17626] Artificial Intelligence Playbook for the UK Government (opens an external website)

[17630] Technology Code of Practice

[17631] UK-wide . Standard, Current

[17633] Thirteen points for designing, building and buying technology, including be open and use open source (3), open standards (4), cloud first (5), share and reuse (8), define your purchasing strategy including contractual limitations (11) and make your technology sustainable across its lifecycle (12). Use it to test AI purchases for portability, reuse and exit. Caveat: Page still says TCoP is used for Cabinet Office spend control, which largely ended 1 April 2026; the Digital Assurance Playbook now cites it as guidance. The GOV.UK Service Standard has 14 points and none on sustainability.

[17635] Government Digital Service (DCMS)

[17636] The Technology Code of Practice (opens an external website)

[17640] Scottish Procurement Journey: Artificial Intelligence guidance

[17641] Scotland . Guidance, Current

[17643] Scottish Government guidance for buyers and bidders on AI, published on the Procurement Journey and Supplier Journey sites. Responsible AI use is permitted in procurement for both, subject to each body's policies, with proportionate steps to manage risk. Caveat: Read via the Scottish Government blog announcement; the Procurement Journey pages themselves were not read.

[17645] Scottish Government (Scottish Procurement)

[17646] Artificial Intelligence (AI) guidance – Public Procurement blog (opens an external website)

[17650] Scottish Procurement Cloud and Hosting Services framework (SP-22-023)

[17651] Scotland . Framework, Current

[17653] National framework open to all Scottish public bodies (central government, health, councils, universities, colleges and eligible third sector) for cloud and hosting, by mini-competition or direct award, from 1 November 2023 to 31 October 2027. A Scotland-specific route for hosting AI workloads. Caveat: No AI-specific Scottish national framework was found.

[17655] Scottish Government (Scottish Procurement)

[17656] Procurement – cloud and hosting services: framework SP-22-023 (opens an external website)

## Records and FOI (9) [17659]

[17664] Obligation

[17665] Where, kind and status

[17666] What it means for AI use

[17667] Owner

[17668] Basis

[17671] Freedom of Information Act 2000 — AI prompts and outputs are 'information'

[17672] England, Wales, Northern Ireland . Law, In force

[17674] FOIA covers 'information recorded in any form' held by a public authority, which includes AI prompts, outputs and chat histories held on work systems or in tools used for work. Treat AI interactions as potentially disclosable and searchable. Scottish public authorities are covered by FOISA instead; UK-wide bodies operating in Scotland remain under FOIA. Caveat: The reserved/devolved position for FOI in Wales and NI was not verified, so marked n/a. Related: ICO guidance on handling AI-generated FOI requests, 6 May 2026 (https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2026/05/new-guidance-to-support-public-authorities-dealing-with-ai-generated-foi-requests/).

[17676] Information Commission (successor to the ICO from 30 Sept 2026)

[17677] Freedom of Information Act 2000, section 84 (opens an external website)

[17681] ICO guidance: Freedom of information and artificial intelligence

[17682] England, Wales, Northern Ireland . Guidance, Current

[17684] If staff use AI for work, both the prompts and the AI-generated outputs are covered by FOIA when held. If a tool keeps conversation history, it must be searched when a request covers it. Move official information produced with AI into a corporate information management system with appropriate retention, and inaccurate AI content is not exempt just because it is wrong. Caveat: Publication date taken from page metadata. Addresses FOIA only, not EIR or private accounts specifically.

[17686] Information Commission (successor to the ICO from 30 Sept 2026)

[17687] Freedom of information (FOI) and artificial intelligence (ICO) (opens an external website)

[17691] DSIT FOI responses on ministers' ChatGPT history (2025)

[17692] UK-wide . Guidance, Current

[17694] A precedent: in 2025 DSIT treated the Secretary of State's ChatGPT history used in an official capacity as information held under FOIA and released it (FOI2025-00120); a later request was refused under section 21 only because the material was already published. Assume official use of AI tools, including by ministers, can be requested. Caveat: This is a departmental FOI response, not a regulator decision notice. No ICO decision notice on AI chat logs was found. FOI2025-00120 itself not read.

[17696] DSIT (publisher at the time; department abolished 21 July 2026)

[17697] FOI2025-00209: ChatGPT history of ministers in DSIT (opens an external website)

[17701] Freedom of Information (Scotland) Act 2002 and the Scottish Information Commissioner

[17702] Scotland . Law, In force

[17704] Scottish public authorities answer to FOISA, which also defines information as 'recorded in any form', so AI prompts and outputs held for work are in scope. Appeals go to the Scottish Information Commissioner, who reported an 83% rise in appeals, many AI-generated, and issued requester guidance plus an appeal management policy; AI guidance for public bodies is forthcoming. Caveat: Commissioner's AI-related activity is from MFMac (10 Jul 2026, grade B); itspublicknowledge.info pages were not read. No SIC guidance confirming AI prompts are held information was found.

[17706] Scottish Information Commissioner

[17707] Freedom of Information (Scotland) Act 2002, section 73 (opens an external website)

[17711] Environmental Information Regulations 2004

[17712] England, Wales, Northern Ireland . Regulation, In force

[17714] Environmental information (including policies, plans and analyses affecting the environment) recorded in any form is requestable under the EIR, not FOIA. AI-assisted analysis of environmental matters, and its prompts and outputs, may fall under the EIR. Scottish public authorities follow separate Scottish regulations. Caveat: Application to AI records is an inference from the definition; no ICO EIR-specific AI guidance was found. Scottish equivalent (EISR 2004) not read.

[17716] Information Commission (successor to the ICO from 30 Sept 2026)

[17717] Environmental Information Regulations 2004, regulation 2 (opens an external website)

[17721] Public Records Act 1958

[17722] England and Wales . Law, In force

[17724] Those responsible for public records must select records worth permanent preservation under the guidance of the Keeper (The National Archives) and transfer them, generally within 20 years. AI prompts and outputs that form part of the record of decisions should be captured in corporate systems so they can be appraised; transient AI drafts may not need keeping. Caveat: Geographic extent was not shown in the fetch; the Act covers UK government departments' records as well as English and Welsh public records. No TNA guidance specific to generative AI prompts was found.

[17726] The National Archives

[17727] Public Records Act 1958, section 3 (opens an external website)

[17731] Lord Chancellor's Code of Practice on the Management of Records (FOIA s.46)

[17732] England, Wales, Northern Ireland . Guidance, Current

[17734] Statutory code on keeping, managing and destroying records for public authorities in England, Wales and Northern Ireland. Retention schedules and information asset registers should be updated to cover AI tool logs, prompts, outputs and embeddings. Caveat: The code predates generative AI; the AI-specific sentence is a recommended application.

[17736] The National Archives

[17737] Code of Practice on the management of records issued under section 46 of the Freedom of Information Act 2000 (opens an external website)

[17741] Public Records (Scotland) Act 2011 — records management plans

[17742] Scotland . Law, In force

[17744] Named Scottish public authorities must prepare a records management plan, have it agreed by the Keeper of the Records of Scotland and manage records in line with it, covering responsibilities, security, retention, archiving and disposal. AI-generated records need to fit the agreed plan. Caveat: No National Records of Scotland guidance specific to AI found.

[17746] Keeper of the Records of Scotland (National Records of Scotland)

[17747] Public Records (Scotland) Act 2011, section 1 (opens an external website)

[17751] Public Records Act (Northern Ireland) 1923 and PRONI

[17752] Northern Ireland . Law, In force

[17754] Public records of NI courts, departments and authorities are governed by the 1923 Act and the Disposal of Documents Order 1925, which underpin disposal schedules and require a responsible records officer. PRONI receives and preserves records. AI records in NI bodies should be covered by disposal schedules. Caveat: No PRONI AI guidance found.

[17756] Public Record Office of Northern Ireland

[17757] Public Records Act (Northern Ireland) 1923 (Department of Health NI) (opens an external website)

## Regulators (7) [17760]

[17765] Obligation

[17766] Where, kind and status

[17767] What it means for AI use

[17768] Owner

[17769] Basis

[17772] UK approach to AI regulation: no general AI Act; sector regulators

[17773] UK-wide . Policy, Current

[17775] The UK has no general AI statute. Existing law (data protection, equality, human rights, consumer, online safety, sector rules) applies to AI and is enforced by existing regulators. The King's Speech of 13 May 2026 contained no new primary AI legislation, though a Regulating for Growth Bill (AI sandboxes) and a Police Reform Bill (facial recognition framework) were announced. Caveat: Secondary source. A Private Member's Bill on artificial superintelligence (Alex Sobel MP) is due for second reading on 13 November 2026 and is unlikely to progress (Lewis Silkin, Sept 2026). Bill status not checked against the Parliament website.

[17777] Cabinet Office (AI policy)

[17778] UK AI regulation: King's Speech, Crime Act and ICO converge in May (Resultsense) (opens an external website)

[17782] ICO AI and biometrics strategy and 2026/27 AI commitments

[17783] UK-wide . Policy, Current

[17785] The ICO regulates AI's use of personal data across the public and private sectors. It has committed to an AI code of practice, dedicated guidance on agentic AI and a new AI strategy with a 2026/27 workplan. Automated decision-making in public services and police facial recognition are among its priority areas. Public bodies should expect closer scrutiny of DPIAs and ADM safeguards. Caveat: Agentic AI guidance and the new AI strategy were not confirmed as published by 19 Oct 2026. The ADM and facial recognition priority areas come from secondary commentary.

[17787] Information Commissioner's Office

[17788] ICO response to government on safe AI-powered innovation (opens an external website)

[17792] EHRC: Artificial intelligence in public services

[17793] Great Britain . Guidance, Current

[17795] The equality regulator for Great Britain has published guidance on avoiding equality law breaches when public bodies use AI, and has monitored councils' AI use in England and Scotland. It enforces the PSED and the accessibility regulations in GB, so expect it to ask for evidence of equality analysis for AI systems. Caveat: Secondary report of a 2022 announcement; the outcomes of the monitoring were not retrieved.

[17797] Equality and Human Rights Commission

[17798] Watchdog to monitor how public bodies use AI, issues guidance on avoiding breaches of equality law (Local Government Lawyer) (opens an external website)

[17802] Equality Commission for Northern Ireland - Section 75 and accessibility enforcement

[17803] Northern Ireland . Practice, Current

[17805] ECNI oversees public authorities' Section 75 equality schemes and enforces the public sector accessibility regulations in Northern Ireland. No AI-specific ECNI guidance was found, so NI bodies should apply ECNI's general screening and EQIA guidance to AI projects. Caveat: Searches of equalityni.org found no AI guidance; this is recorded as a gap.

[17807] Equality Commission for Northern Ireland

[17808] Public sector website and mobile application accessibility monitoring (names ECNI as NI enforcer) (opens an external website)

[17812] CMA: Agentic AI and consumers / Complying with consumer law when using AI agents

[17813] UK-wide . Guidance, Current

[17815] Existing consumer law applies fully to AI agents. An organisation is responsible for its AI agent's breaches as it would be for an employee's, even if a third party supplies the system. Be transparent when people are dealing with an AI agent, build compliance in by design and keep human oversight. This is mainly relevant to public bodies that run trading or consumer-facing services. Caveat: Secondary summary dated 8 May 2026; the CMA's own publication date was not retrieved. How far it applies to public bodies depends on whether they act as traders.

[17817] Competition and Markets Authority

[17818] Agentic AI and consumers: CMA guidance (Cripps summary) (opens an external website)

[17822] Ofcom open letter: Online Safety Act and generative AI chatbots

[17823] UK-wide . Guidance, Current

[17825] Ofcom confirmed that generative AI chatbots and AI-generated content can fall under the Online Safety Act where users share content or where a tool searches multiple sites. Public bodies running public-facing chatbots that let users share content should check whether the Act's duties apply. Caveat: Most government chatbots are unlikely to be user-to-user services; check case by case. Online safety policy moved to DCMS in July 2026.

[17827] Ofcom

[17828] Open letter to UK online service providers regarding generative AI and chatbots (opens an external website)

[17832] Scottish Human Rights Commission - AI

[17833] Scotland . Practice, Unconfirmed

[17835] The SHRC promotes human rights compliance by Scottish public authorities. No SHRC guidance specific to AI was found. The planned Scottish Human Rights Bill, which would have strengthened duties, was not taken forward in the 2021-26 parliamentary session. Caveat: Recorded as a gap. The Human Rights Bill's status after the May 2026 election is unconfirmed.

[17837] Scottish Human Rights Commission

[17838] SHRC letter to the First Minister on the Human Rights Bill (Scottish Parliament correspondence) (opens an external website)

## Security and classification (13) [17841]

[17846] Obligation

[17847] Where, kind and status

[17848] What it means for AI use

[17849] Owner

[17850] Basis

[17853] Government Security Classifications Policy (OFFICIAL, SECRET, TOP SECRET)

[17854] UK-wide . Policy, Current

[17856] All HMG information is classified OFFICIAL, SECRET or TOP SECRET, with OFFICIAL-SENSITIVE a handling marking within OFFICIAL. AI tools must be assessed and approved by your organisation before OFFICIAL information goes into them; public consumer AI tools are not an approved route for sensitive or personal information. The policy itself does not contain AI-specific rules. Caveat: Last substantive update 5 Aug 2024 (Policy, Quick Read, Guidance 1.1 Working at OFFICIAL). The sentence on approval before use summarises departmental practice derived from the 2023 civil servant generative AI guidance, not this policy text. Devolved administrations use the classification scheme but its application to the wider public sector was not checked.

[17858] Cabinet Office (Government Security Group)

[17859] Government Security Classifications (GOV.UK collection) (opens an external website)

[17863] Guidance to civil servants on use of generative AI (2023)

[17864] UK-wide . Guidance, Withdrawn

[17866] The original rule for staff: never put sensitive information, personal data, classified material or information revealing unpublished government intent into publicly available generative AI tools, because government has no oversight of how that data is used. GOV.UK marks it superseded by the Generative AI Framework (and later the AI Playbook), but the principle still underpins departmental policies. Caveat: Status: marked 'superseded' on GOV.UK, not formally withdrawn (updated 29 Jan 2024). Kept for lineage.

[17868] Cabinet Office (AI policy since July 2026)

[17869] Guidance to civil servants on use of generative AI (opens an external website)

[17873] AI Playbook for the UK Government

[17874] UK-wide . Guidance, Current

[17876] Ten principles for using AI lawfully, securely and with human control across government, expanding the January 2024 Generative AI Framework for HMG. It covers data protection by design, security, transparency, auditability and buying AI, including asking suppliers for transparency and audit terms. It does not set explicit rules on which classification levels can go into which tools, so departmental policy fills that gap. Caveat: No explicit mention of OFFICIAL/OFFICIAL-SENSITIVE, data residency, FOI or records of prompts was found when the HTML was read (in two parts). Not checked for a 2026 revision beyond the GOV.UK page date.

[17878] Cabinet Office (AI policy, post-July 2026); published by GDS

[17879] Artificial Intelligence Playbook for the UK Government (opens an external website)

[17883] GovS 007: Security (Government Functional Standard)

[17884] UK-wide . Standard, Current

[17886] Sets the expected security governance, risk management and protective security practice for government organisations, covering physical, personnel, cyber and information security. AI deployments sit inside it: they need an accountable owner, risk assessment and assurance like any other system. Caveat: Version 2.0; no newer version found on GOV.UK. Applicability to devolved administrations not confirmed.

[17888] Cabinet Office (Government Security Group)

[17889] Government Functional Standard GovS 007: Security (v2.0) (opens an external website)

[17893] NCSC Cloud Security Principles (14)

[17894] UK-wide . Guidance, Current

[17896] Fourteen principles for assessing a cloud or SaaS service, including data in transit protection, asset protection and resilience, separation between customers, supply chain security and audit information. Use them to assess any AI service. Principle 2 asks you to understand which legislation your data is subject to, rather than requiring UK hosting. Caveat: Date is the 'reviewed' date for version 2.1.

[17898] National Cyber Security Centre

[17899] Cloud security guidance — implementing the Cloud Security Principles (v2.1) (opens an external website)

[17903] Guidelines for secure AI system development (NCSC)

[17904] UK-wide . Guidance, Current

[17906] Security practice across four lifecycle stages: secure design, development, deployment, and operation and maintenance, including threat modelling, supply chain, protecting models and logging. Teams building or integrating AI should use them alongside Secure by Design. Caveat: Version 1.0. International co-sealing partners not confirmed from the page read. Indexed with other AI security resources at https://www.security.gov.uk/policy-and-guidance/artificial-intelligence/ (updated 16 Sep 2026).

[17908] National Cyber Security Centre

[17909] Guidelines for secure AI system development (opens an external website)

[17913] Code of Practice for the Cyber Security of AI

[17914] UK-wide . Standard, Current

[17916] Thirteen baseline security principles across the AI lifecycle for developers, system operators and data custodians, with an implementation guide. It was submitted to ETSI as the basis of the international standard. Public bodies buying or building AI can use it as a supplier baseline. Caveat: Voluntary status not stated on the GOV.UK page itself. The promised update to mirror ETSI was not confirmed as published.

[17918] DCMS (listed publisher post-July 2026); originally published by DSIT (DSIT, abolished 21 July 2026; check the successor owner)

[17919] AI cyber security code of practice (GOV.UK) (opens an external website)

[17923] ETSI EN 304 223 — Baseline cyber security requirements for AI models and systems

[17924] UK-wide . Standard, Current

[17926] The European Standard built from the UK AI Cyber Security Code of Practice (previously ETSI TS 104 223, with implementation report TR 104 128). It gives an internationally recognised reference that procurement can cite when asking AI suppliers for security assurance. Caveat: EN publication in December 2025 comes from techUK (Jan 2026) and EVS listing 'EN 304 223 V2.1.1 2025'; the ETSI page itself was not read. NCSC's May 2025 blog covers the TS version.

[17928] ETSI (standard); UK input from NCSC and DSIT (now DCMS) (DSIT, abolished 21 July 2026; check the successor owner)

[17929] ETSI sets out new European standard to strengthen AI cyber security (techUK); NCSC blog on TS 104 223 (opens an external website)

[17933] NCSC Cyber Assessment Framework (CAF) v4.0

[17934] UK-wide . Framework, Current

[17936] The outcome-based framework government uses to assess critical systems (via GovAssure) and that NIS regulators use. Version 4.0 added sections on attacker methods, secure software development, stronger monitoring and threat hunting, and AI-specific cyber risks. AI services supporting critical government systems should be in scope of CAF assessment. Caveat: Release date and changes taken from Freevacy (grade B) summary of the NCSC release; the NCSC CAF page was not read directly.

[17938] National Cyber Security Centre

[17939] NCSC releases Cyber Assessment Framework v4.0 (Freevacy summary) (opens an external website)

[17943] GovAssure and the Government Cyber Action Plan

[17944] UK-wide . Framework, Current

[17946] GovAssure assesses OFFICIAL government systems, including government-sector critical national infrastructure, against the CAF. The Government Cyber Action Plan (January 2026) sets objectives for securing public services. Departments should include significant AI services in their GovAssure scope where they are critical. Caveat: Action Plan published 6 Jan 2026 by DSIT; its CAF/GovAssure/AI content was not read in full. security.gov.uk page last updated 24 Sep 2026. The 'include AI services' sentence is a recommendation, not a quotation.

[17948] Government Cyber Unit (moved to DCMS in the July 2026 machinery of government change)

[17949] GovAssure for central government departments (security.gov.uk); Government Cyber Action Plan (GOV.UK) (opens an external website)

[17953] Cyber Security and Resilience (Network and Information Systems) Bill

[17954] UK-wide . Law, Bill

[17956] Would expand the NIS Regulations (including managed service providers and data centres), tighten incident reporting (initial notice within 24 hours, full report within 72 hours) and raise penalties. It has not received Royal Assent: as of 15 October 2026 it is at Lords Report stage. AI and cloud suppliers to essential services may come into scope. Caveat: Stage inferred from the bills page (HL Bill 49, 7 Sep 2026; page updated 15 Oct 2026). Reporting deadlines from BCLP (grade B). Scottish Government lodged a Legislative Consent Memorandum on 6 Jan 2026; consent outcome not confirmed.

[17958] DCMS (inferred post-July 2026; introduced by DSIT) (DSIT, abolished 21 July 2026; check the successor owner)

[17959] Cyber Security and Resilience (Network and Information Systems) Bill — UK Parliament bills page (opens an external website)

[17963] Scottish Government staff guidance on generative AI (FOI-released)

[17964] Scotland . Guidance, Unconfirmed

[17966] Scottish Government officials were told not to put sensitive information, policy details or anything they would not share with a member of the public into generative AI tools, to avoid hypothetical questions about policy, and to fact-check outputs. Caveat: Internal guidance released via FOI; date of the guidance and whether it is current are unconfirmed.

[17968] Scottish Government

[17969] Gen AI guidance tells Scottish officials 'do not share anything you would not share with a member of the public' (PublicTechnology) (opens an external website)

[17973] NICS Use of Generative AI Policy (Northern Ireland)

[17974] Northern Ireland . Policy, Unconfirmed

[17976] The Northern Ireland Civil Service adopted a Use of Generative AI Policy in June 2024; AI use is governed through existing data protection, security and ethics processes, and in The Executive Office the SIRO approves all AI use. Caveat: Not read from niassembly.gov.uk or finance-ni.gov.uk; the policy text itself was not found publicly.

[17978] The Executive Office (NI) and NICS departments

[17979] AQW 48759/22-27 answer (reproduced by an MLA's website) (opens an external website)

## Sustainability (6) [17982]

[17987] Obligation

[17988] Where, kind and status

[17989] What it means for AI use

[17990] Owner

[17991] Basis

[17994] Greening Government Commitments 2021 to 2025

[17995] UK-wide . Policy, Current

[17997] Sets targets for central government departments and their agencies, including reporting the ICT and digital footprint and waste. The 2021-25 period has ended; HM Treasury's 2025-26 sustainability reporting guidance still aligns to its reporting requirements and refers to an 'upcoming 2025-30 commitment period'. Caveat: Marked historic on GOV.UK. The 2025-30 commitments were not found published at 19 Oct 2026 – unconfirmed. Original publication date not re-verified (page shows 15 Dec 2022 update).

[17999] Defra

[18000] Greening government commitments 2021 to 2025 (opens an external website)

[18004] Sustainability Reporting Guidance 2025-26

[18005] UK-wide . Guidance, Current

[18007] Mandatory for UK central government annual reports: departments, agencies and NDPBs report ICT and digital waste by destination and footprint by device category. Data centre emissions count as Scope 1/2 if you own or control the data centre, otherwise Scope 3, and are 'material-only' reporting – so cloud-hosted AI compute is not a minimum reporting line. Caveat: No AI-specific content; last part of the page (about 12% of text) not read.

[18009] HM Treasury

[18010] Sustainability Reporting Guidance 2025-26 (opens an external website)

[18014] Greening Government: ICT and Digital Services Strategy 2020-2025 and successor

[18015] UK-wide . Policy, Unconfirmed

[18017] The 2020-25 strategy set five ICT sustainability objectives to March 2025; the 2024-25 annual report (July 2026) says most were on track. A UK government digital sustainability strategy led by Defra is promised but not published as at the latest sources, and Government Buying Standards are to gain ICT sustainability criteria. Until then there is no government-wide target for AI energy or water use. Caveat: Successor strategy status unconfirmed; Defra digital sustainability blog (26 March 2026) described it as upcoming. Neither source mentions AI energy or water.

[18019] Defra

[18020] Greening Government Commitments ICT annual report 2024 to 2025 (opens an external website)

[18024] Using AI ethically and sustainably (draft AI Knowledge Hub guidance)

[18025] UK-wide . Guidance, Draft

[18027] Draft civil-service guidance: first ask whether AI is needed at all, then choose the smallest model that can do the job, keep prompts short and avoid unnecessary back-and-forth. This is the clearest government steer towards routing work to cheaper, lower-energy models, which also reduces cost. Caveat: Seen only via a secondary report (XenoSpectrum, 29 Sept 2026) of a page on a 'dev' domain marked draft; not verified directly. Gives no measured energy or water figures.

[18029] Cabinet Office AI policy / GDS (unconfirmed)

[18030] Using AI ethically and sustainably (draft) (opens an external website)

[18034] Climate Change (Scotland) Act 2009, s.44 public bodies duties

[18035] Scotland . Law, In force

[18037] Scottish public bodies must act in the way best calculated to help meet Scotland's emissions targets, help deliver the climate change adaptation programme, and act most sustainably. Annual reporting is required under the 2015 Order. Large AI and cloud contracts should therefore be appraised for emissions. Caveat: In force since 1 January 2011. The reporting Order (SSI 2015/347) and its later amendments were not re-checked.

[18039] Scottish Government

[18040] Climate Change (Scotland) Act 2009, section 44 (opens an external website)

[18044] Well-being of Future Generations (Wales) Act 2015

[18045] Wales . Law, In force

[18047] Named Welsh public bodies have a well-being duty (s.3) to act in line with the sustainable development principle towards the seven well-being goals (s.4). AI investment decisions, including their long-term costs and environmental impacts, should be framed against these goals. Caveat: The Welsh public sector's 2030 net zero collective ambition and Net Zero Reporting Guide were seen only through a 2022 trade article – not verified.

[18049] Welsh Government

[18050] Well-being of Future Generations (Wales) Act 2015 (opens an external website)

## Transparency and automated decisions (9) [18053]

[18058] Obligation

[18059] Where, kind and status

[18060] What it means for AI use

[18061] Owner

[18062] Basis

[18065] The Judge Over Your Shoulder (JOYS)

[18066] England and Wales . Guidance, Current

[18068] The Government Legal Department's guide to the public law principles that decision-makers must follow: legality, rationality, procedural fairness and proper consideration. These apply equally when AI or automated tools support a decision, so officials must be able to explain and justify AI-assisted decisions and must not unlawfully fetter their discretion. Caveat: The landing page does not mention automated decision-making or AI; applying JOYS to AI is an interpretation. Scotland has a separate judicial review system; extent shown reflects the English courts focus and should be checked.

[18070] Government Legal Department

[18071] The Judge Over Your Shoulder (6th edition) (opens an external website)

[18075] Algorithmic Transparency Recording Standard (ATRS) - mandatory scope

[18076] UK-wide . Standard, In force

[18078] Central government departments and arm's-length bodies that deliver public services or interact with the public must publish an ATRS record for algorithmic tools that significantly influence decisions with public effect or interact directly with the public, once the tool reaches beta, pilot or production. Retired tools need their record marked 'Retired'; FOI or data protection exemptions can justify marking fields 'EXEMPT'. Caveat: Policy, not statute. Page metadata shows an update on 9-10 September 2026 with no change note. Ownership after July 2026 not formally confirmed.

[18080] Government Digital Service (published under DSIT; GDS now in DCMS) (DSIT, abolished 21 July 2026; check the successor owner)

[18081] Algorithmic Transparency Recording Standard: mandatory scope and exemptions policy (opens an external website)

[18085] ATRS for the wider public sector (local government, devolved bodies)

[18086] UK-wide . Standard, Current

[18088] Outside central government, ATRS is recommended but not required. It is endorsed by the Data Standards Authority, and the stated intent is to extend the requirement across the broader public sector over time. Councils and other bodies can publish records voluntarily. Caveat: No date has been set for extending the requirement. The MHCLG Local AI plans of July 2026 do not mention ATRS.

[18090] Government Digital Service / Data Standards Authority

[18091] ATRS mandatory scope and exemptions policy; ATRS hub (opens an external website)

[18095] Data (Use and Access) Act 2025 - automated decision-making (section 80, UK GDPR Articles 22A-22D)

[18096] UK-wide . Law, In force

[18098] From 5 February 2026, significant decisions based solely on automated processing can rely on a wider range of lawful bases, but safeguards are mandatory. People must be told about the decision and be able to make representations, get human intervention and contest it. Decisions based on special category data are restricted. The changes do not apply to decisions taken before 5 February 2026. Caveat: Commenced by SI 2026/82 (made 29 Jan 2026). The data subject complaints provisions (s.103) commenced 19 June 2026.

[18100] Parliament; regulated by the ICO

[18101] The Data (Use and Access) Act 2025 (Commencement No. 6 and Transitional and Saving Provisions) Regulations 2026 (SI 2026/82) (opens an external website)

[18105] ICO guidance on automated decision-making and profiling (DUAA update)

[18106] UK-wide . Guidance, Consultation

[18108] Draft ICO guidance explains when processing counts as solely automated decision-making with legal or similarly significant effects, and what safeguards are needed. Meaningful human involvement means an active review by someone with the authority and competence to change the outcome, before the decision is final, and it should be recorded. Public task is likely the relevant lawful basis for public bodies. Caveat: Consultation ran 31 March to 29 May 2026; final version not confirmed as published by 19 Oct 2026. The earlier version remains in use until the update is finalised.

[18110] Information Commissioner's Office

[18111] Automated decision-making, including profiling (draft for consultation) (opens an external website)

[18115] ICO statutory code of practice on AI and automated decision-making

[18116] UK-wide . Regulation, Draft

[18118] Regulations require the Information Commissioner to prepare a statutory code of practice on processing personal data when developing and using AI and automated decision-making. Once in force, courts and the ICO must take it into account, so public bodies deploying AI should expect it to become the main data protection benchmark. Caveat: Secondary commentary (Arnold & Porter) says the Regulations came into force on 12 May 2026 and the code is not expected to take effect until 2027; the made and in-force dates were not visible on the legislation page.

[18120] Information Commissioner's Office

[18121] The Data Protection Act 2018 (Code of Practice on Artificial Intelligence and Automated Decision-Making) Regulations 2026 (SI 2026/425) (opens an external website)

[18125] Data and AI Ethics Framework and self-assessment tool

[18126] UK-wide . Framework, Current

[18128] Teams designing, building, buying or running data and AI projects in the public sector should use this framework. It has seven principles: fairness, accountability and transparency, plus privacy, environmental sustainability, societal impact and safety, added in December 2025. Its self-assessment tool records decisions and trade-offs. Caveat: Retitled from 'Data Ethics Framework' on 18 December 2025; first published 2018.

[18130] Government Digital Service (now in DCMS)

[18131] Data and AI Ethics Framework (opens an external website)

[18135] Scottish AI Register

[18136] Scotland . Register, Current

[18138] This is a public register of AI systems used or developed by the Scottish Government and the wider Scottish public sector. Registration is mandatory for the Scottish Government and its core agencies; other public bodies are encouraged to register now, with mandatory registration planned in phases. Register any qualifying system and keep its lifecycle stage up to date. Caveat: Mandatory scope comes from a March/April 2024 announcement and a Data Lab case study (2026). The Digital Strategy delivery plan (Nov 2025) refers only to 'continued use' and does not state a mandate. No date has been found for extending the requirement beyond core Scottish Government. The register website could not be fetched.

[18140] Scottish Government (developed with the Scottish AI Alliance)

[18141] Scottish AI Register (Data Ethics Guidance listing); Scottish AI Alliance 5-year case study (opens an external website)

[18145] Public Law Project - Tracking Automated Government (TAG) register

[18146] UK-wide . Register, Current

[18148] A civil-society register of automated and algorithmic tools used by UK public bodies, compiled from FOI and other sources. It is not an official record, but it shows the outside scrutiny your tool may face and can help identify comparable systems and legal challenges. Caveat: Secondary, non-official source. Launch date and current coverage not verified in this check.

[18150] Public Law Project (charity)

[18151] The Tracking Automated Government register (opens an external website)

## Value and benefits (6) [18154]

[18159] Obligation

[18160] Where, kind and status

[18161] What it means for AI use

[18162] Owner

[18163] Basis

[18166] NAO: Use of artificial intelligence in government (2024)

[18167] UK-wide . Guidance, Current

[18169] The National Audit Office found 37% of 87 responding bodies had deployed AI (typically one or two use cases) and 70% were piloting or planning it. It said the draft AI adoption strategy lacked performance metrics, an implementation plan and clear ownership, and did not set out how benefits would be measured. Expect auditors to ask for baseline and benefits evidence. Caveat: Based on a 2023 survey; adoption has moved on since.

[18171] National Audit Office

[18172] Use of artificial intelligence in government (opens an external website)

[18176] Public Accounts Committee: Use of AI in Government (HC 356)

[18177] UK-wide . Guidance, Current

[18179] The PAC's 18th report of 2024-26 (26 March 2025) followed the NAO work. Government's follow-up letter (18 November 2025) committed to consistent metrics for legacy technology costs and the cost of not acting, tracking remediation funding, and milestones and measures in the digital and AI roadmap – with deadlines moved into mid-2026. Caveat: Report conclusions not read in full; points taken from the government's November 2025 progress letter. Delivery status of the mid-2026 commitments unconfirmed.

[18181] House of Commons Public Accounts Committee

[18182] 18th Report – Use of AI in Government

[18184] NAO: Good practice guide for organisations using AI

[18185] UK-wide . Guidance, Current

[18187] The NAO warns that AI productivity promises are 'not yet borne out by real world experience' – faster individual tasks do not automatically raise throughput where approvals and governance slow work. It asks for measurable objectives, clear pilot success criteria and committed funding, and flags dependence on large external suppliers and cloud providers. Caveat: Published May 2026 (exact day not shown). No cost framework and no environmental content.

[18189] National Audit Office

[18190] Good practice guide for organisations using AI (opens an external website)

[18194] NAO: Improving government's productivity through better cost information

[18195] UK-wide . Guidance, Current

[18197] Departments know total running costs but often lack activity-level cost information, so they cannot target expensive areas or prove productivity gains. The NAO recommends named senior owners for services and simple methods to measure staff time on activities – the baseline you need to show whether AI actually reduces cost per case. In February 2026 the Comptroller and Auditor General publicly questioned whether Copilot licences were delivering gains that justified their cost. Caveat: Copilot remark reported by a trade publication (11 Feb 2026), not an NAO report finding.

[18199] National Audit Office

[18200] Improving government's productivity through better cost information (opens an external website)

[18204] Microsoft 365 Copilot experiment: cross-government findings

[18205] UK-wide, Wales . Guidance, Current

[18207] About 20,000 staff in 12 organisations (including the Welsh Government) used M365 Copilot from September to December 2024. Users self-reported an average saving of 26 minutes a day; 17% saw no clear saving. The report includes no costs or return-on-investment analysis and could not say how saved time was used, so it cannot on its own justify licence spend. Caveat: Time savings are self-reported from range midpoints. DWP's separate Copilot trial evaluation (29 Jan 2026) exists, but its methods and figures were not read.

[18209] Government Digital Service (DCMS)

[18210] Microsoft 365 Copilot Experiment: Cross-Government Findings Report (opens an external website)

[18214] Magenta Book: Guidance on the impact evaluation of AI interventions

[18215] UK-wide . Guidance, Current

[18217] HM Treasury and Evaluation Task Force guidance: plan baselines and a comparison group before deploying AI, and strongly consider randomising access, timing or encouragement because AI is delivered digitally; otherwise use quasi-experimental designs. Its case study cautions against extrapolating early time savings to the whole civil service. Caveat: Last updated 15 May 2026; final part of the page not read.

[18219] HM Treasury; Evaluation Task Force

[18220] Guidance on the Impact Evaluation of AI Interventions (opens an external website)

## Workforce and skills (7) [18223]

[18228] Obligation

[18229] Where, kind and status

[18230] What it means for AI use

[18231] Owner

[18232] Basis

[18235] One Big Thing 2025: AI for All

[18236] UK-wide . Practice, Current

[18238] Every civil servant was asked to complete about one hour of foundational, responsible-use AI training (four 15-minute modules on Civil Service Learning) and take part in departmental activities. Check your department's One Big Thing hub for approved tools and local rules. Caveat: Participation by devolved civil services varies. Wales's Strategic AI Advisory Group discussed it in November 2025; Scottish Government and NICS participation was not confirmed.

[18240] Cabinet Office (Modern Civil Service)

[18241] One Big Thing: AI for All is live (opens an external website)

[18245] Government Skills: Artificial intelligence skills for all

[18246] UK-wide . Guidance, Current

[18248] Free AI courses on Civil Service Learning at four levels: awareness (AI Fundamentals), working (ethics, business value, generative AI), practitioner (machine learning, NLP, working with LLMs) and a two-part Senior Civil Service pathway. Copilot learning is in the Digital skills for all curriculum.

[18249] Government Skills (Cabinet Office)

[18250] Artificial intelligence skills for all (opens an external website)

[18254] Workforce Partnership Council: Managing technology that manages people / Using AI at work

[18255] Wales . Guidance, Current

[18257] Social partnership guidance agreed by the Welsh Government, public sector employers and trade unions. It requires human oversight of strategic decisions and human involvement in day-to-day decisions made by algorithmic management systems. It also calls for consultation and procurement due diligence, staff training, ongoing monitoring and protection of individual rights when AI is used to manage staff. Caveat: Guidance, not statute. It sits within the social partnership model, but its link to the duties in the Social Partnership and Public Procurement (Wales) Act 2023 was not confirmed.

[18259] Welsh Government Workforce Partnership Council (Welsh Government, unions, employers)

[18260] Wales' public sector leading the way in responsible AI use (opens an external website)

[18264] Social Partnership and Public Procurement (Wales) Act 2023

[18265] Wales . Law, In force

[18267] Sets up the Social Partnership Council and a social partnership duty requiring listed Welsh public bodies to seek consensus or compromise with recognised trade unions when setting well-being objectives and making decisions of a strategic nature. It also creates a socially responsible procurement duty. It is the statutory basis for involving unions in strategic AI workforce decisions in Wales. Caveat: The Act does not mention AI; applying it to AI is an interpretation. The summary of the duty is from general knowledge of the Act and was not re-read in section text during this check. Royal Assent date not shown on the contents page.

[18269] Welsh Government; Social Partnership Council

[18270] Social Partnership and Public Procurement (Wales) Act 2023 (opens an external website)

[18274] PCS demands for a civil service AI agreement

[18275] UK-wide . Practice, Current

[18277] PCS, the largest civil service union, wants formal talks with the Cabinet Office on AI. Its demands include agreement before AI systems are introduced, disclosure of existing systems, no AI decisions about staff or AI monitoring of workers, no job losses, impact assessments before roll-out and shared productivity gains. Expect these points in departmental consultations on AI. Caveat: Union position, not an obligation.

[18279] Public and Commercial Services Union

[18280] PCS calls for formal talks with Cabinet Office on AI (opens an external website)

[18284] FDA and Fabian Society: Adopt, Innovate, Transform

[18285] UK-wide . Practice, Current

[18287] The senior civil servants' union and the Fabian Society call for an AI vision developed with staff and unions, better access to AI tools, and AI career paths and reward. They also want AI protections agreed with unions, including ways for staff to give feedback on how AI is used. Caveat: Union and think-tank position, not an obligation.

[18289] FDA (union) and Fabian Society

[18290] FDA and Fabian Society launch new AI report (opens an external website)

[18294] TUC Artificial Intelligence (Regulation and Employment Rights) Bill campaign

[18295] UK-wide . Practice, Current

[18297] The TUC has drafted a 'ready to go' AI bill that would require workers to be told when AI makes important decisions about them, give a right to an explanation and keep decisions human-centred. It has no legal force, but it frames union expectations for AI used in HR, pay, discipline and monitoring. Caveat: Campaign document. Page last modified 11 Nov 2025. No government bill has adopted it.

[18299] Trades Union Congress

[18300] Launching the TUC's 'Ready to Go' AI Bill (opens an external website)

[18303] Back to the contents · Suggest a correction (opens GitHub)

