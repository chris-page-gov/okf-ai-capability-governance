---
type: publisher-section
title: People and adoption
status: draft
sources:
- title: People and adoption
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-people-and-adoption
x-dom-section: part-people-and-adoption
---

# People and adoption

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-people-and-adoption)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[10130] Part 7 of 12 · 12 chapters

## People and adoption [10131]

[10140] The team

## Who needs to be in the room [10141]

[10142] The Service Manual's multidisciplinary team, extended for AI. Not every role is full-time, but every role is engaged from discovery, not summoned for sign-off. "Critical at" marks where each role's absence hurts most.

## Set the direction [10146]

[10148] Accountable and delivery leadership

## Senior Responsible Owner [10151]

[10152] Accountability, benefits, risk appetite. The name on the assurance forms.

[10153] Critical at · Discover → Operate

## Product manager [10155]

[10156] Problem framing, value, prioritisation of the backlog.

[10157] Critical at · Discover · Design

## Delivery manager [10159]

[10160] Cadence, dependencies, unblocking the team.

[10161] Critical at · Build · Deploy

## Programme / portfolio lead [10163]

[10164] Fit with the wider portfolio; stops duplicate AI pilots.

[10165] Critical at · Discover · Deploy

## Build the capability [10168]

[10170] Data and AI engineering

## Data scientist [10173]

[10174] Modelling choices and honest evaluation design.

[10175] Critical at · Design · Build

## AI / ML engineer [10177]

[10178] Pipelines, integration, MLOps, guardrails in code.

[10179] Critical at · Build · Operate

## Data engineer [10181]

[10182] Data quality, provenance, pipelines that last.

[10183] Critical at · Design · Build

## Technical architect [10185]

[10186] System design, interoperability, exit routes.

[10187] Critical at · Design

## Assure and protect [10190]

[10192] Risk, rights and control

## Cyber security specialist [10195]

[10196] Threat modelling and NCSC-aligned controls.

[10197] Critical at · Design · Deploy

## DPO / information governance [10199]

[10200] DPIA, lawful basis, records of processing.

[10201] Critical at · Discover · Design

## Legal adviser [10203]

[10204] Public law, IP and copyright, contracts.

[10205] Critical at · Design · Deploy

## Ethics adviser [10207]

[10208] Bias, participation, societal impact.

[10209] Critical at · Discover → Operate

## Ground it in reality [10212]

[10214] Users, domain and money

## User researcher [10217]

[10218] Real user needs, and real harms, observed rather than assumed.

[10219] Critical at · Discover · Operate

## Service designer [10221]

[10222] The end-to-end journey, including the failure paths.

[10223] Critical at · Design

## Domain expert / operational staff [10225]

[10226] Casework truth, edge cases, what the data actually means.

[10227] Critical at · Discover → Operate

## Commercial specialist [10229]

[10230] Procurement routes, vendor terms, ethical parity for third parties.

[10231] Critical at · Discover · Deploy

[10232] Skills pipeline. Recruit and upskill through the Government Digital and Data profession's capability framework, Civil Service AI training and the cross-government AI community. Playbook principle 9 makes this the deploying organisation's responsibility, not the vendor's.

[10234] Back to the contents · Suggest a correction (opens GitHub)

[10246] Multidisciplinary AI service team

## Twelve disciplines around one AI service [10247]

[10248] Collaborating to design, build, govern and operate trustworthy AI services that deliver public value — through design and plan, build and enable, deploy and operate, measure and improve. The service at the centre is defined by user needs, public value, trust, safety and outcomes.

## Product management [10252]

[10254] Strategy & roadmap

[10255] Prioritisation & value

[10256] Stakeholder alignment

## Service design [10258]

[10260] End-to-end journeys

[10261] Inclusive & accessible

[10262] Experience design

## Solution architecture [10264]

[10266] Architecture & patterns

[10267] Integration & interoperability

[10268] Scalability & resilience

## Data & AI [10270]

[10272] Data strategy & governance

[10273] Data quality & lineage

[10274] Model design & evaluation

## Security [10276]

[10278] Secure by design

[10279] Threat modelling

[10280] Security assurance

## Information governance [10282]

[10284] Information management

[10285] Records & retention

[10286] Data classification

## Legal & policy [10288]

[10290] Lawful & ethical use

[10291] Policy compliance

[10292] Contracts & liabilities

## Commercial [10294]

[10296] Procurement strategy

[10297] Supplier management

[10298] Value for money

## Operations [10300]

[10302] Run & support

[10303] Monitoring & reliability

[10304] Incident management

## Learning & development [10306]

[10308] Capability & skills

[10309] Training & guidance

[10310] Adoption & culture

## Accessibility & inclusion [10312]

[10314] WCAG & inclusive design

[10315] Equality impact

[10316] Usability for all

## User research [10318]

[10320] Understand users

[10321] Research & insights

[10322] Usability & validation

## Team principles [10325]

[10326] User-centred Design with and for users at every stage.

[10328] Inclusive Accessible, equitable and easy to use.

[10330] Trust & safety Build security, privacy and ethics in from the start.

[10332] Collaborative Work together, share ideas and challenge constructively.

[10334] Agile & iterative Learn quickly, adapt and improve continuously.

[10336] Outcome focused Measure what matters and deliver public value.

## Key inputs [10339]

[10341] User needs & insights

[10342] Policies, strategy & standards

[10343] Data & knowledge assets

[10344] Technology & platforms

[10345] Stakeholders & partners

## Key outputs [10347]

[10349] Trusted AI services that work for users

[10350] Better outcomes & public value

[10351] Evidence & insights for decisions

[10352] Assured, compliant & well governed

[10353] Skilled teams & continuous learning

[10354] Back to the contents · Suggest a correction (opens GitHub)

[10366] Roles & pathways

## Learn. Apply. Progress. [10367]

[10368] Role-specific learning journeys to build skills, confidence and impact at every stage of adoption. Pick the role you are supporting; the pathway shows what capability looks like at each of four levels.

[10371] YOUR JOURNEY

## 1. Assess current skills [10376]

## 2. Choose your pathway [10380]

## 3. Learn & practise with support [10384]

## 4. Apply in real work [10388]

## 5. Measure impact & improve [10392]

## 1 · Aware [10397]

[10398] Understand AI basics and opportunities

## AI fundamentals [10399]

## Opportunities & risks [10400]

## Strategic context [10401]

## Responsible AI [10402]

## 2 · Practitioner [10406]

[10407] Apply AI tools and techniques with guidance

## Use cases & value [10408]

## Prioritisation [10409]

## Governance basics [10410]

## Supporting teams [10411]

## 3 · Advanced [10415]

[10416] Design, adapt and lead AI solutions

## AI strategy alignment [10417]

## Portfolio oversight [10418]

## Investment decisions [10419]

## Risk appetite [10420]

## 4 · Expert [10424]

[10425] Shape strategy, standards and innovation

## AI vision & innovation [10426]

## Ecosystem leadership [10427]

## Policy influence [10428]

## Ethical leadership [10429]

## What supports progress at every level [10432]

[10435] Learning & development Role-based curricula, microlearning, labs, communities of practice

[10439] Tools & platforms Approved tools, secure sandboxes, reusable components

[10443] Guidance & standards Policies, playbooks, architectures, guardrails and templates

[10447] Measuring progress Skills assessment, certification, impact and value metrics

[10451] Recognition & career Career pathways, communities, badges and incentives

## Principles behind the pathways [10454]

[10455] Role relevant Right skills for the job

[10458] Practical Learn by doing in real work

[10461] Progressive Build from foundations to mastery

[10464] Trusted Safe, secure and responsible AI use

[10467] Measurable Evidence of competence and impact

[10470] Inclusive Accessible and supportive for all

## From task execution to higher-value work [10473]

[10474] AI augments people, it does not replace them. Roles evolve to focus on judgement, creativity, oversight and continuous improvement.

[10476] ROLE TRADITIONAL FOCUS AI ENABLES AI-ENABLED FUTURE FOCUS IMPACT

[10484] Policy adviser

[10488] Research and information gathering

[10489] Drafting options and text

[10490] Compiling background papers

[10492] AI summarises evidence, suggests options, drafts content, finds patterns

## Strategic analysis and judgement [10494]

## Evaluating trade-offs and impacts [10495]

## Engaging stakeholders and deciding [10496]

[10498] Better policy quality and impact

[10502] Contact centre adviser

[10506] Answering routine queries

[10507] Searching knowledge bases

[10508] Logging and updating cases

[10510] AI handles routine queries, retrieves answers, suggests next best action

## Complex case resolution [10512]

## Empathy and relationship building [10513]

## Handling exceptions and escalation [10514]

[10516] Improved citizen experience

[10520] Software engineer

[10524] Writing and refactoring code

[10525] Testing and fixing defects

[10526] Reviewing changes

[10528] AI generates code, finds bugs, recommends tests, documents changes

## Architecture and design decisions [10530]

## Code review and security assurance [10531]

## Solving novel and complex problems [10532]

[10534] Faster delivery, higher quality

[10538] Data analyst

[10542] Data extraction and preparation

[10543] Running standard reports

[10544] Creating charts and dashboards

[10546] AI prepares data, generates insights, builds visuals, detects anomalies

## Deeper analysis and insight [10548]

## Explaining drivers and implications [10549]

## Advising on data strategy [10550]

[10552] Stronger insight and decisions

[10556] HR advisor

[10560] Processing requests

[10561] Answering policy questions

[10562] Updating records

[10564] AI answers FAQs, guides processes, drafts documents, checks compliance

## People strategy and coaching [10566]

## Complex case management [10567]

## Culture and inclusion leadership [10568]

[10570] Better employee experience

[10574] Risk manager

[10578] Collecting risk data

[10579] Maintaining risk registers

[10580] Producing standard reports

[10582] AI identifies risks, analyses scenarios, monitors controls, suggests mitigations

## Interpreting risk in context [10584]

## Prioritising actions and trade-offs [10585]

## Overseeing governance and assurance [10586]

[10588] Stronger risk management

## The shift [10592]

## From doing tasks… [10593]

## …to orchestrating with AI [10594]

## …to focusing on judgement, creativity and impact [10595]

## Delivering better outcomes for citizens and society [10596]

## What people need [10598]

[10600] AI literacy and critical thinking

[10601] Change mindset and adaptability

[10602] Collaboration and communication

[10603] Ethics and responsible use

[10604] Success depends on people, process redesign, culture, leadership and trust — supported by responsible AI and strong governance.

[10605] Back to the contents · Suggest a correction (opens GitHub)

[10617] AI workforce capability academy

## Building the skills and confidence to design, develop, govern and operate trusted AI services [10618]

[10619] Five learning pathways across four stages. Build confidence. Apply skills. Drive impact. Lead change.

[10621] Foundation Understand the basics Build Develop practical skills Advance Apply and lead Lead Expertise and influence

## Leaders & decision makers [10631]

[10632] Set direction and provide oversight

[10635] Foundation AI essentials for leaders Opportunities, limitations · Risks and public value · Responsible AI principles

[10639] Build AI governance & accountability Oversight responsibilities · Risk appetite and decision rights · Human control and assurance

[10643] Advance Strategic AI leadership Portfolio management · Measuring outcomes and impact · Ethics, bias and inclusion

[10647] Lead Shaping the AI agenda Leading culture change · Stakeholder engagement · Policy influence and advocacy

## Product & service teams [10651]

[10652] Design and deliver AI-enabled services

[10655] Foundation AI for product & service teams User needs and problem framing · AI use cases and value · Ethical and inclusive design

[10659] Build Designing AI-enabled services Journey mapping with AI · Prototyping and evaluation · Managing suppliers

[10663] Advance AI product management Prioritisation and roadmapping · Data-informed outcomes · Scaling AI responsibly

[10667] Lead Leading AI transformation Cross-team leadership · Change management · Driving adoption and value

## Technical & data teams [10671]

[10672] Build and run secure, reliable AI agents

[10675] Foundation AI & data fundamentals Data types and quality · Intro to ML, LLMs and agents · Privacy and security basics

[10679] Build Building AI agents Prompt engineering · RAG and tool integration · Testing and evaluation

[10683] Advance Advanced engineering Agent orchestration · Model evaluation & guardrails · Red teaming and robustness

[10687] Lead Technical excellence Architecture leadership · Innovation and emerging tech · Open standards and reuse

## Governance & assurance teams [10691]

[10692] Assure, audit and manage risk

[10695] Foundation AI governance basics Policies, standards and roles · Risk types and controls · Transparency and ATRS

[10699] Build Assessing and controlling risk DPIA for AI systems · Bias, fairness and inclusion · Security threat modelling

[10703] Advance AI assurance & audit Assurance frameworks · Monitoring and evidence · Incident and issue management

[10707] Lead Assurance leadership Independent challenge · Audit strategy and reporting · Regulatory horizon scanning

## Operational & support teams [10711]

[10712] Operate, monitor and support users

[10715] Foundation Working with AI tools Everyday AI use · Human oversight basics · Data handling and security

[10719] Build Operating AI services Monitoring and logging · Incident reporting · User support and feedback

[10723] Advance Optimising operations Performance analysis · Continuous improvement · Knowledge sharing

[10727] Lead Operational excellence Service reliability leadership · Automation and productivity · Building a learning culture

## Core capabilities for all roles [10732]

[10733] Responsible AI Ethics, fairness, transparency

[10735] Security & privacy Secure by design, data protection

[10737] Human oversight Accountability, challenge, escalation

[10739] Data literacy Quality, lineage, classification

[10741] Accessibility & inclusion Design for everyone, equitable outcomes

[10743] Continuous learning Iterate, adapt and improve

## Learning methods [10747]

[10748] Instructor-led workshops E-learning modules Hands-on labs & sandboxes Communities of practice Certification & badging Playbooks & job aids

## Capability progression [10756]

[10757] Aware Practitioner Expert Leader

[10762] Back to the contents · Suggest a correction (opens GitHub)

[10774] Capability & maturity · illustrative frameworks

## Maturity is a journey, not a destination [10775]

[10776] Seven levels, from ad-hoc use to adaptive capability. Choose a level to see what it looks like across the dimensions and the twelve capability domains — then record the evidence you could actually show.

## Level 3 · Governed [10779]

## Next: 3 → 4 — Integrate and embed [10780]

[10781] Defined governance and controls. Repeatable patterns, registered use cases and measured pilots.

[10786] Leadership Accountable owners

[10789] Governance Controls, risk tiers, assurance gates

[10792] People & skills Role-based skills

[10796] Data & knowledge Catalogued, governed access

[10799] Technology Reference architecture, model choice

[10802] Value & outcomes Measured value from pilots

## Evidence over opinion [10808]

## Record the evidence you can actually show for each domain. [10810]

[10813] Strong Independently validated

[10817] Moderate Documented internal evidence

[10821] Emerging In pilot or partially proven

[10825] Weak Anecdotal or not evidenced

[10829] Not assessed No evidence available

## Strategy & leadership [10839]

## Not recorded [10841]

[10842] AI strategy aligned to business objectives and risk appetite

## People & skills [10849]

## Not recorded [10851]

[10852] Role-based skills framework and capability plans

## Use cases & value [10859]

## Not recorded [10861]

[10862] Use case portfolio managed with benefits tracking

## Technology & architecture [10869]

## Not recorded [10871]

[10872] Target architecture, standards and integration patterns

## Data & information [10879]

## Not recorded [10881]

[10882] Governed data assets, metadata and lineage

## Security & privacy [10889]

## Not recorded [10891]

[10892] Security-by-design; identity, access and monitoring in place

## Responsible AI & ethics [10899]

## Not recorded [10901]

[10902] Responsible AI framework and assurance process

## Commercial & suppliers [10909]

## Not recorded [10911]

[10912] Managed suppliers, contracts and risk assessments

## Finance & FinOps [10919]

## Not recorded [10921]

[10922] Cost visibility, allocation and showback

## Operations & service management [10929]

## Not recorded [10931]

[10932] Defined operating model and SLAs

## Measurement & outcomes [10939]

## Not recorded [10941]

[10942] Benefits tracking; outcomes measured

## Community & knowledge [10949]

## Not recorded [10951]

[10952] Communities of practice and curated knowledge

## How to use this [10955]

[10957] 1 Assess current evidence against each domain

[10959] 2 Identify priority gaps — emerging and weak ratings

[10961] 3 Take actions to build evidence and capability

[10963] 4 Review and update regularly

## Evidence that counts [10966]

[10967] Policies & strategies Architectures & standards Training records Use case business cases KPIs & dashboards Audit & assurance reports Lessons learned & patterns

## What good looks like [10976]

[10978] Clear strategy and governance

[10979] Skilled and empowered people

[10980] Trusted data and knowledge

[10981] Secure and responsible by design

[10982] Smart commercial and supplier management

[10983] Efficient and sustainable spend

[10984] Measurable outcomes and public value

[10985] Strong communities and shared learning

## Where the capability gaps are, by role [10986]

[10987] Current against required capability, scored 5 (critical gap) to 1 (strong, sustain). Illustrative sector-level assessment — replace with your own to prioritise investment. Filter to one role group to read a single column.

[10993] CAPABILITY DOMAIN

[10994] Executives & leaders

[10995] Business & service owners

[10996] Product & delivery managers

[10997] Data & info professionals

[10998] Engineers & technical teams

[10999] Security & risk professionals

[11000] Commercial & procurement

[11001] Finance & FinOps

[11002] Frontline staff & practitioners

[11004] Strategy & leadership Vision, governance, value

[11006] 2

[11007] 4

[11008] 4

[11009] 4

[11010] 3

[11011] 3

[11012] 3

[11013] 4

[11014] 4

[11016] People & change Adoption, culture, engagement

[11018] 3

[11019] 3

[11020] 3

[11021] 3

[11022] 4

[11023] 4

[11024] 3

[11025] 3

[11026] 4

[11028] AI & data literacy Understanding AI, data and information

[11030] 3

[11031] 4

[11032] 3

[11033] 2

[11034] 3

[11035] 3

[11036] 4

[11037] 3

[11038] 5

[11040] Technology & engineering Tools, platforms, integration

[11042] 3

[11043] 3

[11044] 3

[11045] 3

[11046] 2

[11047] 3

[11048] 4

[11049] 4

[11050] 4

[11052] Data & information Quality, access, governance

[11054] 4

[11055] 4

[11056] 4

[11057] 2

[11058] 3

[11059] 3

[11060] 3

[11061] 3

[11062] 4

[11064] Security, privacy & risk Threats, controls, compliance

[11066] 3

[11067] 3

[11068] 3

[11069] 4

[11070] 3

[11071] 2

[11072] 3

[11073] 3

[11074] 4

[11076] Responsible AI & ethics Fairness, transparency, human oversight

[11078] 3

[11079] 3

[11080] 4

[11081] 3

[11082] 3

[11083] 3

[11084] 3

[11085] 3

[11086] 4

[11088] Commercial & procurement Contracts, suppliers, value

[11090] 3

[11091] 3

[11092] 4

[11093] 3

[11094] 3

[11095] 3

[11096] 2

[11097] 4

[11098] 4

[11100] Finance & FinOps Cost management, allocation, value

[11102] 3

[11103] 4

[11104] 3

[11105] 3

[11106] 3

[11107] 3

[11108] 3

[11109] 2

[11110] 3

[11112] Operations & service management Monitoring, support, continuity

[11114] 3

[11115] 4

[11116] 3

[11117] 3

[11118] 3

[11119] 3

[11120] 3

[11121] 3

[11122] 3

[11124] Measurement & outcomes KPIs, impact, benefits — not scored on the source board

[11126] —

[11127] —

[11128] —

[11129] —

[11130] —

[11131] —

[11132] —

[11133] —

[11134] —

[11137] Critical gap High priority

[11141] Major gap Act soon

[11145] Moderate gap Plan to address

[11149] Minor gap Monitor

[11153] Strong / no gap Sustain

## Top priority gaps [11158]

[11159] AI & data literacy for frontline staff

[11160] Data & information for executives, business owners and product managers

[11162] People & change for technical and security roles

[11163] Commercial & procurement for product managers and finance

[11164] Finance & FinOps for product managers

## Key insights [11166]

[11168] Frontline staff need stronger AI literacy and confidence

[11169] Data and information capabilities are a cross-role enabler

[11170] Product managers and finance need deeper commercial and FinOps skills

[11171] Technical teams are relatively strong but need continued investment in security by design

## How to use the heatmap [11174]

[11176] 1 Assess current capability levels by role

[11178] 2 Compare to required capability levels

[11180] 3 Prioritise high-impact gaps

[11182] 4 Invest in learning, support and resources

[11184] 5 Measure progress and outcomes

## Actions to close gaps [11187]

[11188] Role-based learning pathways Communities of practice and peer learning Targeted coaching and enablement Tools, templates and reusable assets Time, budget and leadership support

[11194] Back to the contents · Suggest a correction (opens GitHub)

[11206] Inclusive & accessible adoption

## Different people. Different needs. Shared success. [11207]

[11208] AI tools should empower everyone by offering choice, clarity and support. The spectrum below runs from empowered and confident to apprehensive — and inclusion is not one size for all: listening, choice and support help everyone succeed with AI.

## Enthusiastic & confident [11212]

[11213] Sees AI as a productivity booster and enjoys exploring new tools.

## May typically [11214]

[11216] Experiment and customise

[11217] Share tips and best practice

[11218] Integrate AI into daily work

## Key needs [11219]

## Advanced features [11220]

## Experimentation space [11221]

## Recognition & influence [11222]

## Ways to contribute back [11223]

## Cautious but willing [11225]

[11226] Interested and willing to try, but wants reassurance and guidance.

## May typically [11227]

[11229] Use AI for simple, low-risk tasks

[11230] Seek examples and best practice

[11231] Prefers structured learning

## Key needs [11232]

## Clear guidance & examples [11233]

## Safe practice environments [11234]

## Step-by-step learning [11235]

## Trusted peer support [11236]

## Needs support & clarity [11238]

[11239] Wants to benefit from AI but needs help understanding how and when.

## May typically [11240]

[11242] Uses guided features

[11243] Needs help in context

[11244] Prefers practical, relevant training

## Key needs [11245]

## Plain language & relevance [11246]

## Role-based training [11247]

## Hand-holding & coaching [11248]

## Time to learn & practise [11249]

## Anxious & overwhelmed [11251]

[11252] Feels unsure or overwhelmed by change, complexity or risk.

## May typically [11253]

[11255] Avoids or minimises use

[11256] Worried about errors or job impact

[11257] Prefers human interaction

## Key needs [11258]

## Reassurance & transparency [11259]

## Simple, limited choices [11260]

## Human support always available [11261]

## Safe, low-pressure options [11262]

## Resistant / disengaged [11264]

[11265] Does not see value or may distrust AI or the organisation's intent.

## May typically [11266]

[11268] Declines to use

[11269] Questions fairness or reliability

[11270] Prefers current ways of working

## Key needs [11271]

## Listen & understand concerns [11272]

## Involve in decisions [11273]

## Address trust & fairness [11274]

## Show tangible benefits [11275]

## Design for inclusion [11278]

[11279] Choice & control Let users choose how AI helps, when and in what way

[11281] Clear & simple Use plain language, short explanations and examples

[11283] Flexible interaction Support different workflows, speeds and preferences

[11285] Neuroinclusive design Reduce cognitive load, provide structure, minimise distractions

[11287] Accessible by default WCAG compliant, multimodal, and assistive-tech friendly

[11289] Safe & trusted Protect data, explain limits, and make AI behaviour predictable

[11291] Human support Easy access to help, feedback channels and champions

## Enablers & supports [11295]

[11296] Leadership sponsorship Digital & AI champions Inclusive communication Role-based learning paths Protected learning time Local support networks Feedback & continuous listening Measure & adapt for all users

## Remember [11306]

[11307] Inclusion is not one size fits all. Listening, choice and support help everyone succeed with AI — and inclusive adoption empowers people, strengthens trust and delivers better public services.

## The cross-government community constellation [11308]

[11309] Working together across communities to share knowledge, avoid duplication and build trusted, reusable AI and Copilot capabilities. The weekly cross-government call is the open forum at the centre.

## Practice and engineering [11312]

[11313] Hands-on development, experimentation and engineering excellence.

[11314] AI Engineering Lab Data Science & AI Community Low Code Community Microsoft 365 Technical Community Prototyping and Sandboxes

## Adoption and digital workplace [11321]

[11322] User enablement, organisational change and the digital workplace.

[11323] Digital Workplace Community Change & Adoption Network AI Champions Network Learning & Capability Network Comms & Engagement Network

## Data management communities [11330]

[11331] Data governance, catalogues and information management excellence.

[11332] Data Management Network Data Catalogue Community Information Governance Network Metadata & Standards Community Knowledge Management Community

## Ethics, safety and assurance [11339]

[11340] Ethics, AI governance and assurance across the public sector.

[11341] Cross-Government Data & AI Ethics Community AI Assurance Network Security & Privacy Community Accessibility & Inclusion Network

## Governance and policy network [11347]

[11348] Policy, standards, guidance and compliance.

[11349] Government Digital Service (GDS) DSIT AI Policy & Standards Government Analysis Function Identity & Access Community Service Design Network

## Commercial, finance and suppliers [11356]

[11357] Commercial strategy, vendor engagement and cost insight.

[11358] Commercial Community FinOps Community Supplier Engagement Community Contract & Licensing Community Procurement Policy Community

## Cyber and risk network [11365]

[11366] Cyber security, risk management and resilience.

[11367] Cyber Security Network Risk & Assurance Community Resilience Community

## Digital workplace communities [11372]

[11373] Adoption, change, champions and enablement.

[11374] Copilot Weekly XGov Call Community of practice sessions Show and tell forums

## Cross-sector and place-based connectors [11380]

[11381] Central government departments & ALBs Devolved administrations Local government & combined authorities Health & care network Education network Policing & justice network International & supranational links

## Why the constellation matters [11390]

[11391] Share once, use many times Publish once so others do not repeat the work

[11393] Avoid duplication and rework Find what exists before building it again

[11395] Consistent standards, safer adoption Common expectations across organisations

[11397] Better value and lower total cost Aggregate demand and reuse assets

[11399] Faster innovation with confidence Learn from those who have already tried

[11401] Better outcomes for citizens The point of all of it

[11403] Back to the contents · Suggest a correction (opens GitHub)

[11415] Journeys · adoption operating model

## Adoption is a journey we take together [11416]

[11417] A system of people, processes and support, not a rollout. Leadership sets direction. Business owns outcomes. Communities enable change. Data and evidence drive continuous improvement.

## People first [11423]

## Trust & responsibility [11427]

## Outcome focused [11431]

## Iterate & improve [11435]

## Collaborate & share [11439]

## Evidence & value [11443]

[11445] Inputs

[11446] Strategy & priorities User needs & frontline insights Data, content & tools Policy & regulatory requirements Evidence & external intelligence Budget & investment

## Lead & sponsor [11459]

[11461] Executive sponsorship and vision

[11462] Align to strategy and public value

[11463] Set priorities and risk appetite

[11464] Allocate investment and authority

[11465] Communicate the why

## Engage & align [11471]

[11473] Business ownership and champions

[11474] Stakeholder mapping and engagement

[11475] Co-design with users

[11476] Change impact assessment

[11477] Inclusive and accessible by design

## Prepare & enable [11483]

[11485] Skills, training and role-based learning

[11486] Guidance, guardrails and policies

[11487] Tools, environments and data readiness

[11488] Community of practice and peer support

[11489] Address accessibility and neurodiversity

## Adopt & use [11495]

[11497] Start small, iterate and learn

[11498] Embed in workflows and processes

[11499] Measure early value and experience

[11500] Support and coaching at point of need

[11501] Promote quick wins and success stories

## Measure & improve [11507]

[11509] Track usage, quality and outcomes

[11510] Measure value, cost and productivity

[11511] Gather feedback and identify issues

[11512] Improve models, processes and data

[11513] Report transparently and share learnings

## Scale & sustain [11519]

[11521] Scale proven use cases and patterns

[11522] Standardise where appropriate

[11523] Manage risk, compliance and assurance

[11524] Optimise cost and resource use

[11525] Sustain, adapt and reinvest for impact

[11527] Outcomes

[11528] Better public services Improved user experience Lower cost, higher productivity Stronger compliance and trust Sustainable and adaptable Measurable public value

## Enabling foundations [11536]

## Data & information foundations [11541]

## Security, privacy & safety [11545]

## Responsible AI, ethics & inclusion [11549]

## Technology & platforms [11553]

## Policies, standards & governance [11557]

## Commercial & FinOps [11561]

## Communities & knowledge sharing [11565]

## Operations & support [11569]

## Measurement & feedback loop [11571]

[11572] 1. Observe usage, quality, cost, risk 2. Analyse results, feedback, insights 3. Learn what works, what doesn't 4. Decide prioritise actions and changes 5. Act improve, enable, remove barriers 6. Repeat continuous improvement

## Key roles [11586]

[11589] Leadership Set direction, sponsor change and unblock

[11593] Business owner Define outcomes, prioritise use cases and realise value

[11597] Product / service manager Manage lifecycle, measure value and iterate

[11601] Champion network Advocate, share learning and support peers

[11605] Data & information professional Ensure quality, access, lineage and governance

[11609] Security & privacy Manage risk, protect data and users

[11613] Commercial & FinOps Manage contracts, licensing, cost and value

[11617] Change & adoption team Drive engagement, training and communications

[11621] Technical team Build, integrate and operate solutions

[11625] Frontline users Use, feed back and help shape improvements

[11628] The person-level journey

## From training to organisational capability [11629]

[11630] Six stages from awareness to community contribution — a progression, not a course. The continuous improvement loop runs across all six.

[11632] Stage 1 of 6 All staff

## Awareness [11635]

## Understand the opportunity [11636]

## Goal [11639]

[11640] Build awareness of AI basics and potential in public services.

## Key activities [11642]

[11644] Introductory sessions

[11645] AI fundamentals

[11646] Real-world examples

[11647] Responsible AI awareness

## Outcome [11649]

## Informed and curious workforce [11650]

## Support model [11653]

[11655] Central resources and guidance

[11656] Local support and champions

[11657] Communities of practice

[11658] Expert clinics and labs

[11659] Feedback and improvement

## Learning modes [11661]

[11663] Self-paced learning

[11664] Instructor-led training

[11665] On-the-job practice

[11666] Peer learning and sharing

[11667] Microlearning and nudges

## Measuring progress [11669]

[11671] Adoption rates

[11672] Capability assessments

[11673] Business outcomes

[11674] User satisfaction

[11675] Value realised

## Enablers throughout the journey [11677]

[11678] Leadership and sponsorship Clear guidance and guardrails Accessible tools and environments Role-based learning and support Time to learn and experiment Recognition and career pathways Feedback and user research Measurement and value realisation

[11687] Back to the contents · Suggest a correction (opens GitHub)

[11699] Copilot programme · agent rollout

## Why we decided not to just switch on first-party and Agent Builder agents [11700]

[11701] The opportunity is significant, but ownership, risk and consistency matter.

## Agents can influence real work [11705]

[11706] More than simple prompts, built well, they can support processes, provide advice, surface information and shape decisions.

## Creation creates responsibility [11708]

[11709] Every agent needs a clear purpose, an accountable owner and active lifecycle management. Risk management is critical.

## Scale can amplify inconsistency or provide opportunity [11711]

[11712] Through a culture of safe experimentation, coupled with close monitoring, we will find opportunities to deliver the best agents, while avoiding “agent-aggedon”.

## Success is confident adoption and organisational maturity — not simply the speed of feature enablement. [11714]

## Finding the sweet spot — a “test & learn” approach [11715]

[11716] Innovate confidently. Manage risk. Deliver value. Together.

## Experimentation at the core [11718]

## Start small [11723]

## Test & learn [11727]

## Iterate quickly [11731]

## Learn & adapt [11735]

[11736] Delivering

## Outcomes that matter [11738]

## Business value [11743]

## User adoption [11747]

## Continuous improvement [11751]

## Sustainable scale [11755]

## Start small. Learn safely. Scale with confidence. [11757]

[11758] Public Beta and measured communications ramp up gives the organisation space to learn about the technology, ownership and responsibility before broader scale.

[11763] Copilot Agent Builder is one of many business tools

[11767] Assurance requirements vary by risk and operational impact

[11771] Business areas tailor guidance to their environment

## Governance that enables, not blocks [11772]

[11773] Proportionate guardrails create confidence to experiment.

## Proactive, not reactive [11777]

[11778] Put standards and guidance in place early.

## Central guardrails, local accountability [11780]

[11781] Set common expectations; keep responsibility with agent owners.

## Proportionate and risk-based [11783]

[11784] Apply controls according to use case and data sensitivity.

## Test & learn [11786]

[11787] Evolve the model using real scenarios and evidence.

## What good looks like [11789]

[11791] Agents are visible, owned and managed through their lifecycle.

[11792] Responsible-use standards are embedded into governance and guidance.

[11793] Oversight covers usage, value and risk signals.

[11794] High-value use cases can progress without unnecessary friction.

[11795] Experimentation remains welcome within clear guardrails.

## Governance is the licence to innovate confidently. [11797]

## Support around every colleague [11798]

[11799] Technology enablement is paired with readiness, guidance and local ownership.

## Clear guidance [11802]

[11803] What colleagues can use, when and how to work within the guardrails.

## Communications [11805]

[11806] Initial soft launch, then expand messages around use cases and value. Align to OBT.

## Peer support [11808]

[11809] Digital Champions, Sponsors and business representatives help locally.

## Learning [11811]

[11812] Options from “getting started” through to building agents, focused on real use cases.

## Adoption support [11814]

[11815] Tailored help to embed useful agents into team workflows. May extend to Tiger Teams.

## Programme sets the foundation for safe, consistent and responsible use [11817]

## Business areas adapts to local needs and drives adoption in their context [11819]

## Measure what matters [11820]

[11821] Reporting is not the outcome. It is the feedback loop that helps us decide what to support, change, scale or retire.

[11824] Builders Who is creating agents?

[11827] Ownership Are agents visible and actively owned?

[11830] Usage Which agents are being used?

[11833] Enablement Are learning and communications changing behaviour?

[11836] Value What outcomes and benefits are emerging?

## Challenges we are facing into [11840]

[11842] Reporting will mature

[11843] Identify duplication — spot the best agents

[11844] Alert when agents breach a usage or share threshold

[11845] Business takes ownership of their use cases and determines the best tool for the job

[11846] Local resources to take action on the measures

[11847] Back to the contents · Suggest a correction (opens GitHub)

[11859] People and adoption · community

## From isolated questions to collective capability [11860]

[11861] How a cross-government community matures: the engagement arc, the flywheel that turns experience into shared assets, and the honest exchange of what members give and get. Capability without community repeats mistakes; community without operationalisation produces discussion.

## The engagement arc [11863]

## Information access & orientation [11866]

## Establishing the forum and enabling participation [11867]

[11869] Join meetings

[11870] Access chat and resources

[11871] Understand purpose

[11872] Share initial concerns

[11873] Learn community norms

## Exploration & safe experimentation [11875]

## Understanding tools and testing possibilities [11876]

[11878] Product changes & updates

[11879] Prompting and capabilities

[11880] Early pilots and proofs

[11881] Controls and guardrails

[11882] Licensing questions

## Use cases & practical learning [11884]

## Sharing examples and learning what works [11885]

[11887] Show & tell sessions

[11888] Success stories

[11889] Failures and lessons

[11890] Templates and patterns

[11891] Emerging use cases

## Governance & assurance emerge [11893]

## Defining guardrails and ways of working [11894]

[11896] Ownership and accountability

[11897] Data, security & privacy

[11898] Information management

[11899] Human oversight

[11900] Assurance approaches

## Adoption & scaling together [11902]

## Enabling confident organisational adoption [11903]

[11905] Adoption strategies

[11906] Change & comms

[11907] Training & champions

[11908] FinOps & cost visibility

[11909] Scaled rollouts

## Capability & continuous improvement [11911]

## Embedding capability and driving improvement [11912]

[11914] Measuring outcomes

[11915] Community feedback loop

[11916] Reusable assets

[11917] Influencing suppliers

[11918] Evolving standards

[11920] How we engage

## Inclusive participation [11925]

## Open questions & discussion [11929]

## Share knowledge & experience [11933]

## Challenge & constructively critique [11937]

## Capture decisions & actions [11941]

## Feedback & iterate [11945]

## Enablers [11948]

[11950] Safe space

[11951] Regular cadence

[11952] Diverse perspectives

[11953] Community sponsorship

[11954] Accessible resources

## Outcomes [11956]

[11957] Greater clarity & confidence Less ambiguity about products, controls and next steps.

[11959] Reduced risk & duplication Shared lessons prevent repeated mistakes.

[11961] Reusable knowledge Patterns, templates and guidance that can be adapted.

[11963] Faster & safer implementation Less rework, clearer pathways, better preparation.

[11965] Stronger supplier engagement Consolidated questions and influence based on community insight.

## Value created [11968]

## Better public services [11969]

## Better use of public money [11970]

## Increased trust & assurance [11971]

## Continuous improvement of AI capability [11972]

[11974] Continuous learning loop Experience Insight Guidance Action Impact Feedback Improved practice

## The collective learning flywheel [11983]

[11984] The more we share, the more we all improve.

## Bring questions & challenges [11988]

[11989] Surface real needs and uncertainties

## Share evidence & experience [11992]

[11993] Contribute what you have seen and tried

## Compare, challenge & analyse [11996]

[11997] Learn together and test ideas

## Create insights & patterns [12000]

[12001] Turn learning into shared assets

## Apply, adapt & implement [12004]

[12005] Put learning into practice locally

## Report outcomes & lessons [12008]

[12009] Share results and what is next

## Inputs from the community [12012]

[12014] Real problems & open questions

[12015] Use cases & demonstrations

[12016] Challenges, risks & failures

[12017] Policies, approaches & processes

[12018] Cost, licensing & FinOps data

[12019] Security, privacy & assurance issues

[12020] Ideas, suggestions & future needs

## Outcomes for all [12022]

[12024] Practical guidance & templates

[12025] Stronger guardrails & assurance

[12026] Reusable patterns & components

[12027] Skills, confidence & capability

[12028] Smarter investment & cost control

[12029] Influence with suppliers & partners

[12030] Better services & public value

## Enablers of the flywheel [12032]

[12034] Inclusive & welcoming culture

[12035] Safe spaces for openness

[12036] Accessible knowledge & tools

[12037] Clear communication & feedback

[12038] Recognition of contribution

## The value exchange [12039]

[12040] What members contribute, what the community turns it into, and what everyone gains.

## What we contribute [12043]

[12044] Our questions & challenges Share real problems, uncertainties and barriers

[12046] Use cases & demos Show what we are building, testing and learning

[12048] Successes & lessons Share what works, what did not and why

[12050] Policies & approaches Contribute guidance, guardrails and governance ideas

[12052] Tools & templates Share artefacts, patterns, checklists and assets

[12054] Commercial & cost insight Raise licensing, FinOps and procurement experiences

[12056] Security, privacy & assurance Share risk findings, controls and assurance practice

[12058] Our time & expertise Offer help, review, connect others and support each other

[12061] Open discussions & peer challenge Honest conversations that surface real issues

[12063] Shared evidence & patterns Collective intelligence from across government

[12065] Expert input & supplier access Access to Microsoft, experts and the wider network

[12067] Connections & collaboration Find partners, avoid duplication and work together

[12069] Influence & impact Consolidate our voice to shape products, policy and standards

[12071] Capability uplift & confidence Improve skills, maturity and organisational readiness

[12073] Early awareness & reducing risk Spot changes, risks and opportunities earlier

[12075] Reusable outputs & guidance Turn learning into practical guidance and tools

## What we gain [12078]

[12079] Practical answers Faster solutions to real problems

[12081] Time saved Learn from others' experience, avoid repeating mistakes

[12083] Safer adoption Better decisions with shared assurance and guardrails

[12085] Better quality outcomes Access to proven patterns and worked examples

[12087] Cost confidence Understand licensing, usage and FinOps more clearly

[12089] Stronger relationships Collaborate across departments, sectors and professions

[12091] Measurable progress Track maturity, impact and value together

[12093] Greater public value Better services, better use of public money, more trust

[12096] Shared principle: be open, be respectful, challenge constructively and focus on learning together to deliver safe, inclusive and effective AI in the public sector.

[12097] Back to the contents · Suggest a correction (opens GitHub)

[12109] Operating model & programme

## One operating model. Everyone aboard. [12110]

[12111] One AI capability operating model — not separate Copilot, agent, data, assurance and FinOps programmes. Cognitive load down, recognition up, DEIA by default rather than afterthought.

## Four defaults, baked in [12113]

## Privacy by default [12116]

[12117] Every product, every build. DPIA in, not post.

[12118] Existing

## Secure by default [12120]

[12121] Open, auditable, no vendor lock-in.

[12122] Existing

## DEIA by default [12124]

[12125] Inclusion, equity, access — in every spec.

[12126] Adding now

## Recognition by default [12128]

[12129] Named people, visible work, earned respect.

[12130] Adding now

## Reducing cognitive load [12131]

## Less red tape [12134]

[12137] Decision logs replace approval chains

[12140] AI drafts briefings; you review

[12143] Single source of truth per project

[12146] Open by default, restrict by exception

## Cross-pollination [12148]

[12151] Weekly cross-team show-and-tells

[12154] Shared prompt and tool library

[12157] SME pairing across directorates

[12160] Secondments and shadow programmes

## Leadership engagement [12162]

[12165] Monthly programme board updates

[12168] Outcome dashboards, not status reports

[12171] Senior sponsors own a use-case

[12174] Ministers briefed on citizen impact

## DEIA by default — who this serves, and the checklist [12175]

[12176] Every product must actively serve those experiencing the greatest adversity: economic hardship, disabled and neurodivergent users, underrepresented communities, vulnerable households and carers, digital exclusion and low literacy, and everyone algorithmic unfairness would otherwise reach first.

[12181] Who is most harmed if this fails or excludes?

[12185] Does the design assume internet access or literacy?

[12189] Has it been tested with people from affected groups?

[12193] Are legal obligations (Equality Act, PSED) documented?

[12197] Is there a non-digital fallback route?

[12201] Does the data we collect reflect the full population?

[12205] Are there language and accessibility alternatives?

[12209] How will we measure equitable outcomes, not just usage?

## Bias will be reproduced unless actively constrained [12211]

[12212] A model trained on historical outcomes learns the discrimination in the record, not the potential of a well-supported person. Four pre-specified bias domains to audit — and abstention ("insufficient data — human decision only") is always acceptable, and must be possible.

## Allocation [12215]

[12216] Systematically fewer or lesser recommendations for protected groups with equivalent profiles.

## Calibration [12218]

[12219] Predictions accurate against a biased historical record, wrong about supported potential.

## Representation gap [12221]

[12222] Too few cases for a group; the model fills gaps with majority priors.

## Feedback loop [12224]

[12225] Biased outputs produce worse outcomes that retrain the model — break the loop by design.

[12226] Training-data standards: exclude invalidated-treatment-era and sanctioned-employer records and proxy features; require minimum cases per group, representation audits, labelled synthetic augmentation for regularisation only, and temporal weighting toward modern practice. Lived-experience panels review real outputs; community bodies sign off the test criteria; explanations reference functional needs, never the diagnosis.

## The capability programme — four phases [12227]

[12230] Phase 0 · Foundation Weeks 1–4

## Starter capability, safely [12235]

[12236] Private, data-safe assistant; no lock-in; GDPR by design

## Data protection baseline [12238]

[12239] DPIA template, handling principles, red lines

## Use-case registry [12241]

[12242] Crowdsource the top jobs-to-be-done; impact × feasibility

[12245] Phase 1 · Pilot Months 2–4

## Learning pathway [12250]

[12251] Prompting fundamentals, hands-on sprints, peer cohorts

## Open-tool pilots [12253]

[12254] Open-weight models on gov cloud; avoid lock-in from day one

## Impact measurement [12256]

[12257] Hours saved, quality uplift, citizen outcomes — not vanity metrics

[12260] Phase 2 · Scale Months 5–9

## Shared platform [12265]

[12266] Modular, containerised infrastructure across directorates

## Champions network [12268]

[12269] One champion per team; shared prompt library; show-and-tells

## Legacy reduction [12271]

[12272] AI-assisted modernisation, documentation, automation

[12275] Phase 3 · Embed Months 10–18

## Public trust framework [12280]

[12281] Transparent registers, explainability standards, citizen comms

## Recognition & visibility [12283]

[12284] Awards, case-study library, cross-government showcases

## Continuous learning [12286]

[12287] Evergreen curriculum, AI-native onboarding, horizon scans

[12290] 100%

[12291] team with baseline AI literacy

## ≥10 [12293]

[12294] measurable use-cases live

[12296] 0

[12297] proprietary lock-in

## DPIA [12299]

[12300] embedded in every build

## Named [12302]

[12303] civil servants celebrated

## The sequence — three, six, twelve, twenty-four months [12304]

[12307] 3 months

## Establish preconditions [12308]

[12310] Reachability audit and permissions remediation

[12311] Publish agent-register schema and intake form

[12312] Consumption dashboards and per-agent caps

[12313] Agree retention and FOI position

[12315] 6 months

## Govern [12316]

[12318] Operate the register; classify every agent by tier

[12319] Apply assurance tiers; define the orphaned-agent process

[12320] Secure exit, portability and audit rights

[12321] Publish an evaluation method standard

[12323] 12 months

## Integrate [12324]

[12326] Fund adoption as a standing operating line

[12327] Publish unit economics per production agent

[12328] Unify information and agent governance

[12329] Publish one outcome measure, not an activity

[12331] 24 months

## Federate [12332]

[12334] Share registered agent patterns across bodies

[12335] Aggregate demand for small public bodies

[12336] Prove exit is real via a live substitution

[12337] Publish a community value evaluation

[12338] Sequence matters more than speed: permissions before scale, register before governance claims, cost instrumentation before volume. Recognition runs throughout — named people, visible work, credited contributions, minister-level visibility on citizen wins.

[12339] Back to the contents · Suggest a correction (opens GitHub)

[12351] Responsible AI · people and adoption

## People at the centre: the adoption, capability and change model [12352]

[12353] Eight segments that turn responsible AI into lasting value, with accessibility, guest access and ways-of-working impact. Teams, roles, the academy and the adoption journey in this part go deeper on each.

[12357] Build capability

## Leadership and sponsorship [12358]

[12360] Clear vision and strategic alignment

[12361] Senior sponsor and accountable owners

[12362] Cross-government collaboration

[12363] Adequate funding and resources

[12364] Visible role modelling

[12366] Build capability

## Skills, learning and enablement [12367]

[12369] Role-based learning pathways

[12370] Practical, hands-on training

[12371] Prompts, skills and agent use

[12372] Protected learning time

[12373] Ongoing refresher content

[12375] Engage and empower

## Communication and engagement [12376]

[12378] Clear, consistent messaging

[12379] What is approved, and why

[12380] How to get help and give feedback

[12381] Real examples and case studies

[12382] Address concerns and misinformation

[12384] Engage and empower

## Champions and communities [12385]

[12387] Local AI champions and networks

[12388] Communities of practice such as xGov

[12389] Share prompts, skills and patterns

[12390] Connect pilot teams and early adopters

[12391] Recognise success

[12393] Support and sustain

## Support and service management [12394]

[12396] Clear support model and service levels

[12397] Guidance, FAQs and how-to resources

[12398] Escalation for issues and incidents

[12399] Access to specialist expertise

[12400] Integration with IT and business support

[12402] Support and sustain

## Measurement and value [12403]

[12405] Track adoption and meaningful use

[12406] Measure quality, productivity and outcomes

[12407] Include accessibility and inclusion benefits

[12408] Monitor cost and environmental impact

[12409] Report value to stakeholders

[12411] Learn and improve

## Continuous improvement [12412]

[12414] Capture feedback and lessons

[12415] Share good practice across government

[12416] Update guidance, training and controls

[12417] Respond to product and model changes

[12418] Reassess risks and opportunities

[12420] Learn and improve

## Workforce, ways of working and inclusion [12421]

[12423] Understand role impacts and job changes

[12424] Support new ways of working

[12425] Engage staff and representative groups

[12426] Promote inclusive and accessible design

[12427] Address capability gaps and change fatigue

## Accessibility and workplace adjustments [12430]

[12431] Two questions, kept separate: is the AI tool itself accessible, and can AI support someone as a workplace adjustment? Request either through your line manager or the adjustments route. Every tool needs a non-AI alternative.

## Guest and cross-tenant access [12433]

[12434] Do not rely on meeting recaps for guests. Store resources where external participants can reach them, set permissions deliberately and provide an accessible copy.

## Transcription dictionary [12436]

[12437] Maintain a controlled glossary of cross-government terms and acronyms so that transcription and summaries get names right.

## Employment and workplace effects [12439]

[12440] Include workload, role, delegation, autonomy, training and workplace-adjustment impact in the adoption assessment, and monitor them after rollout.

## Enablers across the model [12443]

[12444] Policy and governance Approved tools and data Security and privacy Accessible by design Sustainability by design Cost control and FinOps Supplier and model management Change management Cross-tenant and external working Legal, ethical and regulatory compliance

## Desired outcomes [12456]

## Greater confidence [12459]

## Higher productivity and quality [12462]

## More inclusive services [12465]

## Reduced environmental impact [12468]

## Better outcomes for citizens [12471]

## Ways-of-working impact questions [12472]

[12474] Could it replace developmental delegation or professional review?

[12475] Could it create meeting, message or document overload?

[12476] How will roles and responsibilities change?

[12477] What training and protected time are required?

[12478] How will non-users be affected?

[12479] What workforce evidence will be monitored?

[12482] Worked example

[12484] Worked example

[12485] Portfolio reporting grounded in the Graph.

[12487] Worked example

[12488] The same day run on Claude Projects and scheduled tasks.

[12490] Worked example

[12491] Whole-portfolio reading in one context.

[12493] Training film

[12494] The Microsoft journey, end to end.

[12496] Training film

## Twin journeys film → [12497]

[12498] Both stacks, the same functions.

[12500] Comparison

## Twin Capability Atlas → [12501]

[12502] 39 capabilities with residency and FinOps layers.

[12503] Back to the contents · Suggest a correction (opens GitHub)

[12515] People and adoption · inclusion

## AI as assistive technology, designed for everyone [12516]

[12517] How AI tools help and hinder people across neurotypes at work, how to talk about them without a deficit framing, and the questions that are still open. Build one version that works for everyone, layered, rather than a separate one. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

## What people say helps [12520]

## I like clear structure and knowing what to expect [12523]

[12524] “I want to know exactly what the tool will and won't do before I rely on it.”

[12525] Helps: Ask the tool to explain its steps before it does something complex; Build a short personal routine for how you use it, and stick to it

[12527] Watch for: Answers can vary between attempts — plan for that, it's not a fault

## Busy screens and long text wear me out fast [12530]

[12531] “Too much on the page at once and I lose track of what matters.”

[12532] Helps: Ask for short answers first, then "tell me more" only if needed; Turn off extra plug-ins or add-ons you don't use

[12534] Watch for: Take a proper break between tasks — don't stack requests back to back

## I want the tool to say exactly what it means [12537]

[12538] “I find it easier when nothing is left for me to guess or read between the lines.”

[12539] Helps: Ask it directly: "say this in plain, literal terms"; Ask it to list assumptions it's making, not just the answer

[12541] Watch for: General advice about people or feelings can be too generic — check it fits your actual situation

## My focus and energy shift a lot, hour to hour [12544]

[12545] “Some days I fly through things, other days the same task feels impossible.”

[12546] Helps: Let AI help you start a task — a blank page is often the hardest part; On a low-energy day, it's fine to lean on it more than usual

[12548] Watch for: On a good day, try the task yourself first — it keeps your own skill sharp

## I catch small details well, but time pressure throws me [12551]

[12552] “Give me time and I'll spot the error. Rush me and I'll miss it.”

[12553] Helps: Use AI for a fast first pass, then take your own unhurried time to check it; Ask it to flag its own uncertain bits so you know where to look closest

[12555] Watch for: Don't let a fast deadline push you into skipping your own check

## I feel uneasy sharing work before it's ready [12558]

[12559] “I'd rather get it right privately than be seen figuring it out.”

[12560] Helps: Use the tool as a private practice space before anything goes to a colleague; It's fine to use it purely to build confidence, not just to produce a final version

[12562] Watch for: Don't share more personal detail with it than the task actually needs

## Communicating about AI tools [12564]

[12566] Don't build two versions (one for neurodiverse staff, one for everyone else) . Managers' attitudes shaped use and control-group awareness was low; a split communication badges it as a 'special accommodation', undersells it to neurotypical staff and stigmatises it for neurodiverse staff.

[12568] Lead with the curb-cut framing, not the deficit framing . Outcome language ('levelled the playing field'), not diagnosis language. Avoid 'crutch' language even to knock it down.

[12570] Layer the detail rather than write two documents: a one-page plain-language summary with the fuller evidence base undern eath.

[12572] Talking to your manager: frame it in terms of outcome, not diagnosis ('this helps me structure written work faster and m ore confidently'); no need to disclose a condition; if it functions as a genuine accessibility aid, say so explicitly so it is treated like any reasonable adjustment if the licence is reviewed.

[12574] For managers: neutral, informed encouragement - not enthusiasm or scepticism - produces the best outcomes for the whole team.

[12576] one layout/format alone will not meet everyone's needs (some autism sub-types are polar oppos ites); present tailored around common characteristics or a compromise that best serves all; Easy Read version is a must. This partly overrides the turn-5 'one layered document' advice: the turn-11 solution is a characteristics poster plus a separate Easy Read version.

## Deployment and licensing [12578]

[12580] Don't blanket-licence . Target by task profile first, need second (admin-heavy/high-information roles benefited; Legal and Policy did not).

[12582] Fund self-led exploration over formal training sessions; budget time, not just courseware (p < 0 .01 at 2+ hours self-led use).

[12584] Plan continuity, not just onboarding . If a licence functions as assistive technology for someone, treat withdrawal with the same seriousness as withdrawing any other reasonable adjustment, not as an IT asset reclaim.

[12586] Build QA expectations that vary by task, not a blanket 'always check' policy nobody follows . Drafting/summarising: light-touch spot-check. Data analysis and anything feeding a decision: mandate verification (DBT observed tasks showed Copilot users did worse on Excel analysis).

[12588] Track dependency alongside satisfaction in any evaluation commissioned; none of the three government evaluations measure d these jointly at individual level - a genuine gap.

[12590] Cost transparency matters to uptake: address ethical/environmental concerns rather than dismiss them .

## Keeping research current [12592]

[12594] Model-dependent findings Describe a specific model's failure mode at a specific point in time (e.g. 2024 ChatGPT advising an autistic user to 'just walk up and start talking'). Testable claims, not settled facts. Re-run the equivalent prompt against current models before relying on it (five-minute check). Tag [model-dependent — re-verify before citing]; note model and test date; anything older than about six months needs a fresh spot-check.

[12596] Structural (human-factors and organisational) findings About people and institutions, not the model. Safe to build governance policy on now. Tag [structural — durable].

[12598] More fluent models are more persuasive when wrong Newer, more fluent, more agreeable models are not guaranteed to reduce dependency risk — they may increase it, because a model better at sounding authoritative and more consistently agreeable is more persuasive when wrong. 'The tooling has evolved' is a reason to scrutinise sycophancy and over-reliance harder, not to trust more.

## Open questions [12600]

[12602] Is chatbot-based support for autistic people legitimate assistive technology, or a paternalistic fix aimed at the wrong target? For: Autistic users in the CMU study chose this themselves, unprompted by clinicians, because existing workplace support was inadequate or absent — 'it's the only thing I trust.' Respecting autonomy means respecting that choice, not gatekeeping it behind professional approval. Against: A review Begel co-authored found 90% of HRI research on autism excluded autistic perspectives — a documented history of building 'solutions' nobody with autism wanted. Chatbot advice-giving individualises a structural workplace-inclusion failure: asking an autistic employee to get better at masking via AI coaching instead of making the workplace accessible treats the symptom.

[12604] Does satisfaction without measured productivity gain justify public licensing spend? For: DBT frames wellbeing, confidence and inclusion as legitimate outcomes independent of output volume; a more sustainable, less anxious workforce is a defensible use of public money, especially for a protected characteristic. Against: DBT's own conclusion: no evidence time savings led to improved productivity; value for money unassessed. Licences justified by self-reported satisfaction are weak in any Treasury-facing review and risk being read as subsidised comfort.

[12606] Does normalising AI-mediated compensation reduce institutional pressure to provide genuine accommodation? For: (risk is real) If AI drafting becomes the default fix for a dyslexic employee, the organisation has less incentive to fund proper adjustments, job redesign or human support - AI is cheaper and needs no line-management change. Against: Assumes accommodation is zero-sum; DBT and Capita evidence shows the tool works alongside existing adjustments and often surfaces previously invisible/unfunded need - additive, not replacement.

[12608] Universal rollout versus targeted, disclosure-based provisioning? For: (universal) Curb-cut argument: benefits accrue to non-native English speakers, hearing- and vision-impaired staff and many neurotypical staff (80% of use cases rated satisfactory across DBT). Targeting requires disclosure, which carries stigma risk (CMU respondents worried). Against: Untargeted rollout produced DBT's finding that Legal and Policy roles got minor benefit while absorbing the same licence cost and verification burden; also removes a comparison group, making it harder to tell real accessibility benefit from placebo/novelty.

[12610] Is self-report evidence trustworthy? For: Confidence, cognitive load and satisfaction are inherently subjective - self-report is the correct instrument. DBT triangulated with interviews and observed tasks and found broadly consistent patterns. Against: Respondents volunteered (70% of DBT) or knew they were evaluated on a tool their employer promoted - social-desirability and novelty bias. The only non-self-report measure (observed tasks) contradicted diary data on Excel analysis and PowerPoint quality.

[12612] Is it responsible to act on this evidence at all, given how fast tooling changes? For: (act now) Waiting for model-current research means never acting. Structural findings (manager influence, training modality, compensatory-vs-substitutive risk) are durable - acting on those is low-risk. Against: The most policy-relevant claims (advice quality, hallucination frequency, persuasiveness/over-reliance risk) are model-dependent and most likely wrong by the time a document reaches a minister. Citing a 2024 finding as current without re-testing is a factual risk.

[12614] Back to the contents · Suggest a correction (opens GitHub)

