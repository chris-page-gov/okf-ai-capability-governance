---
type: publisher-section
title: Fund and buy
status: draft
sources:
- title: Fund and buy
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-fund-and-buy
x-dom-section: part-fund-and-buy
---

# Fund and buy

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-fund-and-buy)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[8584] Part 6 of 12 · 4 chapters

## Fund and buy [8585]

[8594] Cost, value & investment · illustrative figures

## Make every AI pound count [8595]

[8596] A continuous cycle that connects business value, cost efficiency and responsible use. Align, optimise, govern — then deliver and reinvest. Figures on this page are illustrative: replace them with your own contract and telemetry data.

[8602] 1 Forecast & plan Understand demand, use cases, models and unit economics.

[8605] 2 Allocate & budget Allocate costs, set budgets and guardrails.

[8608] 3 Observe & measure Monitor usage, costs, quality and performance in real time.

[8611] 4 Analyse & evaluate Analyse spend, quality, outcomes and business value by use case.

[8615] 5 Optimise & improve Optimise models, workloads, prompts and architecture.

[8618] 6 Report & transparency Report on spend, value, carbon and compliance.

[8621] 7 Reinvest or rebalance Reinvest in high-value initiatives or rebalance priorities.

[8624] 8 Govern & control Review policies, controls and risks. Adapt and evolve.

## What we manage [8629]

[8630] Consumption costs Tokens, credits, API calls, capacity, compute, storage, network

[8632] Technology costs Models, platforms, connectors, licences, infrastructure

[8634] Adoption costs Training, change, champions, workflow redesign, support

[8636] Data & integration costs Data preparation, quality, integration, access and governance

[8638] Assurance & risk costs Security, privacy, testing, human review, audits, incident response

[8640] Operational costs Monitoring, tooling, run support, maintenance, model updates

[8642] Transition & exit costs Migration, parallel run, data portability, vendor switching

## Value we deliver [8645]

[8646] Better public services Improved outcomes for citizens

[8648] Productivity gains Time saved, efficiency improved

[8650] Quality & consistency Fewer errors, higher quality outputs

[8652] Risk reduction Stronger controls, fewer incidents

[8654] Transparency & trust Clear oversight, explainable decisions

[8656] Sustainable impact Lower waste, optimised resources, lower carbon

## Key practices [8659]

[8661] Tag and track by use case

[8662] Set budgets and alerts

[8663] Right-size models and workloads

[8664] Reduce token waste

[8665] Automate policies and guardrails

[8666] Review value regularly

[8667] Collaborate across business, technology, finance and security

## Who works together [8668]

[8669] Business owners Product & delivery Finance / FinOps Engineering & data Security & privacy Procurement & commercial Operations & service management

## Unit economics: what one interaction costs, and what it returns [8677]

[8678] Total cost per interaction = token cost + infrastructure + tool and API cost + human effort + overhead. Multiply by volume for the period, and set it against the value delivered. The starting values are the source model's worked example.

## Cost inputs [8681]

## Cost per interaction [8683]

[8684] Input tokens 2,000 tokens @ £0.002 / 1K £0.0040

[8688] Output tokens 1,000 tokens @ £0.006 / 1K £0.0060

[8692] Tool / API calls External calls and connectors £0.010

[8696] Infrastructure Compute, storage and network allocation £0.0050

[8700] Human effort 5 minutes @ £1 / min £5.00

[8704] Overheads Operations, support and monitoring £0.500

[8708] Total cost per interaction £5.53

[8711] × 1,000 interactions in the period £5,525.00

## Value per interaction [8715]

[8716] Total value £20.00

[8719] NET VALUE £14.48 RETURN 262%

[8726] Value to cost ratio 3.6× · value across the period £20,000.00. Human review time is usually the largest single line — design it down before changing model.

## Workload / request [8730]

[8731] User or system initiates a task

## Examples [8732]

[8734] Summarise document

[8735] Draft policy response

[8736] Code generation

[8737] Case classification

[8738] Data analysis

## Tokens & model consumption [8741]

[8742] Tokens processed by the model

## Components [8743]

[8745] Input tokens (prompt)

[8746] Output tokens (response)

[8747] Reasoning / tool use tokens

[8748] Cached tokens

[8749] Embedding tokens

## Cost drivers [8752]

[8753] What drives the cost of the interaction

## Cost elements [8754]

[8756] Model pricing per 1K tokens

[8757] Context length

[8758] Frequency & volume

[8759] Tool / API calls

[8760] Storage & compute

[8761] Network / egress

## Quality & outcomes [8764]

[8765] Quality of output and outcome achieved

## Quality factors [8766]

[8768] Accuracy & relevance

[8769] Hallucination rate

[8770] Completeness

[8771] Safety & compliance

[8772] User satisfaction

[8773] Rework rate

## Human effort & rework [8776]

[8777] Human time to review, edit or redo

## Effort factors [8778]

[8780] Review time

[8781] Editing / refinement

[8782] Additional research

[8783] Escalations

[8784] Rework / repeat runs

[8785] Approval steps

## Business value [8788]

[8789] Value delivered to the organisation

## Value types [8790]

[8792] Time saved

[8793] Productivity gain

[8794] Better decisions

[8795] Risk reduction

[8796] Improved quality

[8797] Citizen / service impact

## Cost and value optimisation levers [8800]

[8803] Right model Match quality needs to the most cost-effective model

[8806] Prompt engineering Optimise prompts to reduce tokens and improve outcomes

[8809] Context management Right-size context, use retrieval and caching

[8812] Routing & policies Route to the best model or tier based on cost and risk

[8815] Caching & reuse Reuse responses, embeddings and results

[8818] Evaluation & guardrails Measure quality and set thresholds to avoid waste

[8821] FinOps controls Budgets, alerts, showback / chargeback and governance

## KPIs to track [8824]

[8825] Cost per 1,000 tokens Cost per interaction Cost per outcome Quality score Rework rate Time saved ROI / value per £ Budget adherence Token utilisation efficiency

## Six cost layers, each with an owner [8835]

[8836] Fair, transparent, actionable. Allocate costs across the organisation to drive accountability, optimise spend and demonstrate value. Without a named owner, a layer is not allocated — it is absorbed.

## LAYER 1 [8839]

## Enterprise foundation [8840]

[8842] Core platform and shared capabilities enabling all AI use.

[8843] Azure / cloud baseline

[8844] Identity & security

[8845] Networking

[8846] Monitoring platform

[8847] Central services

[8848] OWNER CTO / enterprise Direct allocation by actual cost

## LAYER 2 [8852]

## Shared platform services [8853]

[8855] Reusable services consumed by multiple products and teams.

[8856] AI platforms / services

[8857] Data platforms

[8858] Model hosting

[8859] Logging & observability

[8860] Shared tools & libraries

[8861] OWNER Platform / centre of excellence Cost pools and apportionment drivers

## LAYER 3 [8865]

## Product / service [8866]

[8868] AI capabilities built into a product or service.

[8869] Feature development

[8870] Data preparation

[8871] Models & fine-tuning

[8872] QA & evaluation

[8873] Product support

[8874] OWNER Product / service owner Showback or chargeback to products

## LAYER 4 [8878]

## Team / workload [8879]

[8881] Teams running workloads to deliver features or operations.

[8882] Training / inference

[8883] API calls / tokens

[8884] Experimentation

[8885] Environments

[8886] Team tooling

[8887] OWNER Team lead Team budgets and workload tagging

## LAYER 5 [8891]

## Use case / consumer [8892]

[8894] A specific AI use case delivering value to a defined user group.

[8895] End-user interactions

[8896] Business process cost

[8897] Human-in-the-loop

[8898] Quality assurance

[8899] Change & adoption

[8900] OWNER Use case owner Usage-based allocation (tokens, calls, transactions)

## LAYER 6 [8904]

## End user / beneficiary [8905]

[8907] Cost associated with delivery to end users or citizens.

[8908] Per user / transaction

[8909] Support & helpdesk

[8910] Feedback & outcomes

[8911] Accessibility support

[8912] Service impact

[8913] OWNER Business / service Unit cost per user or beneficiary

## Allocation flow [8918]

## 1. Capture actual costs [8919]

## 2. Tag & classify costs [8920]

## 3. Allocate using defined rules [8921]

## 4. Report & analyse [8922]

## 5. Optimise & act [8923]

## 6. Value realised [8924]

## What we gain [8926]

[8928] Clear visibility of total cost

[8929] Fair and consistent allocation

[8930] Informed decision making

[8931] Cost optimisation

[8932] Accountability and ownership

[8933] Evidence of value and return

## Data & enablers [8935]

[8937] Consistent tagging & metadata

[8938] Usage & cost data feeds

[8939] Access & permissions

[8940] Cost ownership model

[8941] Policies & standards

[8942] Automation & integration

[8943] Data quality & validation

## Governance & controls [8945]

[8947] Cost policies & guardrails

[8948] Budgeting & approvals

[8949] Monitoring & alerts

[8950] Audit & reconciliation

[8951] Roles & responsibilities

## Visible costs are the tip of the iceberg [8952]

[8953] Licences, tokens and compute are usually budgeted and tracked, and are only a fraction of the total. The hidden lines below the waterline determine real value and long-term success.

## Licences & subscriptions [8958]

## Token / usage charges [8962]

## Cloud compute & storage [8966]

## Hidden costs — what is often overlooked [8968]

[8971] Data & information

[8973] Data quality & remediation

[8974] Information architecture

[8975] Permissions & access

[8976] Metadata & cataloguing

[8978] Integration & engineering

[8980] Connectors & APIs

[8981] Workflow redesign

[8982] Systems integration

[8983] Environment set-up

[8985] Security & compliance

[8987] Security controls

[8988] Privacy & DPIAs

[8989] Compliance & legal

[8990] Pen testing & assurance

[8992] Adoption & change

[8994] Training & enablement

[8995] Champions & local support

[8996] Communications

[8997] Workflow & culture change

[8999] Assurance & evaluation

[9001] Model evaluation

[9002] Bias, fairness & robustness

[9003] Human review effort

[9004] Audit & red teaming

[9006] Operations & support

[9008] Monitoring & observability

[9009] Incident response

[9010] Helpdesk & support

[9011] Continual improvement

[9013] FinOps & management

[9015] Cost monitoring & allocation

[9016] Forecasting & optimisation

[9017] Showback / chargeback

[9018] Demand management

[9020] Governance & risk

[9022] Policies & standards

[9023] Risk management

[9024] Third-party risk

[9025] Records & retention

[9027] Workforce & roles

[9029] Role evolution

[9030] Skills development

[9031] Capacity & backfill

[9032] HR & employee relations

[9034] Sustainability

[9036] Energy & carbon impact

[9037] Efficient model usage

[9038] Sustainable operations

[9039] Reporting & metrics

[9041] Transition & exit

[9043] Parallel running

[9044] Data portability

[9045] Supplier exit costs

[9046] Migration & decommission

[9048] Value realisation

[9050] Benefit tracking

[9051] Outcome measurement

[9052] Realisation management

[9053] Continuous feedback

[9054] Total cost of AI = technology + data + people + process + assurance + operations + commercial. Budget for the full cost. Manage it actively. Realise the value.

## What drives hidden costs [9057]

[9060] Complexity Many moving parts across technology, data and people

[9063] Change Workflows, roles and ways of working must adapt

[9066] Risk & assurance Higher risk requires stronger controls and evidence

[9069] Scale & usage More users, data and interactions increase ongoing costs

[9072] Governance Policies, oversight and reporting add essential investment

## Make the hidden visible [9075]

## Map all cost categories [9076]

## Track usage & value [9077]

## Allocate transparently [9078]

## Optimise continuously [9079]

## Review & adapt [9080]

## Beyond licences: adoption as an investment line [9081]

[9082] AI adoption is a long-term investment across technology, people, process, data and assurance. Sustainable value comes from funding the whole system, not the licence.

## 1. Technology [9085]

[9087] Licences & subscriptions

[9088] Tokens / consumption

[9089] Models & platforms

[9090] Infrastructure & cloud

[9091] Tools & integrations

## 2. People & adoption [9093]

[9095] Training & skills

[9096] Champions & support

[9097] Communications

[9098] User research

[9099] Protected time

## 3. Process & change [9101]

[9103] Workflow redesign

[9104] New ways of working

[9105] Governance processes

[9106] Service redesign

[9107] Organisational change

## 4. Data & information [9109]

[9111] Data quality & remediation

[9112] Information management

[9113] Permissions & access

[9114] Knowledge management

[9115] Taxonomy & metadata

## 5. Assurance & risk [9117]

[9119] Security & privacy

[9120] Responsible AI

[9121] Testing & evaluation

[9122] Human review

[9123] Audit & compliance

## 6. Operations & continuous improvement [9125]

[9127] Monitoring & observability

[9128] Support & maintenance

[9129] Incident management

[9130] Benefit measurement

[9131] Iteration & enhancement

[9134] 1. Discover & plan Identify needs, use cases and business value. Build the investment case.

[9137] 2. Pilot & experiment Test, learn and validate value, risk and cost. Measure and refine.

[9140] 3. Scale & adopt Roll out to teams and services. Build capability.

[9143] 4. Operate & optimise Monitor usage, value and cost. Optimise models and processes.

[9146] 5. Sustain & evolve Continually improve, adapt and reinvest for future value.

## Why invest [9150]

[9152] Improve public services and citizen outcomes

[9153] Increase productivity and efficiency

[9154] Enhance decision making with better information

[9155] Reduce risk and strengthen compliance

[9156] Drive innovation and long-term value

## Where value is realised [9158]

[9160] Faster, more consistent service delivery

[9161] Better experience for users and citizens

[9162] Lower cost to serve over time

[9163] Improved quality, accuracy and compliance

[9164] Stronger resilience and adaptability

## Funding approaches [9166]

[9167] Central funding Departmental budgets Programme funds Shared services Outcome / value based funding Public-private partnerships

## Measure what matters [9174]

[9175] Adoption rate Usage & engagement Quality & accuracy Cost per transaction Time saved Outcome & impact

## Without full investment [9183]

[9185] Under-adoption and poor outcomes

[9186] Hidden costs and budget shocks

[9187] Security, compliance and quality risks

[9188] Duplication and technical debt

[9189] Lost trust and stalled programmes

[9190] Back to the contents · Suggest a correction (opens GitHub)

[9202] FinOps & models

## A builder's design choice sets a budget holder's cost [9203]

[9204] AI cost is a portfolio, not a licence line. You are billed per token, in and out — roughly four characters or three-quarters of a word each; an A4 page is 600–800 tokens. Micro-costs stack when an agent runs on repeat. Report by service, product, agent, owner, model and cost driver; showback before chargeback; no expenditure classification without finance-led assessment.

[9206] Licences Credits Model calls Compute Storage Connectors Monitoring Evaluation Adoption & training Remediation Security Human review Support

## How the two main vendors now charge, and where they process [9223]

## Published list positions at 19 October 2026 [9225]

## Microsoft Copilot [9228]

[9229] Cost: a per-user licence ($30 per month list) covers Chat and Copilot in the Office apps. Cowork, Code, Autopilot and frontier models consume Copilot Credits at $0.01 each on pay-as-you-go. Agent security for custom agents needs Agent 365.

[9231] Residency: follows the tenant's Microsoft 365 geography. Web grounding, subprocessor models (Claude, Grok) and Code apps on Managed Runtime need separate checks.

## Anthropic Claude [9234]

[9235] Cost: a seat per user, plus usage at token rates by model (Opus 5.5 lists at $4 input / $20 output per million tokens). Model routing, effort settings and prompt caching are the main levers.

[9237] Residency: set by deployment route. Anthropic-processed with a US-only option, or in-region through Bedrock, Google Cloud or Foundry. Connectors carry the content they fetch to the model.

## See all 39 capabilities compared in the capability atlas → [9239]

## Cost lab — the same job, five model classes [9240]

[9241] Illustrative list prices from the "Where your AI spend goes" explainer (2025), GBP per 1,000 tokens — verify current pricing before any decision. Non-English output can cost more: the same words take more tokens.

[9242] GPT-4o class (OpenAI) Balance of quality and tone £0.017 per run £1.71 per month

[9253] Claude Haiku class (Anthropic) Cost-efficient, high-volume work

[9256] £0.0043 per run

[9260] £0.427 per month

[9265] Claude Opus class (Anthropic) Deep, high-context threads

[9268] £0.026 per run

[9272] £2.56 per month

[9277] Mixtral class (Mistral) · cheapest Ultra-low cost; needs prompt tuning

[9280] £0.0032 per run

[9284] £0.320 per month

[9289] Gemini Pro class (Google) On par with GPT-4o by usage tier

[9292] £0.017 per run

[9296] £1.71 per month

[9299] Design levers before model choice: reuse outputs, cache repeated answers, trim inputs, use plain logic before calling a model.

## Four lenses of value — the estate case, measured and modelled [9300]

## Reclaimed time [9304]

## ~£0.5M–£1.6M / yr at ~680 staff [9306]

[9308] A 10% findability gain on ~1.8 hrs/day spent searching. The big lever — and it can cover the licence bill 2.5–8× over ("earned allocation").

[9309] Storage cost ~£1.5k / yr Effectively £0 marginal under bundled M365. Symbolic.

## Environmental [9315]

## ~9 TB ≈ 55–360 kg CO₂e / yr [9317]

[9319] Modest; aligns with Greening Government; curbs future growth.

## Wellbeing [9322]

## 117 emails/day · ~23 min to refocus [9324]

[9326] Interrupted every ~2 minutes; 48% find work chaotic and fragmented. The human case.

[9327] Rules that hold: require total-cost and portability evidence before scaling any tool or agent · per-agent consumption caps and anomaly alerts · unit economics per production agent published within 12 months · value measured through the evidence chain: activity → output quality → workflow change → organisational outcome → public outcome.

[9329] Back to the contents · Suggest a correction (opens GitHub)

[9341] Commercial barriers · illustrative default scores

## Barriers that slow adoption, increase cost and limit sustainability [9342]

[9343] Score each barrier by its impact and its likelihood in your context. Risk score is impact × likelihood; the band follows the published scale. The defaults are the sector-level assessment — change them and the bands move.

## Critical [9347]

## High [9349]

## Medium [9351]

## Low [9353]

[9354] 4 barriers are critical and 8 high in this scoring. Address these before scale.

[9356] BARRIER IMPACT LIKELIHOOD I×L RISK TYPICAL CURRENT STATE

[9365] Licensing clarity Unclear boundaries between included features, credits, capacity and pay-as-you-go.

## Critical [9370]

[9373] Moving boundaries

[9374] Preview versus general availability confusion

[9377] Cost & usage transparency Limited access to usage data, telemetry, forecasting and billing detail.

## Critical [9382]

[9385] Trials paused

[9386] Inability to model total cost of ownership

[9389] Price predictability Usage-based pricing makes budgets volatile and hard to forecast.

## Critical [9394]

[9397] Variable token costs

[9398] Capacity uncertainty

[9401] Supplier / platform lock-in High switching costs, proprietary connectors and formats.

## Critical [9406]

[9409] Proprietary ecosystems

[9410] Data portability gaps

[9413] Telemetry & audit rights Lack of contractual rights to monitor, audit and export operational data.

## High [9418]

[9421] Limited audit trails

[9422] Evidence gaps

[9425] Data ownership & IP Uncertainty over prompts, outputs, data use, training and generated code.

## High [9430]

[9433] IP ambiguity

[9434] Data use concerns

[9437] Data residency & jurisdiction Data and model processing across jurisdictions may create compliance risk.

## High [9442]

[9445] Cross-border processing

[9446] Sovereignty concerns

[9449] Service level & support Unclear SLAs, responsibilities and support across multiple products and models.

## High [9454]

[9457] Shared responsibility

[9458] Support fragmentation

[9461] Interoperability & portability Limited open standards, export options and easy integration with other systems.

## High [9466]

[9469] Custom connectors

[9470] Integration complexity

[9473] Commercial complexity Complex contracts, overlapping costs, multiple components and change over time.

## High [9478]

[9481] Complex terms

[9482] Change without notice

[9485] Small body disadvantage Smaller organisations lack commercial leverage and specialist expertise.

## High [9490]

[9493] Limited negotiation power

[9494] Resource constraints

[9497] Exit & transition risk Uncertain exit costs, data extraction, migration and parallel running.

## High [9502]

[9505] Exit complexity

[9506] Transition cost risk

[9507] Bands are computed from the published impact × likelihood scale. Two rows on the source board carry a stated risk level that does not match its own band scale; the computed band is shown here.

## Common examples [9510]

[9512] Trial paused due to lack of cost / usage data

[9513] Unexpected charges from token consumption

[9514] Unable to export data or prompts

[9515] Contract terms prevent model substitution

[9516] Data processed outside approved regions

[9517] No audit rights or limited visibility

[9518] SLA ambiguity across multiple services

[9519] Custom integrations create lock-in

## Actions to reduce risk [9521]

[9523] Consolidate demand and negotiate as one government

[9524] Demand transparency, telemetry and audit rights

[9525] Use open standards and ensure portability

[9526] Define clear data ownership and IP terms

[9527] Require model and data location assurance

[9528] Build modular architectures and exit plans

[9529] Share commercial intelligence across the community

[9530] Support smaller bodies with frameworks and guidance

## Build, buy, configure or share? [9531]

[9532] Match the approach to the need, risk, control, value and total cost. Decide wisely, start small, scale with confidence — and revisit the decision as needs, risk and technology evolve.

[9535] 1. Define the need What problem are we solving?

[9538] 2. Assess context Users, data, risk, regulation, criticality

[9541] 3. Evaluate options Use the criteria to compare

[9544] 4. Decide & plan Select approach, plan delivery

[9547] 5. Review & adapt Measure outcomes, learn and adjust

## Use platform / pre-built [9552]

[9554] Moderate complexity / risk

[9555] Use existing platform features or pre-built agents with configuration.

## Best for [9558]

[9559] Common needs, moderate risk, fast value

## You get [9561]

[9563] Faster delivery

[9564] Lower cost

[9565] Built-in updates & support

## Considerations [9567]

[9569] Limited customisation

[9570] Platform roadmap dependency

[9571] Data & permission alignment

## Examples [9573]

[9574] Microsoft 365 Copilot, pre-built agents, Copilot Studio templates, AppSource solutions

## Sample scoring matrix · 1 low to 5 high [9577]

[9578] Strategic value Risk & assurance Control & flexibility Total cost (TCO) Time to value Reusability & scale AVG Personal configuration 2 2 4 5 5 1 3.2 Use platform 3 3 3 4 4 3 3.3 Configure / extend 4 3 4 3 3 4 3.5 Build custom 5 4 5 2 2 3 3.5 Share / buy 4 4 3 4 4 5 4.0

[9626] Very high (strong) High (good) Medium (acceptable) Low (weak) Very low (poor)

## Key questions to help decide [9634]

[9636] What is the impact if this goes wrong?

[9637] What data will it access or generate?

[9638] Do we need full control or can we share?

[9639] Is there an existing solution we can reuse?

[9640] What is the total cost over the lifecycle?

[9641] How quickly do we need value?

## The continuous review loop [9643]

[9644] 1. Monitor usage, value and risk 2. Evaluate outcomes and costs 3. Learn and improve approach 4. Adapt or reinvest

## Common outcomes [9649]

[9651] Right solution for the need

[9652] Controlled risk and spend

[9653] Faster delivery and adoption

[9654] Reusable assets and knowledge

[9655] Better outcomes for citizens

## From community intelligence to better contracts [9656]

[9657] A continuous loop that turns real-world experience across government into stronger commercial engagement, better terms and improved public value. Open once, use many times.

[9659] Inputs

[9660] Departments & public bodies Devolved governments Local government & combined authorities Health & care Police, justice & emergency services Education & skills Regulators & public agencies Communities of practice & forums Audits, reviews & external reports Financial & FinOps data

## Community intelligence [9674]

[9676] Live problems

[9677] Use cases & pilots

[9678] Costs & usage data

[9679] Risks & barriers

[9680] Lessons learned

## Consolidate & analyse [9683]

[9685] Thematic analysis

[9686] Prioritise issues

[9687] Identify patterns

[9688] Evidence strength

[9689] Impact assessment

## Define requirements & questions [9692]

[9694] Functional needs

[9695] Non-functional needs

[9696] Data & telemetry

[9697] Interoperability

[9698] Commercial terms

## Engage suppliers & market [9701]

[9703] Share requirements

[9704] Test assumptions

[9705] Request evidence

[9706] Validate options

[9707] Explore innovation

## Refine terms & frameworks [9710]

[9712] Contract clauses

[9713] Pricing & models

[9714] SLAs & commitments

[9715] Exit & portability

[9716] Risk & liability

## Implement & monitor [9719]

[9721] Deploy solutions

[9722] Monitor performance

[9723] Track usage & cost

[9724] Manage risks

[9725] Capture issues

## Feedback & share [9728]

[9730] Share outcomes

[9731] Publish lessons

[9732] Update patterns

[9733] Support others

[9734] Improve guidance

## Evolve & influence [9737]

[9739] Refine priorities

[9740] Influence roadmaps

[9741] Shape market

[9742] Strengthen policy

[9743] Drive innovation

[9745] Outputs

[9746] Better contracts & terms Cost transparency & predictability Stronger controls & governance Interoperability & portability Improved supplier performance Shared patterns & reusable assets Evidence-based policy & standards Better outcomes for citizens

## Guiding principles [9757]

[9758] Evidence led Real experience, not assertion

[9761] Collaborative & inclusive Across departments, nations and sectors

[9764] Fair & proportionate Terms matched to risk and scale

[9767] Transparent & accountable Open about costs, terms and outcomes

[9770] Open once, use many times Publish so others do not repeat the work

[9773] Continuously improve The loop does not stop at signature

## Enablers [9777]

[9779] Data & analytics

[9780] Skilled commercial & technical teams

[9781] Digital platforms & collaboration

[9782] Standards & guidance

[9783] Security & information assurance

## Outcomes [9785]

[9787] Faster, safer adoption

[9788] Better value for money

[9789] Reduced risk & duplication

[9790] Stronger innovation & competition

[9791] Continuous improvement

[9792] Trusted, sustainable public services

[9793] Back to the contents · Suggest a correction (opens GitHub)

[9805] Dependency, lock-in & exit

## The ecosystem behind an AI-enabled public service [9806]

[9807] AI-enabled services rely on a chain of suppliers, platforms, models, data sources and infrastructure. Visibility of these dependencies is what makes risk management, resilience, portability and value possible.

## Public sector consumers [9811]

## Central government departments [9812]

## Devolved administrations [9813]

## Local government [9814]

## Public bodies & arm's-length bodies [9815]

## Health & care [9816]

## Education [9817]

## Justice & policing [9818]

## Regulators [9819]

## Citizens & service users [9820]

[9823] AI-enabled public service / use case

[9824] Knowledge assistant Case summary Policy drafting Meeting intelligence Citizen support Code assistant Workflow automation Analytics & insight

[9834] Applications & platforms

[9835] Microsoft 365 Copilot Copilot Studio / Agent Builder Teams, SharePoint, Outlook Power Platform (connectors, apps, automate) Foundry / Azure AI services Third-party applications Custom applications

[9844] Models & AI capabilities

[9845] Microsoft models OpenAI models Anthropic models Google models Open source models Specialist / domain models Future / emerging models

[9854] Cloud & infrastructure

[9855] Microsoft Azure (compute, storage, networking) Azure regions & availability zones GPU / compute capacity providers AI services (API management, safety, content filters) Identity & access (Entra ID) Monitoring & observability Backup & disaster recovery

[9864] Data & information

[9865] SharePoint libraries Teams & collaboration content Line-of-business systems Open data & external sources Reference data & master data Vector stores & indexes Logs, telemetry & feedback

[9874] Third parties & suppliers across the ecosystem

[9875] Model providers Cloud provider Software vendors API / service providers Data providers Integration partners Support & operations Consulting & implementation

## Key dependency categories [9886]

[9887] Platform dependency Reliance on specific platforms and ecosystems

[9889] Model dependency Reliance on model providers and availability

[9891] Data dependency Access to quality, timely and trusted data

[9893] Infrastructure dependency Compute, storage, network and region reliance

[9895] Supplier & contractual dependency Third-party services, SLAs, pricing and contractual terms

[9897] Operational dependency Skills, support, monitoring and continuity

## Key questions to ask [9900]

[9902] What happens if a supplier or model is unavailable?

[9903] Can we switch models or platforms easily?

[9904] Where is our data stored and processed?

[9905] Do we have visibility of usage, cost and performance?

[9906] What contractual rights do we have — audit, data portability?

[9907] Are we building excessive lock-in or technical debt?

[9908] Do we have a clear exit and migration plan?

## Managing dependencies [9911]

[9913] Map and document all dependencies

[9914] Assess risk and criticality

[9915] Ensure contractual protections

[9916] Design for portability

[9917] Monitor usage, cost and performance

[9918] Plan for resilience and exit

[9919] Review and adapt continuously

## Outcomes [9921]

[9922] Better risk management Resilience & continuity Cost optimisation Informed supplier strategy Sustainable innovation Public value protection

## Design for choice today. Exit with confidence tomorrow. [9929]

[9930] Avoid unintended dependency. Preserve portability across data, models, agents, integrations and knowledge, so you can adapt, switch or exit when you need to.

[9933] Portability Keep your data, prompts, models and agents portable

[9936] Transparency Know what you use, where it is, and the terms

[9939] Interoperability Use open standards and avoid proprietary traps

[9942] Plan ahead Design exit and migration paths from day one

[9945] Control costs Understand true switching and transition costs

[9948] Continuity Maintain service and compliance through change

## Sources of lock-in [9952]

[9954] Proprietary platforms and ecosystems

[9955] Closed data formats and schemas

[9956] Proprietary connectors and APIs

[9957] Model dependency and exclusivity

[9958] Managed services and operations

[9959] Contractual restrictions and terms

[9960] Data residency and jurisdiction

[9961] Skills and tooling

## The lock-in zone — where dependencies accumulate [9963]

[9966] Technology dependencies

[9968] Proprietary features and roadmaps

[9969] Custom integrations

[9970] Closed standards

[9971] Single-tenant architectures

[9973] Data & knowledge dependencies

[9975] Data locked in proprietary stores

[9976] Non-exportable metadata

[9977] Knowledge bases tied to platform

[9978] Prompt libraries not portable

[9980] Model & AI dependencies

[9982] Model exclusivity clauses

[9983] No right to substitute

[9984] Fine-tuned models not exportable

[9985] Training data use restrictions

[9987] Operational dependencies

[9989] Managed service entanglement

[9990] Monitoring and tool lock-in

[9991] Infrastructure coupling

[9992] Support and SLAs tied to stack

[9994] Commercial dependencies

[9996] Long contracts with penalties

[9997] Limited termination rights

[9998] IP and data use restrictions

[9999] Unilateral price change rights

[10001] Organisational dependencies

[10003] Specialist skills tied to vendor

[10004] Processes built around tools

[10005] Change resistance

[10006] Limited market knowledge

## Exit & transition path — reduce risk, preserve value [10008]

## Discover & inventory [10012]

[10014] Map all assets, services and data

[10015] Identify critical dependencies

[10016] Assess complexity and effort

## Define target state [10019]

[10021] Choose target platform / model

[10022] Define data, security and compliance needs

[10023] Agree outcomes and constraints

## Design migration strategy [10026]

[10028] Prioritise workloads

[10029] Phased or parallel approach

[10030] Define data and application migration

[10031] Plan cutover and rollback

## Prepare & extract [10034]

[10036] Extract data, metadata and documents

[10037] Export prompts, agents and configurations

[10038] Validate completeness and quality

## Build & test [10041]

[10043] Rebuild integrations

[10044] Adapt to target platform / model

[10045] Test functionality, performance and security

## Migrate & cutover [10048]

[10050] Migrate data and configurations

[10051] Switch traffic and users

[10052] Monitor closely post-cutover

## Optimise & decommission [10055]

[10057] Optimise costs and performance

[10058] Retire old assets safely

[10059] Capture lessons and update runbooks

## Exit readiness check [10063]

## Not assessed [10065]

[10067] Rate how prepared you are to exit. The path above is the work; this is the readiness.

## What to preserve and make portable [10070]

[10071] Data Metadata & schemas Documents & content Prompts & instructions Agents & workflows Configurations & settings Integrations & APIs Access & permissions Audit logs & evidence Knowledge & context

## De-risking strategies [10083]

[10085] Use open standards and portable formats

[10086] Negotiate data and IP rights up front

[10087] Retain audit and telemetry access

[10088] Stay multi-cloud and multi-model ready

[10089] Modular architecture and loose coupling

[10090] Regular dependency reviews

## Red flags — high lock-in risk [10093]

[10095] No export or portability options

[10096] Data only accessible via proprietary APIs

[10097] High egress or extraction charges

[10098] Contract penalties for early exit or data retrieval

[10099] Complex custom integrations with no standards

[10100] Single model or provider dependency

[10101] Lack of roadmap visibility or support

## Exit cost components [10103]

[10105] Data extraction and transformation

[10106] Rebuild / re-engineering

[10107] Dual running (parallel operations)

[10108] Testing and assurance

[10109] Training and change

[10110] Contract exit and penalties

[10111] Downtime / disruption risk

## Exit success outcomes [10113]

[10115] Freedom to innovate and adapt

[10116] Lower total cost of ownership

[10117] Stronger resilience and continuity

[10118] Better negotiation power

[10119] Protected public data and trust

[10120] Sustainable, future-proof services

[10121] Back to the contents · Suggest a correction (opens GitHub)

