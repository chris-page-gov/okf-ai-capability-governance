---
type: publisher-section
title: AI Capability Governance and Implementation
status: draft
sources:
- title: AI Capability Governance and Implementation
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#top
x-dom-section: top
---

# AI Capability Governance and Implementation

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#top)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[155] Public edition · one portal · open to everyone

## AI Capability Governance and Implementation [156]

[157] One trusted route to discover, assess, implement, govern and get value from AI in public services. Governance follows what the AI can see, create and do, whichever supplier made it.

[163] 85 chapters

[166] 12 parts

[169] 7 working tools

[172] 69 tiered sources

[175] 29 signals

[178] 174 glossary terms

[208] Four non-negotiable principles

## One route from idea to lasting public value [209]

[211] Humans remain accountable. AI never grants authority a person does not already hold.

[213] AI outputs are verified, not trusted by default. Every claim traces to a citable source.

[215] Public value, equality and accessibility are built in — screened before delivery, not audited after.

[217] Evidence, metadata and provenance are mandatory for anything material or public-facing.

[220] Spotlight · new in 3.4.0

[221] Human oversight that is measured, not assumed

[222] Nine new chapters: oversight principles and controls, how to measure oversight without monitoring people, skill atrophy and automation drift, a twelve-step runbook with governance templates, neuroinclusive AI at work, and a register of 164 obligations across the four nations.

[223] Start with the principles What was withheld

