---
type: publisher-section
title: Authoritative guidance, standards and reusable intelligence
status: draft
sources:
- title: Authoritative guidance, standards and reusable intelligence
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#knowledge
x-dom-section: knowledge
---

# Authoritative guidance, standards and reusable intelligence

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#knowledge)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## Authoritative guidance, standards and reusable intelligence [19916]

[19917] The corpus is organised as a knowledge graph linking laws, policies, standards, design guidance, security controls, skills, agents and evidence — so that a rule can always be traced to its source and its consequences.

## Guidance corpus [19921]

[19922] Index GOV.UK, GDS, CDDO, departmental, international standards, GitHub and engineering-lab sources with authority tiering, freshness checks and applicability metadata.

[19923] Browse the 69 indexed sources →

## Knowledge graph [19927]

[19928] Link services, repositories, datasets, APIs, controls, skills, agents, people, approvals, models, risks and evidence so impact analysis is a query, not a workshop.

[19929] See the metadata model →

## Executable guidance [19933]

[19934] Translate policy and standards into schemas, conformance packs, tests, scripts, checklists and prompt patterns that run in delivery pipelines.

[19935] See the conformance packs →

## Authority tiering — how conflicts are resolved [19937]

[19938] When two sources disagree, the lower tier number wins. Record the conflict and the resolution in the evidence pack.

[19941] Source authority tiers used across the corpus

[19944] Tier

[19945] Source type

[19946] Examples

[19947] Treatment

[19950] 0

[19952] Law and statutory instruments

[19953] Equality Act 2010, DPA 2018, Accessibility Regulations 2018

[19954] Binding. Non-compliance is not a risk to accept — escalate.

[19956] 1

[19958] Mandated standards and cross-government policy

[19959] Service Standard, Technology Code of Practice, Secure by Design, WCAG 2.2, ATRS

[19960] Comply or record a formal, time-boxed exception with an owner.

[19962] 2

[19964] Recognised international and professional standards

[19965] ISO/IEC 42001, NIST AI RMF, OWASP LLM Top 10

[19966] Adopt as good practice; justify divergence.

[19968] 3

[19970] Community, vendor and research material

[19971] Blogs, model cards, toolkits, preprints

[19972] Useful signal. Never the sole basis for a control or a public claim.

## Freshness and drift controls [19973]

## Every indexed source carries [19976]

[19978] • Authority tier and issuing body

[19979] • Date checked and next check due

[19980] • Applicability (organisation, service type, data classification)

[19981] • Supersession chain and withdrawal status

[19982] • Linked controls, skills and conformance tests

## Drift triggers a review when [19984]

[19986] • A cited source is updated, withdrawn or superseded

[19987] • A model or its version changes materially

[19988] • A control fails in production or a conformance test breaks

[19989] • An incident, complaint or FOI request touches the artefact

[19990] • The scheduled review date passes without confirmation

