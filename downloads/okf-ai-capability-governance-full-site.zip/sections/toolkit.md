---
type: publisher-section
title: A complete operating kit for AI-assisted public delivery
status: draft
sources:
- title: A complete operating kit for AI-assisted public delivery
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#toolkit
x-dom-section: toolkit
---

# A complete operating kit for AI-assisted public delivery

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#toolkit)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## A complete operating kit for AI-assisted public delivery [19215]

[19216] Every asset is designed to be catalogued, versioned, reviewed and reused. Filter by purpose, or search across names, descriptions and linked standards.

[19219] Search the toolkit

[19223] Filter by purpose

[19225] Show all

[19226] Governance

[19227] Delivery

[19228] Assurance

[19229] Future-ready

[19230] Showing 18 of 18 toolkit assets.

## AI asset metadata standard [19237]

[19238] Machine-readable schemas for skills, agents, prompts, tools, model-use events, evidence packs and source provenance.

[19239] Output: JSON Schema + YAML template

[19241] Anchored to: PROV-O (opens an external website) , CycloneDX ML-BOM (opens an external website) , DCAT 3 (opens an external website)

## Skill registry [19254]

[19255] Approved, draft and deprecated skills with owners, sources, risk ratings, compatibility and evidence rules.

[19256] Output: Register + lifecycle policy

[19258] Anchored to: Model cards (opens an external website) , alphagov (opens an external website)

## Agent registry and bounding [19269]

[19270] Bounded agents by autonomy level, permissions, allowed skills, prohibited actions, model constraints and kill-switch owner.

[19271] Output: Register + autonomy policy

[19273] Anchored to: MCP (opens an external website) , OWASP LLM Top 10 (opens an external website)

## Evidence pack builder [19285]

[19286] Source consultation records, AI-use declarations, validation results, human acknowledgements and audit trails.

[19287] Output: Generator on this page

[19289] Anchored to: ATRS (opens an external website)

[19293] Open the tool

## DEIA impact screen [19301]

[19302] Equality, accessibility, assisted digital, digital inclusion, protected characteristic and vulnerability screening.

[19303] Output: Screening tool on this page

[19305] Anchored to: PSED (opens an external website) , WCAG 2.2 (opens an external website)

[19311] Open the tool

## Quantum readiness assessor [19319]

[19320] Inventory cryptography, identify long-life data, assess harvest-now-decrypt-later exposure and plan crypto-agility.

[19321] Output: Assessment tool on this page

[19323] Anchored to: NCSC PQC (opens an external website) , NIST PQC (opens an external website)

[19329] Open the tool

## Human review triage (H0–H5) [19337]

[19338] Risk-based routing that decides how many eyes, which specialists and what evidence an AI-assisted output needs.

[19339] Output: Triage tool on this page

[19341] Anchored to: NIST AI RMF (opens an external website)

[19345] Open the tool

## Prompt and context pattern library [19352]

[19353] Reviewed prompt patterns with source-citation requirements, refusal conditions, data-handling rules and test cases.

[19354] Output: Pattern library + tests

[19356] Anchored to: AI Playbook for the UK Government (opens an external website)

## Conformance packs [19365]

[19366] Executable checks turning WCAG, Service Standard, Secure by Design and TCoP clauses into automated tests.

[19367] Output: CI pack

[19369] Anchored to: Pa11y (opens an external website) , Secure by Design (opens an external website)

## Transparency record generator [19381]

[19382] Produce an ATRS-shaped public record for any algorithmic or AI-assisted tool in use.

[19383] Output: Generator on this page

[19385] Anchored to: ATRS hub (opens an external website)

[19389] Open the tool

## Supplier and procurement assurance kit [19396]

[19397] Questions, evidence asks and contract clauses for AI suppliers: model provenance, evaluations, accessibility, exit.

[19398] Output: Question bank + clauses

[19400] Anchored to: ISO/IEC 42001 (opens an external website) , EN 301 549 (opens an external website)

## Incident, near-miss and drift reporting [19411]

[19412] Report AI failures, hallucinations, bias incidents, prompt injection and source drift with learning loops.

[19413] Output: Process + register

[19415] Anchored to: MITRE ATLAS (opens an external website) , NCSC secure AI (opens an external website)

## Model and data provenance ledger [19426]

[19427] Signed, tamper-evident record of which model, version, prompt, source and human touched each artefact.

[19428] Output: Ledger spec

[19430] Anchored to: C2PA (opens an external website) , SLSA (opens an external website)

## Sustainability and cost-to-serve calculator [19441]

[19442] Estimate energy, carbon and unit cost of model calls, and test whether a non-AI option is proportionate.

[19443] Output: Calculator + reporting

[19445] Anchored to: Greening Government ICT (opens an external website) , W3C WSG (opens an external website)

## Inclusive research and co-design kit [19456]

[19457] Recruitment, consent, reimbursement and session plans that reach disabled, digitally excluded and seldom-heard users.

[19458] Output: Research kit

[19460] Anchored to: Research with disabled people (opens an external website) , Assisted digital (opens an external website)

## Plain-language and reading-age checker [19472]

[19473] Test AI-drafted content against GOV.UK style, reading age 9, and inclusive terminology before publication.

[19474] Output: Checker on this page

[19476] Anchored to: GOV.UK style guide (opens an external website)

[19480] Open the tool

## Records, retention and FOI readiness [19487]

[19488] Classify AI interaction logs as records; set retention, disclosure and redaction rules ahead of FOI/SAR requests.

[19489] Output: Retention schedule

[19491] Anchored to: DPA 2018 (opens an external website)

## Capability and competence pathway [19500]

[19501] Role-based learning paths, licence-to-operate checks and refreshers for anyone using AI on public work.

[19502] Output: Curriculum map

[19504] Anchored to: DDaT framework (opens an external website)

[19508] No assets match. Try a broader term or reset the filter.

