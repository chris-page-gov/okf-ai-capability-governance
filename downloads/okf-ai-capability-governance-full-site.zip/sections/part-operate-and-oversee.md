---
type: publisher-section
title: Operate and oversee
status: draft
sources:
- title: Operate and oversee
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#part-operate-and-oversee
x-dom-section: part-operate-and-oversee
---

# Operate and oversee

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#part-operate-and-oversee)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[7158] Part 5 of 12 · 7 chapters

## Operate and oversee [7159]

[7168] AI governance control tower · illustrative dashboard

## AI agent portfolio control tower [7169]

[7170] Govern. Assure. Monitor. Improve. Every figure below is illustrative, showing the dashboard a governed portfolio produces — last updated 20 May 2025 09:30.

[7176] 128

## AI agents registered [7177]

[7178] ↑ 12 this month

[7182] 87

## Live in production [7183]

[7184] ↑ 7 this month

[7188] 45

## In testing / pilot [7189]

[7190] ↓ 3 this month

[7194] 5

## Suspended [7195]

[7196] — No change

[7200] 12

## Retired [7201]

[7202] ↑ 2 this month

[7206] 116

## ATRS records published [7207]

[7208] ↑ 10 this month

## Agents by lifecycle stage [7211]

## 128 total [7212]

[7213] Proposed 8 6%

[7217] Live 87 68%

[7221] Pilot / testing 45 35%

[7225] Suspended 5 4%

[7229] Retired 12 9%

## Assurance status [7234]

## 128 total [7235]

[7236] Assured 72 56%

[7240] Partially assured 28 22%

[7244] Not assured 18 14%

[7248] Not required 10 8%

## Risk overview [7253]

[7254] High risk 12 9%

[7258] Medium risk 34 27%

[7262] Low risk 62 48%

[7266] Very low risk 20 16%

[7273] 12 agents are high risk and require action. View risk register →

## Agents by domain [7276]

[7277] Citizen services 32 25%

[7283] Corporate services 24 19%

[7289] Policy & strategy 18 14%

[7295] Operations 16 13%

[7301] Finance 14 11%

[7307] HR & people 12 9%

[7313] Other 12 9%

## AI agent register [7322]

## View all agents → [7324]

[7325] AGENT NAME SERVICE / DOMAIN PURPOSE OWNER LIFECYCLE RISK ASSURANCE ATRS RECORD LAST REVIEWED NEXT REVIEW

## Policy Briefing Assistant [7338]

[7340] Policy & Strategy

[7342] Supports policy analysts by summarising key documents and drafting briefing notes.

[7344] Sarah Johnson (Director)

## Live [7346]

## High [7348]

## Assured [7350]

## ATRS-00045 [7352]

[7354] 15 May 2025

[7356] 15 Aug 2025

## Casework Triage Agent [7359]

[7361] Citizen Services

[7363] Prioritises and routes incoming casework to the right teams.

[7365] Mark Patel (Head of Ops)

## Live [7367]

## Medium [7369]

## Partially assured [7371]

## ATRS-00032 [7373]

[7375] 10 May 2025

[7377] 10 Aug 2025

[7378] Finance Anomaly Detector Finance Detects unusual transactions and supports investigation. Alex Kim (Finance Lead) Live Medium Assured ATRS-00028 08 May 2025 08 Aug 2025

[7389] HR Policy Advisor HR & People Provides guidance on HR policies and employee queries. Lucy Bennett (HR Manager) Pilot Low Assured ATRS-00061 12 May 2025 12 Aug 2025

## IT Support Copilot [7402]

[7404] Corporate Services

[7406] Assists IT staff with troubleshooting and knowledge retrieval.

[7408] Tom Edwards (IT Manager)

## Pilot [7410]

## Low [7412]

## Not required [7414]

## — [7416]

[7418] 18 May 2025

[7420] 18 Aug 2025

[7421] Comms Drafting Agent Corporate Services Drafts communications and public messages. Nina Shah (Comms Lead) Suspended High Partially assured ATRS-00017 02 May 2025 Review pending

[7436] 46 Data sources connected

[7441] 27 High sensitivity data sources

[7446] 96% Agents have named owners

[7451] 100% DPIA completed (in scope)

[7456] 94% Security reviews up to date

[7461] 85% Agents have defined success metrics

[7466] 65% Agents have sustainability assessment

## Control tower navigation [7470]

## Overview [7475]

## AI agents [7479]

## ATRS registry [7483]

## Assurance [7487]

## Risks [7491]

## Incidents [7495]

## Reports [7499]

## Analytics [7503]

## Settings [7507]

## Help [7511]

## Quick actions [7513]

## Register new agent [7517]

## Create ATRS record [7521]

## Request assurance [7525]

## Report an issue [7529]

[7530] Back to the contents · Suggest a correction (opens GitHub)

[7542] Responsible AI · operate and improve

## Approval stays current only while the evidence does [7543]

[7544] Monitoring, incidents, the change watchlist, reassessment and retirement, run as one learning loop. The Portfolio control tower shows the estate view; this chapter defines what feeds it.

## Dashboard domains [7546]

[7552] Domain

[7553] What it shows

[7554] Fed by

[7555] Act when

[7558] Adoption and usage

[7559] Who uses which capability, and how often, by group.

[7560] Tool, use-case registers

[7561] Uptake is uneven across groups or roles.

[7563] Cost and consumption

[7564] Spend by tool, team and use case against caps.

[7565] Tool, benefits registers

[7566] A cap or alert is hit, or cost grows faster than use.

[7568] Outcome quality and value

[7569] Verified outcomes, not prompt counts or time saved alone.

[7570] Benefits register

[7571] Value evidence is missing at review.

[7573] Correction and rework

[7574] Review effort and how much output is edited or discarded.

[7575] Benefits register

[7576] Rework cancels the time saved.

[7578] Accessibility and inclusion

[7579] Barriers reported, adjustments supported, alternatives used.

[7580] Incident, use-case registers

[7581] A barrier is reported without an alternative.

[7583] Risk, incidents and near misses

[7584] Incidents by tool, model, use case and control.

[7585] Incident register

[7586] Repeat incidents on one control.

[7588] Sustainability indicators

[7589] Supplier environmental evidence and usage indicators.

[7590] Tool, supplier registers

[7591] Evidence is missing or usage is disproportionate.

[7593] Control effectiveness

[7594] Whether controls worked when tested or triggered.

[7595] Incident, review registers

[7596] A control failed or was bypassed.

[7598] Change and deprecation exposure

[7599] Live use affected by upcoming supplier changes.

[7600] Change, model registers

[7601] A deprecation lands inside the review window.

[7603] Support demand and recurring issues

[7604] Tickets and repeat questions by tool.

[7605] Support and service records

[7606] The same issue recurs across teams.

[7607] No figures are shown. Each domain is defined so live data can be connected without redesign.

## Changes that trigger reassessment [7608]

## Model [7611]

[7612] A new, changed or automatically selected model.

[7613] Partial or full

## Supplier [7615]

[7616] New subprocessor, location, terms or ownership.

[7617] Full

## Data [7619]

[7620] New sources, connectors or classifications.

[7621] Partial or full

## Permission [7623]

[7624] Wider access, new identities or delegation.

[7625] Full

## Action [7627]

[7628] New tools, actions, schedules or agent links.

[7629] Full

## Interface [7631]

[7632] Changed terminology, layout or defaults.

[7633] Guidance update

## Cost [7635]

[7636] New pricing, metering or consumption pattern.

[7637] Partial

## Policy [7639]

[7640] New law, policy or guidance.

[7641] Partial or full

## Change and deprecation watchlist [7642]

## 17–20 Nov 2026 [7646]

[7648] Microsoft Ignite Several preview items in the service atlas are likely to change. Refresh entries after the event.

[7651] Proposed

## Ongoing [7654]

[7656] Staggered Copilot interface rollout Users see different interfaces at once. Keep guidance by release channel and show preview versus general availability.

[7659] Reported

## Each release [7662]

[7664] Default-enabled features New features can arrive switched on. Check admin defaults after each release.

[7667] Reported

## Open [7670]

[7672] Claude models reached through Microsoft Confirm subprocessor terms and whether processing sits inside the data boundary.

[7675] Unresolved

## Open [7678]

[7680] Microsoft UK data processing commitment Confirm in your admin centre before relying on it.

[7683] Unresolved

## Ongoing [7686]

[7688] Indexed metadata exposure Titles, filenames and metadata can surface despite permissions. Re-test indexing on change.

[7691] Reported

## Sep 2026 [7694]

[7696] Cowork cost and security Concerns raised about credit consumption and security. Set caps before any pilot.

[7699] Reported

## Governance as a continuous learning system [7700]

[7702] 1. Pilot Define scope and success measures Test with real users Put controls in place Set stop criteria

[7709] 2. Evidence Gather quantitative and qualitative data Assess outcomes, quality and value Capture accessibility, cost and risk Record unintended effects

[7716] 3. Decision Approve, approve with conditions, extend, restrict or stop Record the rationale Update registers Tell users

[7723] 4. Operation Deploy and support users Monitor controls and compliance Provide guidance and training Maintain human oversight

[7730] 5. Monitoring Track usage and adoption Monitor cost and consumption Identify risks and anomalies Measure outcomes and value

[7737] 6. Incident, change or learning Respond to incidents and near misses Investigate and resolve Capture lessons Watch product, model and policy changes

[7744] 7. Reassessment Assess the impact of change Update the risk and control position Refresh approvals if needed Decide: continue, restrict or suspend

[7751] 8. Retire Disable access and actions Remove data and integrations Inform users Close records and capture lessons

[7759] Turning experience into impact

[7760] Better decisions Based on real outcomes Stronger controls Informed by actual risks Greater value For users and public services More inclusive Identifying and removing barriers Smarter spending Understanding cost and benefit Shared learning Reusable patterns and guidance

## Report an AI concern, incident or near miss [7775]

[7776] Report anything that went wrong or nearly did: a wrong output that was acted on, an exposed file, an unexpected action, a cost spike, an accessibility barrier. Record:

[7778] Tool, model and deployment route

[7779] Use case and what happened

[7780] Who was affected, and whether it was acted on

[7781] The control that should have prevented it

[7782] Corrective action and owner

## Suspension and retirement [7784]

[7786] Record the reason and the replacement.

[7787] Tell users, with an accessible alternative.

[7788] Disable agents and actions, and revoke access.

[7789] Disconnect integrations and dispose of data.

[7790] Update registers and remove supplier access.

[7791] Record residual risks and lessons; approve closure.

[7792] Back to the contents · Suggest a correction (opens GitHub)

[7804] Agent journey

## From idea to retirement, with a gate at every stage [7805]

[7806] An agent that helps one person and an agent that decides a citizen's case are not the same thing, and should not carry the same controls. Eight stages, each with a gate question, the control that applies, the role accountable and the outcome expected.

[7809] Stage 1 of 8 Personal / low risk

## Idea & discovery [7812]

## What happens [7815]

[7817] Identify a need or opportunity

[7818] Explore feasibility

[7819] Check existing solutions and policies

## Gate 1 — decision point [7821]

## Is there a clear need and no existing solution? [7822]

## Control applied [7824]

[7825] Security & identity — least privilege, access control and monitoring

## Key accountability [7826]

[7827] Creator — builds and tests the agent; owns initial purpose

## Outcome at this stage [7829]

## Better understanding of needs and opportunities [7830]

## Success factors across the journey [7832]

[7833] Clear purpose and value Right controls at the right time User engagement and feedback Sustainable cost model Continuous learning and improvement Strong community and reuse Better public value outcomes

## Personal experiment to enterprise service [7841]

[7842] A managed progression that balances innovation, control, risk and value. Agents evolve from personal productivity tools to trusted, supported services — and ownership moves with them.

[7845] 1 Idea & personal experiment Individual creator Low risk · personal

[7850] 2 Share & team pilot Team data owners Low to moderate risk

[7855] 3 Managed team agent Named team owner Moderate risk

[7860] 4 Departmental capability Departmental owner Moderate to high risk

[7865] 5 Operational service Service owner High risk

[7870] 6 Enterprise service Business / enterprise owner High risk · high impact

[7875] 7 Cross-government capability Cross-government sponsor & owners High impact · strategic

## The Copilot-to-agent capability spectrum [7879]

[7880] A continuum of assistance and autonomy — from individual productivity to enterprise agentic services. Purpose: enable people to work better today, orchestrate intelligent workflows, and deliver trusted, efficient, inclusive public services.

[7882] Tier 2 of 7 · Microsoft 365 Copilot

## M365 Copilot [7883]

[7884] AI in your apps to summarise, draft, analyse and explore

[7887] TYPICAL USERS Individual

[7891] AUTONOMY LEVEL Human-guided

[7895] SCOPE Personal

[7899] EXAMPLES Word drafting · Excel analysis · Meeting summary

[7903] GOVERNANCE Org policies

## Avoiding the “access database moment” [7906]

[7907] How a small, helpful agent becomes business critical without visibility or control. Small agents can create big value — and big risk. Visibility, ownership and governance early in the journey prevent unmanaged tools from becoming unmanageable dependencies.

[7910] 1 Personal experiment Low visibility An individual creates an agent to solve a personal problem or save time.

[7915] 2 Shared with team Low to moderate visibility Shared with colleagues or a small team to help with common tasks.

[7920] 3 Wider adoption Rising visibility More teams discover it and start using it organically.

[7925] 4 Dependence builds Rising to high visibility Critical work starts to rely on the agent and its outputs.

[7930] 5 Business critical High visibility Used across the department or service. Business processes become dependent on it.

[7935] 6 Invisible criticality Gap in visibility No formal ownership, limited documentation, unknown controls, unknown costs.

[7940] 7 High risk exposure Critical · unmanaged Risk of failure, data breach, inaccurate decisions or service disruption.

[7945] 8 Event of failure Loss of trust and value Agent breaks, data changes or owner leaves — causing a real operational impact.

## How to prevent it — early detection, ownership and routes to enterprise management [7950]

[7953] 1. Discover early Agent inventory · Usage monitoring · Sharing visibility · Community reports

[7956] 2. Require description Purpose & use case · Data sources · Support owner · Review dates

[7959] 3. Assign ownership Business owner · Technical owner · Information owner · Risk owner

[7962] 4. Assess & classify Risk & impact · Data sensitivity · Criticality score · Assurance needs

[7965] 5. Control & assure Approved sources · Guardrails · Human oversight · Testing & validation

[7968] 6. Monitor & review Usage & performance · Cost & consumption · Accuracy & quality · Incident tracking

[7971] 7. Promote or remediate Move to managed platform (e.g. Copilot Studio) · Or retire / remediate

## What goes wrong when it is left unmanaged [7974]

[7975] Shadow IT Inconsistent quality Lack of documentation Knowledge silos Unknown cost Compliance breach Loss of public trust

[7983] Back to the contents · Suggest a correction (opens GitHub)

[7995] Agent employment lifecycle

## Managing AI agents as governed digital workers [7996]

[7997] Agents go through a managed lifecycle — from intent to retirement — with controls, oversight and accountability at every stage. People remain accountable: agents augment human capability, they do not replace judgement, responsibility or accountability.

## Recruitment (define need) [8002]

## Human analogy: Job requisition & role definition [8003]

[8004] Identify the need, purpose and expected outcomes.

[8005] Key controls

[8007] Business case

[8008] User need

[8009] Impact assessment

[8010] Initial risk screen

## Clear mandate and value case [8011]

## Vetting & evaluation [8014]

## Human analogy: Recruitment, screening & interviews [8015]

[8016] Assess capability, risks, data needs and alignment with policy and standards.

[8017] Key controls

[8019] Capability evaluation

[8020] Risk assessment

[8021] Data assessment

[8022] Policy alignment

[8023] Assurance readiness

## Fit for purpose and safe to proceed [8024]

## Onboarding & configuration [8027]

## Human analogy: Induction & onboarding [8028]

[8029] Configure the agent, set permissions, guardrails and connect data and tools.

[8030] Key controls

[8032] Guardrails

[8033] Permissions

[8034] Data access

[8035] Tool access

[8036] Prompt / policy setup

## Ready, secure and configured correctly [8037]

## Probation (pilot) [8040]

## Human analogy: Probation period [8041]

[8042] Operate in a controlled pilot with close human oversight and limited scope.

[8043] Key controls

[8045] Limited scope

[8046] Human-in-the-loop

[8047] Enhanced monitoring

[8048] Evaluation criteria

## Validated in real-world conditions [8049]

## Live operation (employment) [8052]

## Human analogy: Active employment [8053]

[8054] Agent operates within its delegated authority to support people and processes.

[8055] Key controls

[8057] Performance KPIs

[8058] Quality checks

[8059] Bias & fairness review

[8060] Value realisation review

## Measurable performance and value [8061]

## Performance review [8064]

## Human analogy: Performance appraisal [8065]

[8066] Regularly review performance, accuracy, impact, risks and value delivery.

[8067] Key controls

[8069] Model updates

[8070] Knowledge refresh

[8071] Prompt tuning

[8072] Control improvements

## Improved capability and reduced risk [8073]

## Retrain & improve [8076]

## Human analogy: Training & professional development [8077]

[8078] Update knowledge, models, prompts and controls based on learning and feedback.

[8079] Key controls

[8081] Restrict authority

[8082] Increase oversight

[8083] Root cause analysis

[8084] Remediation plan

## Risk managed and issues contained [8085]

## Suspension / restriction [8088]

## Human analogy: Suspension [8089]

[8090] Restrict or pause the agent if risks increase, rules are breached or performance drops.

[8091] Key controls

[8093] Restrict authority

[8094] Increase oversight

[8095] Root cause analysis

[8096] Remediation plan

## Risk managed and issues contained [8097]

## Retirement & offboarding [8100]

## Human analogy: Resignation or termination [8101]

[8102] Retire the agent when no longer needed or superseded. Revoke access and archive records.

[8103] Key controls

[8105] Revoke access

[8106] Disconnect tools

[8107] Data cleanup

[8108] Archive agent artefacts

[8109] Stakeholder notification

## Safe retirement and clean closure [8110]

## Archive & audit [8113]

## Human analogy: HR records retention & reference [8114]

[8115] Retain records for audit, transparency and learning in accordance with retention rules.

[8116] Key controls

[8118] Records archive

[8119] Audit trail retention

[8120] Lessons learned

[8121] Knowledge capture

## Accountable, transparent and auditable [8122]

## Applied throughout every stage [8124]

[8125] Continuous monitoring Human oversight Audit logging Policy compliance Security Privacy Safety

## Capability is not authority [8133]

[8134] An agent may be able to do many things, but can only do what it is authorised to do. Capability is about potential; authority is about permission. Capability + authority + context = action — only when all controls are satisfied can the agent act.

## What the agent can do — capability [8137]

[8138] Technical potential and skills: the full range of capabilities, knowledge, tools and actions the agent is built or enabled to perform.

[8139] Natural language understanding Tool use & API integrations Reasoning & problem solving Workflow orchestration & scheduling Data retrieval (RAG) Analysis & visualisation Code generation & automation Communication (drafting, email, chat) Content creation & summarisation Learning from feedback

## Governance controls [8151]

[8152] Bridging capability to appropriate action.

[8153] Policies & rules Organisational policies, legal requirements and ethical guardrails define boundaries.

[8155] Delegated authority Explicit permissions granted for specific tasks, data and systems.

[8157] Conditions & controls Context, thresholds, approvals and risk checks must be satisfied.

[8159] Human oversight People remain in control of decisions and can intervene or override.

[8161] Monitoring & audit Actions are logged, monitored and reviewed for assurance and compliance.

## What the agent is allowed to do — authority [8164]

[8165] Permitted actions in the right context, within defined boundaries, for specific purposes and users.

[8166] Draft policy briefing Approved for Policy Team (sensitivity: OFFICIAL)

[8168] Send standard email response Approved with template and review

[8170] Summarise documents up to OFFICIAL Approved with data classification filter

[8172] Update internal tracker or system Approved with role-based permissions

[8174] Escalate issue to human reviewer Required when confidence below threshold

## Why separate capability from authority [8177]

[8180] Reduces risk Limits exposure by ensuring agents cannot act beyond intent or policy.

[8183] Improves accountability Clear ownership and delegated authority for all actions.

[8186] Supports compliance Meets legal, regulatory and ethical obligations.

[8189] Enables agility Adjust permissions without rebuilding capabilities.

[8192] Builds trust Transparent controls and oversight build confidence.

[8195] Adapts to context Decisions and permissions can vary by role, risk and situation.

[8197] Back to the contents · Suggest a correction (opens GitHub)

[8209] Public service impact cascade

## How agents influence decisions and deliver public value [8210]

[8211] Seven links from capability to legitimacy — each with the elements that must hold and the risks that arise if they do not. Better governed AI agents lead to better decisions, better services, and better outcomes for everyone.

## AI capability (agent) [8216]

[8217] The agent has defined capabilities, knowledge, tools and guardrails within its delegated authority.

[8218] Key elements

[8220] Purpose & scope

[8221] Data & knowledge

[8222] Tools & actions

[8223] Guardrails & policies

[8224] Monitoring in place

[8225] Risks at this stage

[8227] Inaccurate data

[8228] Bias in training

[8229] Over-broad scope

[8230] Weak guardrails

## Civil servant (user) [8233]

[8234] Civil servants interact with the agent, using its insights, suggestions or automation to support their work.

[8235] Key elements

[8237] Trained & supported

[8238] Understood context

[8239] Human judgement

[8240] Challenge & review

[8241] Accountability clear

[8242] Risks at this stage

[8244] Over-reliance

[8245] Skill gaps

[8246] Poor prompting

[8247] Lack of challenge

## Operational decision [8250]

[8251] The agent's output informs or automates parts of operational decisions and actions within the service process.

[8252] Key elements

[8254] Decision boundaries

[8255] Human oversight

[8256] Documentation

[8257] Compliance checks

[8258] Audit trail captured

[8259] Risks at this stage

[8261] Automation bias

[8262] Unclear accountability

[8263] Policy non-compliance

[8264] Incomplete records

## Service outcome (internal) [8267]

[8268] Operational actions produce internal service results such as case resolution, guidance issued, or processing completed.

[8269] Key elements

[8271] Process efficiency

[8272] Accuracy & quality

[8273] Timeliness

[8274] Consistency

[8275] Cost effectiveness

[8276] Risks at this stage

[8278] Process error

[8279] Delay or backlog

[8280] Poor integration

[8281] Resource waste

## Public experience (end users) [8284]

[8285] Citizens, businesses and communities experience the service through interactions, outcomes and communications.

[8286] Key elements

[8288] Accessible & inclusive

[8289] Fair & equitable

[8290] Clear & understandable

[8291] Safe & secure

[8292] Easy to interact with

[8293] Risks at this stage

[8295] Exclusion

[8296] Confusing comms

[8297] Privacy concerns

[8298] Unequal treatment

## Public value & outcomes [8301]

[8302] Better outcomes are achieved for people and society, improving trust in services and contributing to public value.

[8303] Key elements

[8305] Better outcomes

[8306] Reduced burden

[8307] Improved equity

[8308] Economic value

[8309] Confidence & trust

[8310] Risks at this stage

[8312] Unintended harm

[8313] Widening inequity

[8314] Benefit not realised

[8315] Poor measurement

## Trust & legitimacy [8318]

[8319] Transparent, accountable and responsible use of AI strengthens public trust and democratic legitimacy.

[8320] Key elements

[8322] Transparency

[8323] Accountability

[8324] Safety & ethics

[8325] Oversight & redress

[8326] Continuous improvement

[8327] Risks at this stage

[8329] Lack of transparency

[8330] Accountability gaps

[8331] Safety incidents

[8332] Erosion of trust

## Enablers & controls across the cascade [8334]

[8335] Strong governance & ownership Policies & ethical use Security & privacy by design Quality data & provenance Monitoring & auditability Human oversight at every step Transparency (ATRS) Performance measurement Continuous improvement

[8345] Back to the contents · Suggest a correction (opens GitHub)

[8357] Observatory & barometer

## Published signals and a readiness assessment [8358]

[8359] The observatory tracks published signals of UK public-sector AI adoption; the model is the OECD.AI Policy Observatory, applied at home. Each figure carries its publisher and date. The barometer is your own assessment, stored on this device only.

## Observatory — published signals [8361]

[8366] OECD.AI · 2026

## 125+ [8367]

[8368] ATRS transparency records published. Mandatory reporting for central departments and ALBs since 2025.

[8372] Civil Service · 2026

[8373] 252

[8374] ideas entered in the Civil Service AI & Data Challenge 2026 — a 160% increase, in its fourth year.

[8378] DSIT analysis · 2026

## £68bn [8379]

[8380] AI investment pledged into the UK since January 2025.

[8384] delivery.ai.gov.uk · 2026

## 21 → 420 [8385]

[8386] UK AI compute in ExaFLOPs: 2025 actual to 2030 commitment (from 2 in 2024).

[8390] DSIT analysis · 2026

[8391] 200k

[8392] People studying AI-related higher-education programmes in the UK.

[8396] Heriot-Watt & GoLLM · 2025

## 1 in 3 [8397]

[8398] Scottish councils piloting or using AI. The leading UK nation for local-government adoption.

## Barometer — your readiness [8399]

[8400] Rate each dimension 0–4. Saved locally on this device; nothing leaves the page.

## — [8403]

## Rate the dimensions for a reading [8404]

[8405] 0 of 8 dimensions rated

## Strategy & leadership [8408]

## Governance & assurance [8410]

## Data readiness [8412]

## Skills & multidisciplinary team [8414]

## Security posture [8416]

## Ethics & transparency [8418]

## Delivery capability [8420]

## Monitoring & evaluation [8422]

[8423] Back to the contents · Suggest a correction (opens GitHub)

[8435] Human oversight · runbook

## Twelve steps to stand up proportionate oversight [8436]

[8437] A runbook for a service or department starting human oversight of AI, with starting positions for the governance documents it will need. The templates are skeletons, not legal advice: take them to your data protection officer, equality lead and legal adviser. From the Responsible AI and Data Use (RAIDU) work, merged into this playbook on 22 November 2026. Each item keeps its evidence grade: Proposed items are design proposals for review, not policy or established practice.

[8441] Before anything: is this for you? (Adopt) Run the classifier against your two or three largest AI deployments. All assist-class? Tier-1 telemetry and resourced oversight declaration; stop there. Anything determine-class? Work through the whole runbook. Mostly recommend-class? Tiers 1 and 2; read reversibility question carefully.

[8448] Who is needed (Adopt)

[8452] Weeks 1–2 — decide and disclose (Adopt) Classify every AI deployment in the service. Add each to the register. Export it. Brief the SRO on the register summary, particularly anything determine-class that cannot evidence its safeguard works. Open the DPIA and the union conversation in the same week. Both get harder the longer you leave them, and the union one cannot be recovered if it starts late. Write the resourced oversight declaration for the largest deployment.

[8459] Weeks 3–6 — emit tier 1 (Adopt) Map your existing approval telemetry onto the seven tier-1 fields. Most case management systems already hold all seven; the work is naming, not capture. Emit to the standard vocabulary codes. Resist local variants — the point is comparability. Run run_baseline.py or drop the CSV into the instrument. Expect the tier-1 warning that you cannot yet assess decay. That warning is the finding.

[8465] Weeks 7–10 — reach tier 2 (Adopt) Add edit distance, reason capture, streak count and model version. Streak must be derived from the real sequence. A field that disagrees with its own sequence is worse than an absent one. First real reading. Report it to the SRO whatever it says.

[8471] Weeks 11–12 — decide about tier 3 (Adopt) If the service is determine-class, start the ethics and union route for canaries now. It is the long pole. If not, stay at tier 2 and revisit in six months. Publish the baseline internally. Including if it shows nothing — a null result honestly reported is what makes this evidence-led rather than advocacy.

[8477] Integration (Adopt)

[8481] What to expect to go wrong (Adopt) The union conversation started too late. Recoverable only by stopping and restarting. Start it in week 1. Someone asks for individual-level breakdowns. Refuse. It is technically unavailable in the aggregator by design; keep it that way. Once it exists it will be requested by someone senior enough to get it. The first reading looks bad and there is pressure to withhold it. A withheld baseline is worse than no baseline, because you now know and cannot say you did not. Tier-1 data reported as reassurance. It cannot detect decay. The instrument says so explicitly for this reason. Local vocabulary variants. Every unprefixed local code destroys comparability. Use x_ and propose the addition centrally.

[8489] Ninety-day MVP (earlier version) (Superseded sequence) Instrument one live decision-support deployment with the P1 event schema (two weeks of engineering) Add predict-then-reveal on the highest-consequence decision type only Establish unaided baseline from priors captured in first month Publish aggregate result to service owner and Hub — including if it shows nothing Run first canary batch under ethics approval, aggregate only, agreed with unions in advance Write up event schema and prior-capture component as reusable spec

[8498] What departments are asked to do (README) (Programme) Map existing telemetry onto the event schema Add predict-then-reveal on one high-consequence decision type Run run_baseline.py against real events instead of simulated ones Publish the aggregate result, including if it shows nothing

[8505] Immediate sequence post-MoG (Programme) Establish where the AI assurance profession work landed Submit the ministerial brief Contact MHCLG Local AI and the LGA Offer the schema and pipeline to GDS in DCMS as a candidate first delivery artefact Identify one department willing to be instrumented

[8513] Recommended order to publication (Programme) Repository Pilot Exemplar Accessibility conformance Publication

## Governance templates [8521]

## Data protection impact assessment — starting positions [8523]

[8525] Is a DPIA required? Probably yes at tier 2 and certainly at tier 3. The processing concerns staff conduct at work, involves systematic monitoring of a workforce, and relates to the evaluation of performance — even though the design deliberately prevents individual evaluation. Argue it through rather than assuming the aggregation exempts you.

[8526] The question your DPO will ask: if it is genuinely non-identifying, why does it need a DPIA? Answer: because the collection point is identifying, and because the risk being assessed is function creep, not the current design.

## Equality impact assessment — the questions that actually bite [8528]

[8530] The generic template will not surface the real issues. These will.

[8531] Differential effect of friction. Cognitive forcing interventions benefit people with higher need for cognition more than others. Uniform application therefore produces unequal benefit. Who is disadvantaged — staff with dyslexia, ADHD, English as an additional language, high caseloads, caring responsibilities affecting available concentration?

[8532] Reasonable adjustments. Does predict-then-reveal interact badly with any assistive technology in use? Has it been tested with a screen reader, with magnification, and at the time pressure a real queue applies?

[8533] Cohort composition. If cohorts map to teams, and teams differ systematically in composition, aggregate comparison between cohorts can become proxy discrimination. Check before publishing cohort comparisons.

[8534] Who is in determine-class roles? If the roles carrying the heaviest oversight burden are disproportionately held by any group, the burden is not equally distributed.

[8535] Effect of the junior-role finding. If entry-level roles are being reshaped, who currently holds them and who is affected by their redesign? This has a clear equality dimension and is the longest-lead item in the programme.

[8536] Language. Where the body has Welsh Language Standards obligations, the interface and any staff-facing materials fall within them.

[8537] Do not conclude "no impact". The honest finding is that the impact is real, differential and manageable — and that uniform friction is the version that fails the duty.

## Trade union engagement — a note to open the conversation [8539]

[8541] Draft for adaptation. Send before anything is built, not before it launches.

[8542] We are proposing to measure whether human oversight of AI systems in this service is working. We want to design it with you, and there is one design decision we would rather you set than we did.

[8543] The background: every instrument governing our use of AI treats human oversight as the main safeguard. None of them checks whether that safeguard is functioning. That is a risk to the public and, more immediately, a risk to members — because a colleague placed in an approval loop without the time, information or practised skill to exercise it meaningfully is not exercising accountability. They are absorbing liability for an institutional decision they could not realistically have controlled.

[8544] What we are proposing to measure: how the service as a whole is performing — how quickly outputs are approved, how much they are changed, whether errors are being caught.

[8545] What we are not proposing to measure, in any form: individual performance. There is no user identifier in the data schema. The schema is closed, so one cannot be added. The analysis tools refuse any query resolving to fewer than ten people, and refuse outright any file containing an identifier column. This is enforced in code rather than promised in policy, because we think a promise is worth less than a system that cannot do the thing.

[8546] What we would like to agree with you before we build: that this operates on a just-culture basis — closer to confidential safety reporting in aviation than to appraisal; that findings are never attributed, formally or informally; that participation in any unaided practice or sampling is scheduled work rather than an addition to workload; and that we jointly review, annually, whether any request for individual-level data has been made, and record that it was refused.

[8547] What we would ask in return: that where the measurement shows oversight is not working, the response is to fix the workload, the interface or the deployment — not the individual.

[8548] We would rather have this conversation now, at design stage, than present you with something finished. If the answer is that this cannot be made acceptable, we would rather know before we build it.

## Ethics application for canary injection — the content that will be asked for [8550]

[8552] Only needed at tier 3. Expect months, not weeks.

[8553] What is proposed. Injecting synthetic known-bad AI outputs, at a low randomised rate, into a live review queue, to measure whether reviewers detect them.

[8554] Why it cannot be done in a simulation. Detection under real time pressure, real caseload and real fatigue is the thing being measured. A laboratory version measures something else. This is the same reasoning behind live fire drills and phishing simulations, both of which have established precedent in government.

[8555] Harm to the public — the safety case. No canary can reach a citizen. Injected items are suppressed downstream by the platform regardless of the reviewer's disposition. State the technical mechanism, not the intention. Include the failure mode: what happens if the suppression fails, how it would be detected, and how quickly.

[8556] Harm to staff. Reviewers know canaries exist but not which items they are. The measure is aggregate and non-attributable; failing to catch one has no individual consequence and cannot be traced to a person. Address the stress question directly: this is a workload and design intervention if catch rates fall, not a disciplinary one.

[8557] Consent. Individual consent is not sought, for the same reason it is not sought for fire drills — announced tests measure announced behaviour. Collective agreement is sought instead, through the recognised unions, and staff are told the programme exists, its purpose, and that results are never individual.

[8558] Withdrawal. The union side can suspend injection. Say so explicitly; it is what makes the collective-agreement route legitimate.

[8559] Data. Canary events carry no identifier. Retention as per the DPIA.

[8560] Reporting. Aggregate catch rate by canary class, reported to the service owner and the SRO. Published internally including when results are poor.

[8561] The question the committee will ask: what happens if catch rates are very low? Answer in advance: it triggers a review of workload, interface and deployment scope — and, for a determine-class service, consideration of whether the deployment should continue in its current form. If you cannot commit to that, the case for injecting is weak.

## Governance templates — preamble [8563]

[8565] Four artefacts a department cannot deploy this without. Skeletons, not legal advice — take them to your DPO, equality lead and Government Legal Department contact. They exist so the conversation starts from a draft rather than a blank page.

## CONTRIBUTING.md [8567]

[8569] Run python3 -m pytest tests/ -q and python3 ../verify.py. Both must pass. CI runs them anyway.

[8570] Codes are additive and permanent. A code is never removed or repurposed; superseded codes are marked deprecated with a named successor. To propose an addition, give a definition, a worked example, and a statement of why an existing code does not fit.

[8571] Local codes must be prefixed x_. Anything unprefixed is reserved centrally so that local extension never collides with a future addition.

[8572] The schema is closed (additionalProperties: false) and contains no individual identifier field. Both properties are load-bearing: they are what makes the privacy commitment credible to staff and to unions rather than merely stated. A change that weakens either needs an explicit case, not a pull request.

[8573] Say what data the new threshold was calibrated against. Thresholds set by judgement should be labelled as such in the finding text, as the current ones are.

[8574] Prefer a test that would have caught a real defect. Every fix in the changelog was found by one of: a test, the verification harness, or a reader asking a sharp question. Only the first two scale.

[8575] Back to the contents · Suggest a correction (opens GitHub)

