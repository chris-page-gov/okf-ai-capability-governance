---
type: publisher-section
title: What practitioners and regulators are saying
status: draft
sources:
- title: What practitioners and regulators are saying
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#signals
x-dom-section: signals
---

# What practitioners and regulators are saying

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#signals)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## What practitioners and regulators are saying [20914]

[20915] 29 signals on governing AI agents and the data they use, gathered from public LinkedIn content and refreshed weekly. Each names its author, links to where it was found and says how far it has been checked. Inclusion is not endorsement.

[20917] Read with care. LinkedIn does not allow automated reading of posts, so every summary comes from search-indexed text and is paraphrased. 15 of 29 come from vendors, consultancies or law firms and are marked. Statistics without a primary source are flagged as unverified. Check the source before you quote anything. The register is open data: ai-data-governance-signals.json (scanned 2026-11-09, version 1.2.0).

## UK public sector data leaders on data in action for public services [20928]

[20929] Lee Stockwell , Databricks · 2026

[20931] Activity highlights George Bettsworth, Head of Data Science at the Foreign, Commonwealth and Development Office, putting AI progress down to good governance, with the argument that governance should sit at the data layer rather than in each application. Also trails an Innovation 2026 panel with Sue Bateman (Defra CDO), Jacqui Leggetter (DWP) and Aimee Smith (Government Chief Data Officer).

[20932] Why it matters: Direct UK government voices on governing AI through the data estate; supports BOT's position that agent governance starts with data governance.

[20934] Caution: Vendor-hosted content; the FCDO view is relayed by the vendor, not quoted from FCDO.

[20936] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Trusted third-party AI assurance: from principles to implementation [20946]

[20947] Elizabeth Seger , Tony Blair Institute for Global Change · 2026 (about one month before scan)

[20949] Argues AI governance is shifting from principles to implementation and that governance capacity is what lets organisations adopt AI agents safely. Points to the UK Government's Trusted Third-Party AI Assurance Roadmap (September 2025), tied to commitment 29 of the AI Opportunities Action Plan.

[20950] Why it matters: Links BOT's assurance pages to a named UK policy instrument and commitment number.

[20952] Caution: Roadmap and commitment number should be checked against GOV.UK before citing in BOT's evidence base.

[20954] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Scaling the Responsible Adoption of Agentic AI (techUK report) [20963]

[20964] Usman Ikhlaq , techUK (author); now University of Bath Institute for Policy Research · 21 July 2026

[20966] Profile lists a techUK report he authored on moving agentic AI beyond pilots to responsible deployment at scale across the UK economy, including how oversight and accountability keep pace.

[20967] Why it matters: UK industry baseline for agent oversight; a comparator for BOT's agent governance playbook.

[20969] Caution: Report itself not read; summary is from the profile listing.

[20971] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## AI Security Institute and NCSC advice on agentic AI cyber risk [20981]

[20982] AI Security Institute (AISI) , UK Government · 2026

[20984] AISI's page links to NCSC guidance on managing the cyber risk of agentic AI and to its Alignment Red Team work. The page describes AISI as part of the Cabinet Office.

[20985] Why it matters: Authoritative UK security sources BOT should cite for agent permissions and runtime controls.

[20987] Caution: Departmental home is as stated on the LinkedIn page; confirm on aisi.gov.uk given recent machinery of government changes.

[20989] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Agent autonomy, accountability and control boundaries in financial services [21000]

[21001] Keith Vincent (speaker); hosted by Ashurst Perkins Coie , Government Legal Department, Treasury Legal Advisers · 7 October 2026

[21003] Event activity frames AI agents around autonomy, accountability and where control boundaries sit, and notes that customers' own agents bring new liquidity and fraud risks.

[21004] Why it matters: Government legal perspective on the same question BOT answers: what an agent may do without a human.

[21006] Caution: Event summary written by the host firm, not by the speaker.

[21008] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## FCA moving towards agentic supervision [21018]

[21019] Sophie Sheldon (quoted in Law360 UK); liked by Devina Shah , Simmons & Simmons · 2026

[21021] Activity reports the FCA's plan to become an agentic regulator, with a warning about over-reliance on a single model, platform or provider, and separately references new FCA guidance on AI in financial services.

[21022] Why it matters: A UK regulator itself adopting agents: a live case for BOT's concentration-risk and vendor-neutrality guidance.

[21024] Caution: Secondary report via Law360; check the FCA's own statement.

[21026] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Responsible AI governance: beyond the 'Department of No' [21036]

[21037] Yasmin Liverpool , Chief Data Office, National Highways · Undated (likely 2025)

[21039] LinkedIn article proposing shared accountability for AI governance (for example the CDO with the CSO) or a cross-executive AI steering group, citing the NAO finding that poor data quality is a barrier to AI in government and the Generative AI Framework for HM Government as a starting point.

[21040] Why it matters: A practising government CDO's operating-model view; maps onto BOT's roles and accountability pages.

[21042] Caution: Predates later UK guidance that replaced the Generative AI Framework; treat as historical context.

[21044] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Most organisations will adopt agents before they can govern them [21053]

[21054] Melvyn White , Agentic AI strategy, governance and management (independent, London) · Current profile

[21056] Profile thesis: the gap between agent adoption and the ability to govern agents is the core risk.

[21057] Why it matters: A crisp framing of the governance-debt problem BOT exists to close.

[21059] Caution: Opinion; no evidence attached in the indexed text.

[21061] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Data governance must scale with AI adoption [21070]

[21071] Jake Boudsocq , Department of Government Services (Victoria, Australia) · 2026 (about five months before scan)

[21073] Takeaways from the 2026 Melbourne Data Protection and Security Summit: data governance is the operating model that makes responsible AI possible at scale; uncatalogued legacy data compounds risk; Digital Transformation Agency model clauses are becoming a public sector baseline; AI governance is not set-and-forget.

[21074] Why it matters: Peer-government evidence for BOT's 'know your data before AI' gate and for catalogue-first sequencing.

[21076] Caution: Australian context; DTA clauses are not UK instruments.

[21078] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## 2026 AI governance priorities, including governing AI agents [21087]

[21088] Partnership on AI (reposted by Stephanie Ifayemi) , Partnership on AI · 2026 (about eight months before scan)

[21090] Sets out priorities led by governing AI agents with accountability, security and privacy, plus stronger documentation and public reporting across the AI value chain and shared international baselines. Also notes work on how public sector AI governance differs from private sector approaches.

[21091] Why it matters: Multi-stakeholder agenda that BOT's agent registry and transparency pages already address.

[21093] Caution: Agenda-setting piece; not guidance.

[21095] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## From governance decisions to enforceable authority at runtime [21105]

[21106] Patrick Upmann , AIGN Global · 2026

[21108] As agents move from generating information to taking actions across data, tools and systems, the question becomes how governance decisions are enforced at runtime. Situates this against ISO/IEC 42001, the NIST AI Risk Management Framework and the EU AI Act.

[21109] Why it matters: Matches BOT's 'the app is the leash' principle: permissions enforced by scope, not policy text.

[21111] Caution: Author markets a proprietary governance framework.

[21113] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Agent scanners and an agent registry built on agent-card metadata [21123]

[21124] Roberto Mandiola , Amazon Web Services (post about MuleSoft and Google Cloud) · 2026

[21126] Describes scanners that find AI agents and capture metadata on what each can do, its underlying model and its data access rights, mapped to the agent-to-agent protocol's agent card so organisations hold one registry of agents, including home-built agents and MCP servers.

[21127] Why it matters: Strongest metadata link in this scan: an agent register is a metadata problem, which ties BOT to the Metadata Exchange Model and DCAT work.

[21129] Caution: Vendor announcement relayed in another person's activity feed (indexed under Andrea Radojicic's profile).

[21131] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Governing AI agents as data consumers [21141]

[21142] Bigeye (and others in the feed) , Bigeye · 2026

[21144] Argues that governing agents that read enterprise data differs from human-era data governance because agents fail at different points in the pipeline; recommends knowing data quality signals and what data agents access before rollout. The feed also cites a Sinch survey of 2,527 senior decision-makers in which 74% had rolled back a live agent after a governance failure.

[21145] Why it matters: Useful framing for BOT's data-access controls; the rollback figure is a candidate indicator.

[21147] Caution: Survey figure is vendor-reported and unverified; do not use in BOT's evidence base until the Sinch source is read.

[21149] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Unsanctioned agents as governance debt [21159]

[21160] Subeer Sehgal , Grazitti Interactive · 2026

[21162] A playbook for governing agents: where risk concentrates, which controls hold and how to prove compliance as agent numbers grow. Warns that unvalidated feedback loops, where agents treat their own inferences as fact, are the real blind spot. The company feed claims 54% of organisations have between 1 and 100 unsanctioned agents.

[21163] Why it matters: Supports BOT's agent inventory and lineage controls.

[21165] Caution: The 54% figure has no stated source; treat as unverified.

[21167] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Context engines and a knowledge layer for agents [21176]

[21177] Robert Noyce , Shell · 2026

[21179] Agents need business context, semantic definitions, governance, memory and trusted data; a knowledge layer linking business definitions to data gives agents that context.

[21180] Why it matters: Endorses the glossary, ontology and knowledge-graph layer the govukOS build standard already requires.

[21182] Caution: Practitioner reflection after an event; no evidence attached.

[21184] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## AI-ready data goes beyond data quality [21193]

[21194] Joyce Goh , Salesforce (Informatica) · 2026

[21196] Data readiness affects AI economics, and governance must evolve as AI moves from generating insight to agents taking action, needing more visibility, accountability and control.

[21197] Why it matters: Corroborates S01 and S09 from the platform side.

[21199] Caution: Vendor promotional content.

[21201] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Agents stretch the old data quality problem [21210]

[21211] Herman Yu , Teeup Data Technology · 2026

[21213] Data governance and data quality issues are long-standing; the non-deterministic behaviour of LLMs and agents stretches them further, so enterprise architecture must join governance dimensions into one framework.

[21214] Why it matters: Supports treating agent governance as an extension of data governance, not a new silo.

[21216] Caution: Opinion.

[21218] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## EU AI Act in force but enforcement readiness uneven [21227]

[21228] Robert Gasparovic , HAVEL & PARTNERS, Slovak Republic · 2026

[21230] Notes the EU AI Act has applied since 2 August 2026 but Member States differ in enforcement readiness; Europe is also revisiting text-and-data-mining rules.

[21231] Why it matters: Cross-border context for BOT's regulatory crosswalk.

[21233] Caution: Applicability dates differ by obligation under the Act; check the specific article before citing.

[21235] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## China's July 2026 framework for governing AI agents [21245]

[21246] Pascal Jiang (post by Rimon PC) , Dacheng Law Offices / Rimon PC · July 2026

[21248] Three measures effective July 2026 move China from principles to operational governance, including AI ethics guidance, a framework for anthropomorphic AI services and a policy framework for governing AI agents.

[21249] Why it matters: One of the first national-level agent governance frameworks; a comparator for BOT.

[21251] Caution: Law-firm summary; the primary texts are not read.

[21253] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Institutional readiness for responsible AI in the public sector [21262]

[21263] Anthony Akpan , Tizee Consult; Institutional AI Governance newsletter · April and July 2026

[21265] An SSRN preprint (April 2026) on institutional readiness as a condition for responsible AI in the public sector, and a newsletter launched in July 2026 on institutional responsibility in AI governance.

[21266] Why it matters: Academic framing of readiness that maps onto BOT's maturity and adoption model.

[21268] Caution: Preprint, not peer reviewed; focus is developing countries.

[21270] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Five AI governance platforms compared [21280]

[21281] Brad Martineau , LinkedIn article · Undated

[21283] Compares Credo AI, IBM watsonx.governance, Holistic AI, Fiddler AI and Atlan, noting that a data governance and metadata platform such as Atlan supplies the lineage regulators expect.

[21284] Why it matters: Market scan only; useful for BOT's tooling landscape, not for recommendations.

[21286] Caution: Listicle; possible commercial interest. BOT stays vendor-neutral.

[21288] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## AI Security Institute publishes its inaugural Frontier AI Trends Report [21297]

[21298] Tess Buckley , Post about the AI Security Institute (DSIT) · 18 December 2025 (derived from the post's activity ID)

[21300] Post announcing that the UK AI Security Institute, part of DSIT, published its first Frontier AI Trends Report.

[21301] Why it matters: A UK government evidence source on frontier AI capability and risk that BOT's assurance material can cite once read at source.

[21303] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Read the report on GOV.UK before citing any finding. Older than the last scan date; indexed only now.

[21305] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## AI governance as the next frontier of data governance [21314]

[21315] Khyati Thakkar , LinkedIn article · Undated

[21317] Article framing AI governance as an extension of existing data governance practice.

[21318] Why it matters: Supports BOT's premise that AI and agent governance should be built on data governance foundations.

[21320] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Author name taken from the article URL; organisation and date unknown.

[21322] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Developing AI assurance frameworks [21330]

[21331] Heather Dawe , LinkedIn article · Undated

[21333] Article on how organisations can build AI assurance frameworks.

[21334] Why it matters: Possible practitioner input to BOT's assurance pillar.

[21336] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Author name taken from the article URL; organisation, region and date not confirmed.

[21338] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## AI control planes for governing models, agents and decisions at scale [21347]

[21348] Mahmoud Abufadda , LinkedIn article · Undated

[21350] Article on the rise of AI control planes as a way to govern models, agents and their decisions centrally.

[21351] Why it matters: Relates to BOT's control-tower and agent-registry thinking: one governed layer over many agents.

[21353] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Author name taken from the article URL; organisation and date unknown. Check for vendor interest before citing.

[21355] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## UK introduction to AI assurance [21364]

[21365] Katharina Koerner , LinkedIn post · 15 February 2024 (derived from the post's activity ID)

[21367] Post sharing the UK government's Introduction to AI assurance guidance.

[21368] Why it matters: Points to the baseline UK assurance guidance BOT should align with.

[21370] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Dated 2024, so background rather than new signal; check GOV.UK for the current edition.

[21372] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## CETaS paper on assurance of third-party AI systems for UK national security [21381]

[21382] The Alan Turing Institute (CETaS) , The Alan Turing Institute · 17 January 2024 (derived from the post's activity ID)

[21384] Turing Institute post on a CETaS paper about AI risk management and assuring third-party AI systems in a UK national security setting.

[21385] Why it matters: Complements S02 on third-party assurance with a public-sector research source.

[21387] Caution: Only the headline and URL were indexed; LinkedIn refuses page fetches, so the body was not read. Full paper title is truncated in the URL; dated 2024, so background rather than new signal.

[21389] Source on LinkedIn (opens an external website) · evidence: search-indexed text, post not opened

## Semantic layer for agents: AI drafts business definitions, people certify them, agents answer in SQL [21399]

[21400] NVIDIA , Auto Ontology (open source, Apache 2.0) · November 2026 (repository read on 13 November 2026)

[21402] An open-source service that drafts an ontology from database metadata: business terms mapped to columns, reviewed SQL expressions, and the joins between tables. People then test it with real questions and certify the names, descriptions and SQL. An agent answers questions by writing SQL from those definitions, checks the query against the database, and returns the answer with its SQL and the steps it took. It serves this context to other agents over MCP, and says when a question cannot be answered from the data.

[21403] Why it matters: It makes certification a separate human step from drafting, which is where this toolkit's H0 to H5 review levels apply: see the advanced guide's worked examples on certifying a definition and reviewing an agent's answer, and the evidence pack's field for the definitions an answer relied on.

[21405] Caution: Vendor project, and it does not accept outside contributions. Accuracy is measured with a separate text-to-SQL benchmark repository; this review did not run it or the software.

[21407] Source repository on GitHub (opens an external website) · evidence: primary source, the repository's README (summary and how it works)

## AI governance as four questions: the law, the proof, the accountability, and what runs in production [21418]

[21419] Luís Rodrigues , Not stated on the post (the author's headline describes him as a CPTO; he writes the newsletter Build What Matters) · About 7 November 2026 (the post showed '1w' when read on 17 November; the date is decoded from its activity ID)

[21421] Frames AI governance as four layers: regulation (the EU AI Act, plus GDPR, sector rules, NIS2 and DORA), standards and frameworks (ISO/IEC 42001 and the NIST AI RMF), roles (a named owner for every AI system) and controls. Argues that controls are where most organisations fall short, and lists them: risk-rate every system, give agents only the tools they need, train people in AI literacy, keep a human able to stop the system, keep an inventory, log everything, and test continuously. Suggests starting with an inventory of every AI tool in use.

[21422] Why it matters: The four questions map onto this toolkit: the law (Resources, tier 0), proof (evidence pack builder, TK-04), accountability (the accountable owner and H4 to H5 review) and production (agent registry, TK-03, and incident reporting, TK-12).

[21424] Caution: A practitioner's opinion post that also promotes the author's newsletter. The legal points (for example AI literacy as an EU duty) and the standards named should be checked against the primary texts before citing.

[21426] Source on LinkedIn (opens an external website) · evidence: post read in full in the owner's signed-in browser on 17 November 2026

[21429] Credit belongs to the named authors. To correct or remove an item, use the contact routes below.

