---
type: publisher-section
title: What is missing, prioritised with MoSCoW
status: draft
sources:
- title: What is missing, prioritised with MoSCoW
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#roadmap
x-dom-section: roadmap
---

# What is missing, prioritised with MoSCoW

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#roadmap)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

## What is missing, prioritised with MoSCoW [22074]

[22075] An honest backlog is a trust signal. These are the gaps identified in this portal and in most public sector AI guidance, ordered by whether they are essential, valuable, desirable or deliberately out of scope.

[22077] All

[22078] Must have

[22079] Should have

[22080] Could have

[22081] Won't have (this time)

## Named accountable owner and published contact route [22085]

[22086] Nothing on this page is credible without a person who owns it and answers questions.

## Accessibility statement, testing evidence and feedback route [22089]

[22090] Legally required for UK public sector sites; also the fastest trust signal.

## Version, last-reviewed and next-review dates on every artefact [22093]

[22094] Freshness is the main failure mode of guidance portals.

## Machine-readable metadata schema published openly [22097]

[22098] Without a schema, registries cannot federate and evidence cannot be automated.

## Risk-based human review model with no self-approval [22101]

[22102] The core control that keeps accountability with people.

## Source citation and provenance for every claim [22105]

[22106] Prevents hallucination becoming policy.

## DEIA screening built into the default workflow [22109]

[22110] Equality duty is a due-regard duty — it must happen before decisions, not after.

## Search across the whole corpus with filters and permalinks [22113]

[22114] Findability is the top usability complaint for guidance sites.

## Role-based entry points and task-first navigation [22117]

[22118] Users arrive with a task, not an interest in your information architecture.

## Downloadable, offline and printable formats [22121]

[22122] Supports assisted digital, low bandwidth and audit contexts.

## Worked examples and anti-patterns for each control [22125]

[22126] Abstract principles do not change behaviour; examples do.

## Change log and subscribe-to-updates [22129]

[22130] Lets teams re-check work when guidance changes.

## Multilingual and alternative-format provision (Welsh, Easy Read, BSL) [22133]

[22134] Statutory in some contexts and essential for inclusion in all.

## Automated link-health and freshness checking [22137]

[22138] Broken authority links silently destroy trust.

## API and JSON export of the registry and corpus [22141]

[22142] Enables reuse by other departments and tooling.

## Maturity self-assessment with benchmarking [22145]

[22146] Helps organisations see where they are without a consultant.

## Community contribution workflow with moderation [22149]

[22150] Scales the corpus beyond a single team.

## Interactive decision tree for tool selection [22153]

[22154] Reduces the "which tool may I use?" support burden.

## Carbon and cost telemetry per model call [22157]

[22158] Makes proportionality measurable rather than rhetorical.

## Automated approval of any high-risk output [22161]

[22162] Out of scope by design — approval stays human.

## Storing personal or official-sensitive data in this portal [22165]

[22166] The portal is public and stateless; sensitive records belong in assured systems.

## Vendor-specific lock-in to a single model provider [22169]

[22170] Conflicts with interoperability and exit obligations.

## Replacing professional assurance roles [22173]

[22174] The toolkit supports specialists; it does not substitute for them.

