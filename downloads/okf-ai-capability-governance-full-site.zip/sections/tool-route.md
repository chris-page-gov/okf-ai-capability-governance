---
type: publisher-section
title: Can I use AI for this?
status: draft
sources:
- title: Can I use AI for this?
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#tool-route
x-dom-section: tool-route
---

# Can I use AI for this?

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#tool-route)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[18309] Working tool

## Can I use AI for this? [18310]

[18311] Five questions give a first route. Governance follows what the AI can see, create and do, not which company made it. Nothing you enter leaves your browser.

[18315] 1 Would the output decide, or directly change, someone’s rights, entitlements, safety or access to a service?

[18318] Yes

[18320] No

[18322] Not sure

[18325] 2 Will you use personal data or information marked OFFICIAL-SENSITIVE or above?

[18328] Yes

[18330] No

[18332] Not sure

[18335] 3 Can the AI take actions, run on a schedule or work through several steps without you?

[18338] Yes

[18340] No

[18342] Not sure

[18345] 4 Is there an approved tool in your organisation's catalogue that already does this?

[18348] Yes

[18350] No

[18352] Not sure

[18355] 5 Could a conventional rule, form or automation do the job reliably?

[18358] Yes

[18360] No

[18362] Not sure

[18365] Answer the five questions

[18366] The route appears when every question has an answer. “Not sure” is a valid answer.

[18367] Start again

## How the route is decided [18369]

[18370] The first rule that matches wins. A first sort, not an approval: every route other than an approved tool leads to a registered use case.

[18372] Would the output decide, or directly change, someone’s rights, entitlements, safety or access to a service?

[18373] Will you use personal data or information marked OFFICIAL-SENSITIVE or above?

[18374] Can the AI take actions, run on a schedule or work through several steps without you?

[18375] Is there an approved tool in your organisation's catalogue that already does this?

[18376] Could a conventional rule, form or automation do the job reliably?

[18381] When

[18382] Route

[18383] What it means

[18386] Q1 is Yes

[18387] Seek advice before going further

[18389] AI must not make or directly change this kind of decision on its own. Register a use case; it takes the specialist route with a named human decision-maker.

[18391] Q5 is Yes

[18392] Try conventional automation first

[18394] A rule, form or workflow is usually safer, cheaper and more consistent. Use AI only where judgement over unstructured material is the task.

[18396] Q3 is Yes or Not sure

[18397] Take the agent route

[18399] Anything that acts, runs on a schedule or works through steps without you needs an agent design record, approval points and a stop control.

[18401] Q1 is Not sure, or Q2 is Yes or Not sure

[18402] Register a use case

[18404] Personal or sensitive information, or an unclear impact on people, needs data readiness and privacy screening before use.

[18406] Q4 is Yes

[18407] Go ahead with an approved tool

[18409] Use it within its approved uses and check its catalogue entry for conditions. Review every output before you rely on it.

[18411] Otherwise

[18412] Check for reuse, then register

[18414] No approved tool is known to fit. Search your organisation's catalogue first; if nothing fits, request a tool through a use case.

