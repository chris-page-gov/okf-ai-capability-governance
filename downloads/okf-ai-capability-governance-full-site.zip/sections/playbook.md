---
type: publisher-section
title: Every part, every chapter
status: draft
sources:
- title: Every part, every chapter
  resource: https://cyberdudeuk.github.io/ai-capability-governance/#playbook
x-dom-section: playbook
---

# Every part, every chapter

[Open this section on the publisher’s website](https://cyberdudeuk.github.io/ai-capability-governance/#playbook)

The numbers in brackets identify elements in the ordered DOM inventory. This is a text projection of Em’s material.

[1140] Contents · 85 chapters in 12 parts

## Every part, every chapter [1142]

[1143] The agent governance playbook takes a team from “can I use AI for this?” to a governed, monitored and eventually retired AI agent. Open a part to see its chapters, or use the contents drawer.

[1146] Part 1 · 5 chapters Start here From Overview to Capability domains

[1155] 1.1 Overview

[1158] 1.2 Can I use AI for this?

[1161] 1.3 How to use this guide

[1164] 1.4 The playbook

[1167] 1.5 Capability domains

[1171] Part 2 · 6 chapters Decide and prioritise From Evidence before assertion to Assurance tiers

[1180] 2.1 Evidence before assertion

[1183] 2.2 Use cases & evidence

[1186] 2.3 Public sector case library

[1189] 2.4 Classify & assess

[1192] 2.5 Criticality & gates

[1195] 2.6 Assurance tiers

[1199] Part 3 · 8 chapters Design and build From Lifecycle & templates to Autonomy boundaries

[1208] 3.1 Lifecycle & templates

[1211] 3.2 Capability classes

[1214] 3.3 Skill studio

[1217] 3.4 Agent assurance X-ray

[1220] 3.5 Connectors, MCP & integrations

[1223] 3.6 Architecture & quality

[1226] 3.7 Knowledge foundation

[1229] 3.8 Autonomy boundaries

[1233] Part 4 · 13 chapters Assure and govern From Control plane & evidence to Verifying AI-assisted work

[1242] 4.1 Control plane & evidence

[1245] 4.2 Data & information governance

[1248] 4.3 Architecture of trust

[1251] 4.4 Governance operating model

[1254] 4.5 Risks & mitigations

[1257] 4.6 Registers & lifecycle

[1260] 4.7 Internal ATRS registry

[1263] 4.8 Failure & recovery

[1266] 4.9 Human oversight principles

[1269] 4.10 Oversight controls

[1272] 4.11 Measuring oversight

[1275] 4.12 Human-side risks and priorities

[1278] 4.13 Verifying AI-assisted work

[1282] Part 5 · 7 chapters Operate and oversee From Portfolio control tower to Oversight runbook and templates

[1291] 5.1 Portfolio control tower

[1294] 5.2 Monitoring & reassessment

[1297] 5.3 Agent journey

[1300] 5.4 Agent employment

[1303] 5.5 Public service impact

[1306] 5.6 Observatory & barometer

[1309] 5.7 Oversight runbook and templates

[1313] Part 6 · 4 chapters Fund and buy From Cost, value & investment to Dependency & exit

[1322] 6.1 Cost, value & investment

[1325] 6.2 FinOps & models

[1328] 6.3 Commercial & suppliers

[1331] 6.4 Dependency & exit

[1335] Part 7 · 12 chapters People and adoption From Multidisciplinary teams to Neuroinclusive AI at work

[1344] 7.1 Multidisciplinary teams

[1347] 7.2 AI service team

[1350] 7.3 Roles & pathways

[1353] 7.4 Capability academy

[1356] 7.5 Capability & maturity

[1359] 7.6 Inclusive adoption

[1362] 7.7 Adoption journey

[1365] 7.8 Agent rollout

[1368] 7.9 Community engagement

[1371] 7.10 Operating model

[1374] 7.11 Adoption & change model

[1377] 7.12 Neuroinclusive AI at work

[1381] Part 8 · 9 chapters Live pilot From The pilot in one view to Decision & toolkit

[1390] 8.1 The pilot in one view

[1393] 8.2 What it tests

[1396] 8.3 Candidate selection

[1399] 8.4 Pilot roles

[1402] 8.5 Assurance model

[1405] 8.6 Journey & ceremonies

[1408] 8.7 Communications

[1411] 8.8 Success & feedback

[1414] 8.9 Decision & toolkit

[1418] Part 9 · 8 chapters Product documentation From Product requirements to Gov.uk AI resources

[1427] 9.1 Product requirements

[1430] 9.2 Functional & technical spec

[1433] 9.3 Solution architecture

[1436] 9.4 High-level design

[1439] 9.5 Low-level design

[1442] 9.6 Theory of change

[1445] 9.7 Personas & journeys

[1448] 9.8 Gov.uk AI resources

[1452] Part 10 · 4 chapters Knowledge and navigation From Thesaurus to Federated guidance service

[1461] 10.1 Thesaurus

[1464] 10.2 Taxonomies & ontology

[1467] 10.3 Platforms & repositories

[1470] 10.4 Federated guidance service

[1474] Part 11 · 4 chapters Deploy for real From Service atlas to What this does not cover

[1483] 11.1 Service atlas

[1486] 11.2 Case generator

[1489] 11.3 Worked examples

[1492] 11.4 What this does not cover

[1496] Part 12 · 5 chapters Reference From UK nations to Obligations register

[1505] 12.1 UK nations

[1508] 12.2 International

[1511] 12.3 Pace & parity

[1514] 12.4 Oversight crosswalk

[1517] 12.5 Obligations register

[1521] Read

[1524] Route tool

[1527] Knowledge map

[1530] Method and withheld content

[18417] Knowledge map

## How the playbook fits together [18418]

[18419] Parts on the inner ring, chapters on the outer ring; select any node to go to it. The taxonomy is published as SKOS in JSON-LD and the content as JSON, so other portals can harvest both.

[18827] 1. Start here 5

[18831] 2. Decide and prioritise 6

[18835] 3. Design and build 8

[18839] 4. Assure and govern 13

[18843] 5. Operate and oversee 7

[18847] 6. Fund and buy 4

[18851] 7. People and adoption 12

[18855] 8. Live pilot 9

[18859] 9. Product documentation 8

[18863] 10. Knowledge and navigation 4

[18867] 11. Deploy for real 4

[18871] 12. Reference 5

[18875] Taxonomy (SKOS, JSON-LD) · Content (JSON) · Glossary

[18881] Transparency

## How the playbook was made [18882]

[18883] Ported from an internal AI agent governance toolkit on 18 November 2026. Each chapter was rendered, classified as public or withheld, redacted where needed and rebuilt as plain semantic content. Figures the source labels illustrative stay labelled illustrative; nothing here is an official policy position. On 22 November 2026, nine chapters were added from the Responsible AI and Data Use (RAIDU) work, classified the same way (docs/content-classification-2026-11-22-raidu.md). The source has 96 chapters: 85 are published here and 11 are withheld or merged into the rest of the portal. The decision for every chapter is in the content classification (opens GitHub) .

## Withheld or merged chapters [18886]

[18891] Chapter

[18892] Part

[18893] Decision and reason

[18896] AI tool catalogue

[18897] Decide and prioritise

[18898] Organisation-specific approved-tool statuses and links to internal pages; publishing them would read as endorsement.

[18900] Analytics, estimators & dashboards

[18901] Decide and prioritise

[18902] Its charts count entries in the withheld tool catalogue; the estimators it links to are published in "Cost, value and investment".

[18904] Blueprint coverage

[18905] Product documentation

[18906] Coverage map of internal source documents and blueprints, which are not published.

[18908] Portal specification trace

[18909] Product documentation

[18910] Traces requirements from an internal specification document.

[18912] Knowledge graph

[18913] Knowledge and navigation

[18914] Interactive graph of the internal edition; replaced by the generated knowledge map in this playbook.

[18916] Portal & site map

[18917] Knowledge and navigation

[18918] Map of the internal edition, including internal pages. The public playbook has its own contents and drawer.

[18920] Guided tours

[18921] Knowledge and navigation

[18922] Guided tours route through internal pages; the home page personas and journeys replace them.

[18924] Media centre

[18925] Knowledge and navigation

[18926] Films and decks: never kept in a repository (owner rule). They stay in the media library outside GitHub.

[18928] Self-assurance console

[18929] Knowledge and navigation

[18930] Self-test console of the internal edition; the public site runs its own checks in CI (see Transparency).

[18932] Sources & blueprints

[18933] Reference

[18934] Lists internal source documents. Public sources are in the resource library on the home page.

[18936] Glossary

[18937] Knowledge and navigation

[18938] Merged into the portal glossary, so the whole portal has one glossary: 39 new terms added, existing definitions kept.

## How changes are made and tracked [18939]

[18941] Reviewed every quarter; next review 2027-02-18.

[18942] The playbook, the contents drawer, the hero figures and the masthead menus are generated from data/playbook.json by tools/build_playbook.py ; check S21 fails the build if they drift.

[18945] Check S22 fails the build if any published file names an internal page, an internal team or an email address.

[18946] Corrections and requests go through GitHub issue forms (opens GitHub) ; the roadmap lists what is next.

