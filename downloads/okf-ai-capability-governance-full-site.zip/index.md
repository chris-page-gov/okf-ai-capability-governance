---
okf_version: '0.3'
title: AI Capability Governance and Implementation
description: Pinned public publisher-site archive with a curated OKF+ correspondence
  case
license: CC-BY-4.0
x-upstream-commit: 9dd855ecfd8aece1b87c49eff2096b2d13d3fc98
---

# AI Capability Governance and Implementation

An independent OKF 0.3 archive of Em’s public site at release 3.4.0. Each section has a readable text projection. The ordered element inventory and compressed original files preserve tables, controls, SVGs, runtime inputs and other details omitted from the readable projection.

Captured **29 named sections**, **23,005 HTML elements**, **933 links** and **186 controls** from the main page, plus **13 deployment files** from the pinned Git tree.

Start with [the correspondence case](correspondence/index.md) for the curated OKF+ example. Its semantic relationships are supplied as YAML-LD and JSON-LD.

## Read the site by section

| Section | HTML elements | Text blocks |
| --- | ---: | ---: |
| [Page shell and ungrouped content](sections/page-shell.md) | 1617 | 174 |
| [AI Capability Governance and Implementation](sections/top.md) | 78 | 19 |
| [Pick the route that matches your job today](sections/start-here.md) | 165 | 63 |
| [Every part, every chapter](sections/playbook.md) | 932 | 165 |
| [Start here](sections/part-start-here.md) | 575 | 261 |
| [Decide and prioritise](sections/part-decide-and-prioritise.md) | 1294 | 640 |
| [Design and build](sections/part-design-and-build.md) | 1520 | 770 |
| [Assure and govern](sections/part-assure-and-govern.md) | 2230 | 1254 |
| [Operate and oversee](sections/part-operate-and-oversee.md) | 1426 | 607 |
| [Fund and buy](sections/part-fund-and-buy.md) | 1546 | 742 |
| [People and adoption](sections/part-people-and-adoption.md) | 2493 | 1207 |
| [Live pilot](sections/part-live-pilot.md) | 1087 | 461 |
| [Product documentation](sections/part-product-documentation.md) | 1104 | 496 |
| [Knowledge and navigation](sections/part-knowledge-and-navigation.md) | 547 | 224 |
| [Deploy for real](sections/part-deploy-for-real.md) | 339 | 164 |
| [Reference](sections/part-reference.md) | 2612 | 1323 |
| [Can I use AI for this?](sections/tool-route.md) | 107 | 54 |
| [Do the work here, not in a separate spreadsheet](sections/tools.md) | 262 | 121 |
| [A complete operating kit for AI-assisted public delivery](sections/toolkit.md) | 297 | 89 |
| [Human-centred controls for trustworthy AI work](sections/assurance.md) | 161 | 104 |
| [Treat skills, agents and code as assets in their own right](sections/catalogue.md) | 88 | 38 |
| [Designed for real people, varied needs and accountable teams](sections/ucd.md) | 78 | 44 |
| [Responsible use of AI assistive technology](sections/practice.md) | 77 | 49 |
| [Authoritative guidance, standards and reusable intelligence](sections/knowledge.md) | 78 | 47 |
| [Guidance, standards, toolkits and solutions — indexed and tiered](sections/resources.md) | 920 | 377 |
| [What practitioners and regulators are saying](sections/signals.md) | 519 | 178 |
| [Glossary and frequently asked questions](sections/glossary.md) | 568 | 368 |
| [How to check, challenge and contribute](sections/transparency.md) | 73 | 43 |
| [What is missing, prioritised with MoSCoW](sections/roadmap.md) | 104 | 53 |
| [Tell us what is wrong, missing or unclear](sections/contact.md) | 108 | 54 |

## Source and scope

- [Publisher code licence](source-bytes/em-code-LICENSE.txt)
- [Content licence](https://creativecommons.org/licenses/by/4.0/)
- [Pinned publisher HTML](https://github.com/cyberdudeuk/ai-capability-governance/blob/9dd855ecfd8aece1b87c49eff2096b2d13d3fc98/index.html)
- [Section index](evidence/section-index.json)
- [Ordered HTML elements and attributes](evidence/dom-elements.jsonl)
- [Link inventory](evidence/links.json)
- [Control inventory](evidence/controls.json)
- [Deployment and repository inventory with hashes](evidence/source-inventory.json)

The publisher’s content is CC BY 4.0 and code is MIT, with the included SIL Open Font License for fonts. This archive attributes Em, retains source links and records the extraction. Source files are compressed as data. External destinations are indexed as links. The Git inventory also identifies repository files outside the Pages deployment.

The full static capture is separate from operational verification. The original site remains the reference for live calculators, dynamically assembled views and changing resources. The full corpus has not been independently semantically reviewed.
